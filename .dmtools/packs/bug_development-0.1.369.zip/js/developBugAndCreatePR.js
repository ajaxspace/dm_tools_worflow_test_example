/**
 * Develop Bug and Create PR Post-Action
 * postJSAction for bug_development agent.
 *
 * Four possible outcomes determined by outputs written by the CLI agent:
 *
 *   outputs/blocked.json      → Bug cannot be fixed (needs human / credentials / etc.)
 *                               → Post Jira comment, move to Blocked, remove labels
 *
 *   outputs/already_fixed.json → Bug was fixed in a prior commit, no new code changes
 *                               → Post Jira comment with commit ref, move to Done
 *
 *   (neither file, but response.md missing) → CLI agent was interrupted (rate limit / crash)
 *                               → Push partial work (e.g. outputs/rca.md) if any
 *                               → Post informational comment, move to Ready For Development for retry
 *                               → Fail the run (gh-742) so the no-PR leg is a visible dead letter
 *
 *   (neither file, response.md present) → Normal fix — code changes made
 *                               → Delegate to developTicketAndCreatePR: commit, push, create PR, move to In Review
 */

var configLoader = require('./configLoader.js');
const { LABELS, resolveStatuses } = require('./config.js');
const developTicket = require('./developTicketAndCreatePR.js');
const commentMarkup = require('./common/commentMarkup.js');
const outputFiles = require('./common/outputFiles.js');
const gitStaging = require('./common/gitStaging.js');
// gh-1087: quota circuit-breaker — shared classification/comment contract
// with the story leg (both legs park the lane on a hard quota failure).
var quotaBreaker = require('./common/quotaCircuitBreaker.js');
var trackersModule = require('./common/trackers.js');
// gh-1301: shared ask-mode cluster — the needs-input probe, the
// ai_questions_asked label and the green needsInput outcome body are shared
// with the story and batch legs (review round 1, bug-legs thread).
var needsInputCommon = require('./common/needsInput.js');
// gh-1329: the structured dev exit — outputs/test_suspected.json routes
// machine-side into the rolling TC maintenance ledger.
var tcMaintenanceLedger = require('./common/tcMaintenanceLedger.js');
// gh-1329 review: the shared "load bug bookkeeping" helper (one getIssue,
// one machine-author resolution) for both legs that read the markers.
var bugBookkeeping = require('./common/bugBookkeeping.js');
// gh-1493: terminal-signal delivery contract (attemptDelivery/deliveryOutcome).
const { attemptDelivery, deliveryOutcome } = require('./common/terminalDelivery.js');
var wipSquash = require('./common/wipSquash.js');

function cleanCliOutput(output) {
    return (output || '').split('\n').filter(function(l) {
        return l.trim() &&
               l.indexOf('Script started') === -1 &&
               l.indexOf('Script done') === -1 &&
               l.indexOf('COMMAND=') === -1 &&
               l.indexOf('COMMAND_EXIT_CODE=') === -1;
    }).join('').trim();
}

function readJson(path) {
    try {
        const raw = outputFiles.readOutputFile(path, {});
        return (raw && raw.trim()) ? JSON.parse(raw) : null;
    } catch (e) {
        return null;
    }
}

function hasCodeGraphUsage() {
    try {
        const raw = file_read({ path: '.dmtools/codegraph-usage.log' });
        return !!(raw && raw.trim());
    } catch (e) {
        return false;
    }
}

function isCodeGraphRequired() {
    try {
        cli_execute_command({ command: 'bash -c "test -d .codegraph && command -v codegraph"' });
        return true;
    } catch (e) {
        return false;
    }
}

function isBlockedClaimVerified() {
    return hasCodeGraphUsage() || !isCodeGraphRequired();
}

/**
 * True when outputs/response.md exists with content. Thin wrapper over the
 * canonical outputFiles.hasOutputFile so the existence read shares one
 * candidate-expansion shape with developTicketAndCreatePR's content reader
 * (readResponseMd) — review round 1, duplicate-readers thread.
 */
function readHasResponseMd(ticketKey) {
    try {
        return outputFiles.hasOutputFile('response.md', { ticketKey: ticketKey });
    } catch (e) {
        return false;
    }
}

function removeWipLabel(ticketKey, params, tracker) {
    const wipLabel = params.metadata && params.metadata.contextId
        ? params.metadata.contextId + '_wip' : null;
    if (wipLabel) {
        try { tracker.removeLabel(ticketKey, wipLabel); } catch (e) {}
    }
}

function removeLabels(ticketKey, params, tracker) {
    removeWipLabel(ticketKey, params, tracker);

    const customParams = params.jobParams && params.jobParams.customParams;
    const removeLabel = customParams && customParams.removeLabel;
    if (removeLabel) {
        try {
            tracker.removeLabel(ticketKey, removeLabel);
            console.log('✅ Removed SM label:', removeLabel);
        } catch (e) {}
    }
}

/**
 * gh-1003: `params.ticket ? params : (params.jobParams || params)` was
 * evaluated twice in action; one named helper owns the actual-params
 * resolution.
 */
function resolveActualParams(params) {
    return params.ticket ? params : (params.jobParams || params);
}

/**
 * gh-1003: Path 0 (PR already open) scan predicate extracted from action —
 * same listPrs('open') shape, same head.ref match, null-tolerant.
 */
function findOpenPrForBranch(openPrs, expectedBranch) {
    return (openPrs || []).filter(function(pr) {
        return pr && pr.head && pr.head.ref === expectedBranch;
    })[0];
}

/**
 * gh-1003: Path 0 comment builder — pure markup assembly extracted so the
 * comment contract is unit-testable.
 */
function buildPrAlreadyOpenComment(ticketKey, existingUrl) {
    const m = commentMarkup.forTicket(ticketKey);
    return m.h(3, 'ℹ️ PR Already Open') + '\n\n' +
            'A pull/merge request already exists for this ticket: ' + existingUrl + '\n\n' +
            'Moved ticket to ' + m.bold('In Review') + ' for review.';
}

/**
 * gh-1003: Path 1 comment bodies extracted from action. The blocked comment
 * keeps the reason/tried/needs assembly — a multi-item `tried` list renders
 * one bullet per entry.
 */
function buildBlockedComment(ticketKey, blocked) {
    const m = commentMarkup.forTicket(ticketKey);
    let comment = m.h(3, '🚫 Bug Cannot Be Fixed Automatically') + '\n\n';
    comment += m.bold('Reason') + ': ' + (blocked.reason || '(see details below)') + '\n\n';
    if (blocked.tried && blocked.tried.length > 0) {
        comment += m.bold('Attempted') + ':\n';
        blocked.tried.forEach(function(t) { comment += '- ' + t + '\n'; });
        comment += '\n';
    }
    if (blocked.needs) {
        comment += m.bold('Needs from human') + ': ' + blocked.needs + '\n';
    }
    return comment;
}

/**
 * gh-1003: the CodeGraph-rejection wording for a blocked.json without
 * recorded CodeGraph usage (Path 1a).
 */
function buildBlockedWithoutCodeGraphComment(ticketKey) {
    const m = commentMarkup.forTicket(ticketKey);
    return m.h(3, '⚠️ Blocked Claim Needs CodeGraph Verification') + '\n\n' +
            'The agent wrote `outputs/blocked.json`, but no CodeGraph usage was recorded. ' +
            'Source-code bugs must use CodeGraph before declaring the work blocked.\n\n' +
            'Resetting to ' + m.bold('Ready For Development') + ' for an automatic retry.';
}

/**
 * gh-1003: Path 2 comment builder — rca/commit/description are optional; the
 * CodeGraph-usage wording difference (with/without) is preserved verbatim.
 */
function buildAlreadyFixedComment(ticketKey, alreadyFixed, codeGraphUsed) {
    const m = commentMarkup.forTicket(ticketKey);
    let comment = m.h(3, '✅ Bug Already Fixed') + '\n\n';
    if (alreadyFixed.rca) {
        comment += m.bold('Root Cause') + ': ' + alreadyFixed.rca + '\n\n';
    }
    if (alreadyFixed.commit) {
        comment += m.bold('Fixed in commit') + ': ' + m.code(alreadyFixed.commit) + '\n\n';
    }
    if (alreadyFixed.description) {
        comment += alreadyFixed.description + '\n\n';
    }
    if (!codeGraphUsed) {
        comment += 'No new PR required — fix is already in the codebase. No CodeGraph usage was recorded, but the ticket is being moved to *Done* as requested.\n\n';
    } else {
        comment += 'No new PR required — fix is already in the codebase. Moved to *Done*.';
    }
    return comment;
}

/**
 * gh-1003: Path 3 interrupted-leg comment builder — the partial-work wording
 * depends only on whether any git changes were found.
 *
 * gh-1121: when the leg's failure text classified as a whole-provider-chain
 * transient outage (kind provider_transient) the comment names the real
 * cause — the failing models and codes — instead of guessing a rate limit.
 * The header shape is shared with the story leg via
 * quotaBreaker.outageResetHeaderOf so both legs word the reset identically.
 */
function buildInterruptedComment(ticketKey, hasGitChanges, outage) {
    const m = commentMarkup.forTicket(ticketKey);
    var header = '⏸️ Development Interrupted';
    var causeLine = 'The AI agent was interrupted (likely hit a rate limit) before completing the implementation.';
    if (outage && outage.kind === 'provider_transient') {
        header = quotaBreaker.outageResetHeaderOf(outage);
        causeLine = 'The whole provider chain failed with transient errors, interrupting the AI agent before it could finish.';
    }
    return m.h(3, header) + '\n\n' + causeLine + ' The ticket has been reset to ' + m.bold('Ready For Development') + ' and will be automatically retried.\n\n' +
            (hasGitChanges ? 'Partial analysis work was saved to the branch.' : 'No partial work was produced.');
}

/**
 * gh-1003: the `git status --porcelain` line filter extracted from action's
 * staging/status check — same four exclusions in the same order (factory-kit
 * gitlink, machine-local runtime artifacts, script noise).
 */
function isMeaningfulStatusLine(line) {
    return !!line.trim() &&
           !/^(\?\?|A )\s+factory-kit(\/|$)/.test(line) &&
           !gitStaging.isRuntimeArtifactStatusLine(line) &&
           line.indexOf('Script started') === -1 &&
           line.indexOf('Script done') === -1;
}

/**
 * gh-1003: the staging + porcelain-status probe extracted from action.
 * Receives the raw cli tool so both the untrack wrapper and the
 * buildStagingPathspecs check-ignore probe keep their original call shapes.
 * A staging failure degrades to "no changes" (as before), never a throw.
 */
function detectGitChanges(cliTool) {
    const run = function (command) { return cliTool({ command: command }); };
    try {
        try {
            // gh-628: untrack machine-local runtime logs carried by
            // already-poisoned branches (the timer's broad add swept
            // .dmtools/credential-helper.log onto ai/gh-628); the
            // staging pathspec below keeps them out going forward.
            // Shared canonical list: js/common/gitStaging.js.
            gitStaging.untrackRuntimeArtifacts(run);
        } catch (cleanupErr) {
            console.warn('Could not remove tracked Copilot session cache before checking status:', cleanupErr);
        }
        // `:!factory-kit` — the factory workflow's kit step materializes a
        // NESTED git repo at $GITHUB_WORKSPACE/factory-kit; staging that
        // unstaged gitlink dies exit 128 and kills the whole bug/rework
        // leg after a green dev run (same class as gh-1000 on the story
        // flow, #648). Excluded like copilot-sessions; the status filter
        // below skips its `?? factory-kit/` line too.
        // `:!.dmtools/...` runtime logs (gh-628) — excluded by pathspec
        // because they live next to COMMITTED .dmtools/ files.
        // gh-683 (live fa run 37153405587): the check-ignore probe
        // (via cli_execute_command) drops exclusions for paths git
        // already ignores — naming an existing ignored-untracked path
        // in an exclusion pathspec trips git add's ignored-files guard.
        // gh-1164: `factory-kit` goes through the same check-ignore
        // probe (inside buildStagingPathspecs' extraPaths) — a static
        // exclusion trips the same ignored-pathspec guard when the kit
        // is materialized AND gitignored.
        // gh-1318: `input` + `outputs` ride the same probe — tracker-
        // regenerated leg context never belongs in the PR (see
        // js/common/gitStaging.js LEG_CONTEXT_ARTIFACT_PATHS).
        run('git add . -- ' + gitStaging.buildStagingPathspecs(cliTool, ['factory-kit', 'input', 'outputs']));
        const rawStatus = run('git status --porcelain') || '';
        return rawStatus.split('\n').filter(isMeaningfulStatusLine).length > 0;
    } catch (e) {
        console.warn('Could not check git status:', e);
        return false;
    }
}

/**
 * gh-1003: pure planner for the interrupted-leg partial-work push — decides
 * the target branch (expected branch wins over the current one), whether a
 * checkout switch is needed, and whether the push needs --force-with-lease
 * (partial work rescued from a protected branch). Returns null when there is
 * no branch to push at all.
 */
function decidePartialPush(currentBranch, expectedBranch, baseBranch) {
    const partialBranch = expectedBranch || currentBranch;
    if (!partialBranch) {
        return null;
    }
    return {
        branch: partialBranch,
        needsCheckout: currentBranch !== partialBranch,
        force: currentBranch === baseBranch || currentBranch === 'main' || currentBranch === 'master'
    };
}

/**
 * gh-1003: Path 0 completion extracted from action — posts the
 * already-open-PR comment, moves the ticket to In Review, removes SM labels
 * and returns the pr_already_open outcome. Tracker call order preserved.
 */
function handlePrAlreadyOpen(ticketKey, existingPr, tracker, statuses, params) {
    const existingUrl = existingPr.html_url || existingPr.url || ('#' + existingPr.number);
    console.log('⚠️  PR already open for', ticketKey, ':', existingUrl, '— skipping re-development');
    try {
        tracker.postComment(ticketKey, buildPrAlreadyOpenComment(ticketKey, existingUrl));
    } catch (e) {}
    try {
        tracker.moveToStatus(ticketKey, statuses.IN_REVIEW);
        console.log('✅ Moved', ticketKey, 'to In Review');
    } catch (e) { console.warn('Failed to move to In Review:', e); }
    removeLabels(ticketKey, params, tracker);
    return { success: true, path: 'pr_already_open', ticketKey };
}

/**
 * gh-1003: Path 1 completion extracted from action. Without recorded
 * CodeGraph usage the blocked claim is rejected and the ticket resets for a
 * retry; otherwise the blocked comment is posted and the ticket moves to
 * Blocked. Tracker call order (comment → move → labels) preserved.
 * gh-1493: a failed comment/transition fails the leg (terminalDelivery);
 * label cleanup stays non-fatal.
 */
function completeBlockedPath(ticketKey, blocked, hasCodeGraph, tracker, statuses, jiraConfig, params) {
    var deliveryErrors = [];
    if (!hasCodeGraph) {
        console.warn('outputs/blocked.json rejected — no CodeGraph usage was recorded');
        attemptDelivery(deliveryErrors, 'postComment failed', '❌ CodeGraph-retry comment NOT delivered:', null, function() {
            tracker.postComment(ticketKey, buildBlockedWithoutCodeGraphComment(ticketKey));
        });
        attemptDelivery(deliveryErrors, 'moveToStatus(' + statuses.READY_FOR_DEVELOPMENT + ') failed', '❌ Ticket NOT moved to Ready For Development — the CodeGraph retry will not be armed:', '✅ Moved ' + ticketKey + ' to Ready For Development for CodeGraph retry', function() {
            tracker.moveToStatus(ticketKey, statuses.READY_FOR_DEVELOPMENT);
        });
        removeLabels(ticketKey, params, tracker);
        return deliveryOutcome('blocked_without_codegraph', ticketKey, deliveryErrors);
    }
    attemptDelivery(deliveryErrors, 'postComment failed', '❌ Blocked comment NOT delivered:', null, function() {
        tracker.postComment(ticketKey, buildBlockedComment(ticketKey, blocked));
    });
    attemptDelivery(deliveryErrors, 'moveToStatus(' + jiraConfig.statuses.BLOCKED + ') failed', '❌ Ticket NOT moved to Blocked — the SM will keep arming dev legs:', '✅ Moved ' + ticketKey + ' to Blocked', function() {
        tracker.moveToStatus(ticketKey, jiraConfig.statuses.BLOCKED);
    });
    removeLabels(ticketKey, params, tracker);
    return deliveryOutcome('blocked', ticketKey, deliveryErrors);
}

/**
 * gh-1003: Path 2 completion extracted from action — posts the
 * already-fixed comment, moves the ticket to Done, stamps the
 * AI_DEVELOPED label, removes SM labels. Tracker call order preserved.
 * gh-1493: the comment + Done transition ARE the terminal signal — a failed
 * delivery fails the leg (fah#2182: a false success re-armed 40 legs).
 */
function completeAlreadyFixedPath(ticketKey, alreadyFixed, hasCodeGraph, tracker, jiraConfig, params) {
    if (!hasCodeGraph) console.warn('outputs/already_fixed.json accepted without CodeGraph usage');
    var deliveryErrors = [];
    attemptDelivery(deliveryErrors, 'postComment failed', '❌ Already-fixed comment NOT delivered:', null, function() {
        tracker.postComment(ticketKey, buildAlreadyFixedComment(ticketKey, alreadyFixed, hasCodeGraph));
    });
    attemptDelivery(deliveryErrors, 'moveToStatus(' + jiraConfig.statuses.DONE + ') failed', '❌ Ticket NOT moved to Done — the SM will keep re-arming:', '✅ Moved ' + ticketKey + ' to Done', function() {
        tracker.moveToStatus(ticketKey, jiraConfig.statuses.DONE);
    });
    try { tracker.addLabel(ticketKey, LABELS.AI_DEVELOPED); } catch (e) {
        console.warn('Failed to add', LABELS.AI_DEVELOPED, 'label:', e);
    }
    removeLabels(ticketKey, params, tracker);
    return deliveryOutcome('already_fixed', ticketKey, deliveryErrors);
}

/**
 * gh-1087 AC2: the quota-park variant of the interrupted-leg tracker side
 * effects — park comment (provider / quota window / reset condition), park
 * label on the ticket AND on the open PR for the branch (if any), but NO
 * status reset: an immediate retry is guaranteed to fail against the quota
 * wall. The SM dispatch lanes skip the park label; a bounded probe or a
 * human lifts it (AC3).
 */
// gh-1087 AC2: the open PR for the branch (if any) carries the park label
// too, so the PR reads parked to humans and review automation.
function parkLabelOpenPr(parkLabel, config, ticket, scm) {
    try {
        var pr = findOpenPrForBranch(scm.listPrs('open'), configLoader.resolveBranchName(config, ticket, 'development'));
        if (pr && pr.number) {
            scm.addLabel(pr.number, parkLabel);
            console.log('🅿️  Added quota park label', parkLabel, 'to PR #' + pr.number);
        }
    } catch (e) {
        console.warn('Could not label the open PR with the quota park label (non-fatal):', e);
    }
}

function parkQuotaPath(ticketKey, config, ticket, tracker, params, scm, classification) {
    var jobParams = (params && params.jobParams) || {};
    var parkLabel = quotaBreaker.parkLabelOf(jobParams);
    var everyN = quotaBreaker.probeEveryOf(jobParams);
    var m = commentMarkup.forTicket(ticketKey);
    try {
        tracker.postComment(ticketKey, quotaBreaker.parkComment(m, classification, parkLabel, everyN));
    } catch (e) { }
    try {
        tracker.addLabel(ticketKey, parkLabel);
        console.log('🅿️  Added quota park label', parkLabel, 'to', ticketKey);
    } catch (e) {
        console.warn('Failed to add quota park label ' + parkLabel + ':', e);
    }
    parkLabelOpenPr(parkLabel, config, ticket, scm);
    console.log('🅿️  Quota-exhausted leg parked — ticket NOT reset; the SM will skip the', parkLabel,
        'lane until the quota window resets (probe every', everyN, 'ticks) or a human removes the label.');
}

/**
 * gh-1301: the ask-mode outcome (outputs/needs-input.md present, response.md
 * deliberately absent). MUST run before the interrupted classification: an
 * ask leg is the documented pre-flight contract, not a crash. The WIP (if
 * any) is preserved on the branch first, the ticket is labeled
 * ai_questions_asked, SM idempotency labels go, and the leg ends GREEN —
 * no reset, no dead letter, no PR, no false "interrupted" incident under
 * the reporter's question.
 */
function completeNeedsInputPath(ticketKey, hasGitChanges, cliTool, config, ticket, tracker, params, expectedBranch) {
    pushPreservedAnalysisWork(hasGitChanges, cliTool, config, ticket, ticketKey);
    needsInputCommon.markNeedsInputTicket(tracker, ticketKey, LABELS.AI_QUESTIONS_ASKED);
    console.log('✅', ticketKey, 'flagged missing inputs — labeled ' + LABELS.AI_QUESTIONS_ASKED + ', awaiting the reporter (no PR, no reset)');
    // gh-1301 re-review: remove ONLY the per-leg WIP marker. The SM
    // idempotency label (customParams.removeLabel) must stay: the ask terminal
    // makes no status move, so the ticket stays eligible for the
    // bug-development SM rule, and that label is the rule's only skip guard —
    // stripping it re-dispatches the ask leg on every SM tick, forever. The
    // story leg's ask exit keeps its own SM label for exactly this reason.
    removeWipLabel(ticketKey, params, tracker);
    return needsInputCommon.needsInputOutcomeBody(ticketKey, expectedBranch);
}

/**
 * gh-1003: Path 3 interrupted-leg completion extracted from action — pushes
 * any partial work (planned by decidePartialPush), posts the informational
 * comment, resets the ticket for retry, removes SM labels and fails the run
 * via the shared throwInterruptedReset marker. Command and tracker call
 * order preserved.
 *
 * gh-1087: when the leg's failure text classifies as quota_exhausted the
 * reset is replaced by a quota park (label + comment + NO status reset) and
 * the run fails via the shared throwQuotaPark marker instead.
 */
function completeInterruptedPath(ticketKey, hasGitChanges, cliTool, config, ticket, tracker, statuses, params, scm, quotaClassification) {
    pushPreservedAnalysisWork(hasGitChanges, cliTool, config, ticket, ticketKey);
    parkQuotaInterruptedGate(ticketKey, config, ticket, tracker, params, scm, quotaClassification);
    // gh-1121: the interrupted reset comment names a provider-chain outage
    // (models + codes) instead of guessing a rate limit when the leg's
    // failure text classified as provider_transient.
    resetTicketForRetry(ticketKey, hasGitChanges, tracker, statuses, quotaClassification);

    removeLabels(ticketKey, params, tracker);
    // gh-742: ticket is reset for retry — fail the RUN so this
    // interrupted half-exit is a visible dead letter, not a green
    // no-PR leg that arms review downstream. The marked
    // throwInterruptedReset helper is shared from
    // developTicketAndCreatePR (required above) so the
    // marker/message contract lives in exactly one place.
    developTicket.throwInterruptedReset(ticketKey);
}

function pushPreservedAnalysisWork(hasGitChanges, cliTool, config, ticket, ticketKey) {
    if (!hasGitChanges) {
        wipSquash.squashTicketWipInPlace({ ticketKey: ticketKey, config: config, cliTool: cliTool, readFn: typeof file_read === 'function' ? file_read : null });
        console.log('No git changes — nothing to push.');
        return;
    }
    console.log('Partial git changes found — pushing to preserve analysis work...');
    try {
        const currentBranch = cleanCliOutput(cliTool({ command: 'git branch --show-current' }));
        const expectedBranch = configLoader.resolveBranchName(config, ticket, 'development');
        const baseBranch = (config.git && config.git.baseBranch) || 'main';
        executePartialPushPlan(cliTool, config, ticketKey, decidePartialPush(currentBranch, expectedBranch, baseBranch), currentBranch);
    } catch (pushErr) {
        console.warn('Could not push partial work:', pushErr);
    }
}

function executePartialPushPlan(cliTool, config, ticketKey, plan, currentBranch) {
    if (!plan) return;
    if (plan.needsCheckout) {
        console.log('Switching partial work from ' + (currentBranch || '(unknown)') +
            ' to development branch: ' + plan.branch);
        cliTool({ command: 'git checkout -B ' + plan.branch });
    }
    pushPartialWork(cliTool, config, ticketKey, plan);
}
/**
 * gh-1087 AC1/AC2: the quota variant of the interrupted-leg completion —
 * when the leg's failure text classifies as quota_exhausted the ticket is
 * PARKED (label + comment + NO status reset) and the run fails with the
 * shared quotaPark marker (same dead-letter contract as gh-742). Transient
 * or unknown classifications are a no-op here (the classic gh-742 reset
 * below handles them).
 */
function parkQuotaInterruptedGate(ticketKey, config, ticket, tracker, params, scm, quotaClassification) {
    if (!quotaClassification || quotaClassification.kind !== 'quota_exhausted') {
        return;
    }
    parkQuotaPath(ticketKey, config, ticket, tracker, params, scm, quotaClassification);
    removeLabels(ticketKey, params, tracker);
    developTicket.throwQuotaPark(ticketKey, quotaBreaker.parkLabelOf((params && params.jobParams) || {}));
}
function quotaGateContextOf(actualParams, params, ticketKey, customParams, expectedBranch) {
    return {
        ticketKey: ticketKey,
        customParams: customParams,
        metadata: actualParams.metadata || null,
        expectedBranch: expectedBranch,
        branchName: null,
        jobParams: params.jobParams || {}
    };
}

function quotaFailureClassificationOf(actualParams) {
    return quotaBreaker.classifyFailure(
        developTicket.classifyInterruptedText(actualParams.currentCliErrorMessage || null, actualParams.response || ''));
}

function isPropagatingFailure(error) {
    return !!(error && (error.fatalCliEnvironment || error.gitOperationsFailure || error.prCreationFailure || error.interruptedReset || error.quotaPark));
}

function resolveCustomParams(params, actualParams) {
    return (params.jobParams && params.jobParams.customParams) || actualParams.customParams;
}

function pushPartialWork(cliTool, config, ticketKey, plan) {
    cliTool({ command: 'git config user.name "' + config.git.authorName + '"' });
    cliTool({ command: 'git config user.email "' + config.git.authorEmail + '"' });
    cliTool({ command: 'git commit -m "' + configLoader.formatTemplate(config.formats.commitMessage.wip, {ticketKey: ticketKey}) + '"' });
    let pushCommand = 'git push -u origin ' + plan.branch;
    if (plan.force) {
        pushCommand += ' --force-with-lease';
    }
    cliTool({ command: pushCommand });
    wipSquash.squashTicketWipInPlace({ ticketKey: ticketKey, config: config, cliTool: cliTool, readFn: typeof file_read === 'function' ? file_read : null });
    console.log('✅ Pushed partial analysis to branch:', plan.branch);
}

function resetTicketForRetry(ticketKey, hasGitChanges, tracker, statuses, outage) {
    try {
        tracker.postComment(ticketKey, buildInterruptedComment(ticketKey, hasGitChanges, outage));
    } catch (e) {}

    try {
        tracker.moveToStatus(ticketKey, statuses.READY_FOR_DEVELOPMENT);
        console.log('✅ Moved', ticketKey, 'to Ready For Development for retry');
    } catch (e) {
        console.warn('Failed to move ticket to Ready For Development:', e);
    }
}

/**
 * gh-1188: the working-tree log line extracted from action.
 */
function logWorkingTreeCheck(hasGitChanges, hasResponseMd) {
    console.log('Working tree check: git changes present = ' + hasGitChanges +
        '; outputs/response.md = ' + (hasResponseMd ? 'present' : 'MISSING') +
        (hasGitChanges || hasResponseMd ? '' : ' — neither work nor a response; the agent produced nothing'));
}

/**
 * gh-1188: run-context resolution extracted from action — config, jira
 * section, scm, custom params, statuses and tracker (same construction
 * order as before).
 */
function resolveRunContext(params, actualParams) {
    var config = configLoader.loadProjectConfig(params.jobParams || params);
    var jiraConfig = config.jira;
    var scm = configLoader.createScm(config);
    var customParams = resolveCustomParams(params, actualParams);
    var statuses = resolveStatuses(customParams, jiraConfig && jiraConfig.statuses);
    var tracker = trackersModule.createTracker(config, customParams || {});
    return {
        config: config,
        jiraConfig: jiraConfig,
        scm: scm,
        customParams: customParams,
        statuses: statuses,
        tracker: tracker
    };
}

/**
 * gh-1188: Path 0 scan extracted from action — returns the
 * pr_already_open outcome when a PR exists for the branch, null otherwise.
 * A listing failure stays non-fatal (as before).
 */
function resolvePrAlreadyOpenOutcome(ticketKey, scm, expectedBranch, tracker, statuses, params) {
    try {
        const existingPr = findOpenPrForBranch(scm.listPrs('open'), expectedBranch);
        if (existingPr) {
            return handlePrAlreadyOpen(ticketKey, existingPr, tracker, statuses, params);
        }
    } catch (prCheckErr) {
        console.warn('Could not check existing PRs (non-fatal):', prCheckErr);
    }
    return null;
}

function postLedgerMarker(ticketKey, ledger, tracker) {
    try {
        tracker.postComment(ticketKey, tcMaintenanceLedger.buildLedgerMarker(ledger));
    } catch (e) {
        console.warn('Failed to post TC maintenance ledger marker (non-fatal):', e);
    }
}

function postDevClaimDigest(ticketKey, ledger, tracker) {
    try {
        tracker.postComment(ticketKey,
            '\uD83D\uDD0D Dev leg claims a test-side cause (gh-1329) — outputs/test_suspected.json routed to the TC maintenance ledger.\n\n' +
            tcMaintenanceLedger.buildDigestComment(ledger));
    } catch (e) {
        console.warn('Failed to post dev-claim digest (non-fatal):', e);
    }
}

function moveBugToTesting(ticketKey, jiraConfig, tracker) {
    try {
        tracker.moveToStatus(ticketKey, jiraConfig.statuses.IN_TESTING);
        console.log('✅ Moved', ticketKey, 'to', jiraConfig.statuses.IN_TESTING, '— verdict stays gated by its own oracle TC');
    } catch (e) {
        console.warn('Failed to move to In Testing:', e);
    }
}

function completeTestSuspectedPath(ticketKey, claim, tracker, jiraConfig, params, config) {
    var bookkeeping = bugBookkeeping.loadBugBookkeeping(tracker, ticketKey, params, config);
    var ledger = tcMaintenanceLedger.appendFinding(
        bookkeeping.ledger, tcMaintenanceLedger.findingFromDevClaim(claim));

    postLedgerMarker(ticketKey, ledger, tracker);
    postDevClaimDigest(ticketKey, ledger, tracker);
    moveBugToTesting(ticketKey, jiraConfig, tracker);

    removeLabels(ticketKey, params, tracker);
    return { success: true, path: 'test_suspected', ticketKey };
}

function isValidTestSuspectedClaim(claim) {
    return !!(claim && (claim.tcKey || claim.testCaseKey));
}

function resolveSpecialOutputPath(ticketKey, tracker, statuses, jiraConfig, params, config) {
    const blocked = readJson('outputs/blocked.json');
    if (blocked) {
        console.log('outputs/blocked.json found — bug cannot be fixed automatically');
        wipSquash.squashTicketWipInPlace({ ticketKey: ticketKey, config: config, cliTool: cli_execute_command, readFn: typeof file_read === 'function' ? file_read : null });
        return completeBlockedPath(ticketKey, blocked, isBlockedClaimVerified(), tracker, statuses, jiraConfig, params);
    }
    const alreadyFixed = readJson('outputs/already_fixed.json');
    if (alreadyFixed) {
        console.log('outputs/already_fixed.json found — bug already resolved in codebase');
        wipSquash.squashTicketWipInPlace({ ticketKey: ticketKey, config: config, cliTool: cli_execute_command, readFn: typeof file_read === 'function' ? file_read : null });
        return completeAlreadyFixedPath(ticketKey, alreadyFixed, hasCodeGraphUsage(), tracker, jiraConfig, params);
    }
    const testSuspected = readJson('outputs/test_suspected.json');
    if (testSuspected) {
        if (!isValidTestSuspectedClaim(testSuspected)) {
            console.warn('outputs/test_suspected.json rejected — no TC key in the claim; proceeding with the normal fix path');
        } else {
            console.log('outputs/test_suspected.json found — dev claims a test-side cause; routing to the TC maintenance ledger');
            wipSquash.squashTicketWipInPlace({ ticketKey: ticketKey, config: config, cliTool: cli_execute_command, readFn: typeof file_read === 'function' ? file_read : null });
            return completeTestSuspectedPath(ticketKey, testSuspected, tracker, jiraConfig, params, config);
        }
    }
    return null;
}

function recoverResponseMd(ticketKey, actualParams, params, customParams, expectedBranch) {
    const recovered = developTicket.recoverMissingResponse(
        ticketKey,
        customParams,
        actualParams.response || '',
        actualParams.currentCliHasFatalError === true,
        actualParams.currentCliErrorMessage || null,
        // gh-1087: context for the delegated quota gate — the park
        // labels the open PR and resolves jobParams (park label /
        // probe cadence config).
        quotaGateContextOf(actualParams, params, ticketKey, customParams, expectedBranch));
    return !!(recovered && recovered.trim());
}

/**
 * gh-1188: the action catch block extracted — marked failures
 * (fatal CLI environment, git-operations gh-683, PR-creation gh-729,
 * interrupted-reset gh-742, quota-park gh-1087) keep propagating so the RUN
 * is RED; everything else posts the error comment (best effort) and returns
 * the failure result.
 */
function handleActionError(error, params, tracker) {
    console.error('❌ Error in developBugAndCreatePR:', error);
    if (isPropagatingFailure(error)) {
        throw error;
    }
    try {
        const key = (params.ticket || (params.jobParams && params.jobParams.ticket) || {}).key;
        if (key) {
            tracker.postComment(key, commentMarkup.forTicket(key).h(3, '❌ Bug Development Error') + '\n\n' + commentMarkup.forTicket(key).code(error.toString())
            );
        }
    } catch (e) {}
    return { success: false, error: error.toString() };
}

function action(params) {
    var tracker = null;
    try {
        const actualParams = resolveActualParams(params);
        const ticketKey = actualParams.ticket.key;
        const ctx = resolveRunContext(params, actualParams);
        var config = ctx.config;
        tracker = ctx.tracker;

        console.log('=== Bug development post-action for', ticketKey, '===');

        // ── Path 0: PR already open — skip re-development ───────────────────
        // If a PR already exists for this ticket's branch, the previous run created
        // it but failed to move the ticket to In Review (e.g. was interrupted).
        // Move to In Review now and skip development entirely.
        const expectedBranch = configLoader.resolveBranchName(config, actualParams.ticket, 'development');

        // ── gh-1301 re-review: ask-mode probe runs BEFORE the pr-already-open
        // guard. A needs-input stop on a rework leg with an existing PR must
        // win — Path 0 returning first moved the ticket to In Review and
        // silently swallowed the reporter's question (no label, no green
        // needs-input outcome). The story leg's recovery checks askModeOutcome
        // before every terminal for the same reason; running ahead of the
        // gh-775 resume gate also means a bounded resume attempt is never
        // burned fighting an intentional ask stop.
        if (!readHasResponseMd(ticketKey) && needsInputCommon.hasNeedsInputFile(outputFiles)) {
            console.log('outputs/needs-input.md present — ask-mode leg: agent asked for missing inputs. No PR, no reset.');
            return completeNeedsInputPath(ticketKey, detectGitChanges(cli_execute_command), cli_execute_command, config, actualParams.ticket, tracker, params, expectedBranch);
        }

        // ── Path 0: PR already open — skip re-development ───────────────────
        // If a PR already exists for this ticket's branch, the previous run created
        // it but failed to move the ticket to In Review (e.g. was interrupted).
        // Move to In Review now and skip development entirely.
        const prOpenResult = resolvePrAlreadyOpenOutcome(ticketKey, ctx.scm, expectedBranch, tracker, ctx.statuses, params);
        if (prOpenResult) {
            return prOpenResult;
        }

        // ── Path 1: Blocked / Path 2: Already Fixed / Path 2b: Test Suspected ─
        const specialResult = resolveSpecialOutputPath(ticketKey, tracker, ctx.statuses, ctx.jiraConfig, params, config);
        if (specialResult) {
            return specialResult;
        }

        // ── Path 3: Normal Fix — code changes present ────────────────────────
        console.log('No special outputs found — proceeding with normal PR creation');

        // gh-729 (live fa gh-1197, run 37234028759): the job log went silent
        // between the staging check-ignore probes and the delegated
        // developTicketAndCreatePR call — 23s with no git add, no error, and
        // the leg still reported success with no PR. Every step below logs,
        // so a future stall in this window is diagnosable from the job log.
        console.log('Staging + status check: inspecting the working tree for agent changes...');

        // Before delegating, check if the CLI agent was interrupted (no response.md, no code changes).
        // If there ARE git changes (e.g. outputs/rca.md written) but no response.md, the agent
        // was interrupted mid-way. Push partial work and reset ticket for retry.
        // gh-1003: the staging + porcelain-status probe (with the gh-628 /
        // gh-683 / gh-1164 exclusion comments) lives in detectGitChanges.
        const hasGitChanges = detectGitChanges(cli_execute_command);

        let hasResponseMd = readHasResponseMd(ticketKey);

        logWorkingTreeCheck(hasGitChanges, hasResponseMd);

        // gh-775: ONE shared gate (developTicketAndCreatePR.recoverMissingResponse)
        // for every response.md-missing cold-reset site — the gating order (fatal
        // CLI/environment class FIRST: the resume never preempts it — AC6; then
        // exactly ONE bounded resume attempt; then the re-read) lives in exactly
        // one place. The bug leg passes its own CLI outcome signals so a fatally
        // broken environment (missing binary, unknown provider, exit 127) skips
        // the doomed attempt exactly like the story leg.
        if (!hasResponseMd) {
            hasResponseMd = recoverResponseMd(ticketKey, actualParams, params, ctx.customParams, expectedBranch);
        }

        // gh-1087 AC1: classify the leg's failure text BEFORE the interrupted
        // path decides — a hard quota failure parks the lane instead of
        // resetting for a guaranteed-fail retry (transient keeps gh-742).
        var quotaCls = quotaFailureClassificationOf(actualParams);

        // (gh-1301: the ask-mode probe moved ABOVE the pr-already-open guard —
        // an ask stop there must win; see the probe at the top of action().)

        if (!hasResponseMd) {
            // CLI agent did not finish (rate limit / crash). Push whatever partial work exists
            // (e.g. outputs/rca.md) and reset the ticket so SM can retry.
            // gh-1003: the partial-work push + comment + reset sequence lives
            // in completeInterruptedPath (planned by decidePartialPush).
            console.log('outputs/response.md missing — CLI agent was interrupted. Resetting ticket for retry.');
            return completeInterruptedPath(ticketKey, hasGitChanges, cli_execute_command, config, actualParams.ticket, tracker, ctx.statuses, params, ctx.scm, quotaCls);
        }

        const result = developTicket.action(params);

        // Always remove SM idempotency label — even on failure — to avoid permanent lock
        // (developTicketAndCreatePR doesn't know about SM labels)
        removeLabels(ticketKey, params, tracker);

        return result;

    } catch (error) {
        return handleActionError(error, params, tracker);
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        action,
        // gh-1003: pure helpers extracted from action — exported for direct
        // characterization tests.
        resolveActualParams,
        hasCodeGraphUsage,
        isCodeGraphRequired,
        isBlockedClaimVerified,
        findOpenPrForBranch,
        buildPrAlreadyOpenComment,
        buildBlockedComment,
        buildBlockedWithoutCodeGraphComment,
        buildAlreadyFixedComment,
        buildInterruptedComment,
        isMeaningfulStatusLine,
        detectGitChanges,
        decidePartialPush,
        isPropagatingFailure,
        resolveCustomParams,
        pushPartialWork,
        resetTicketForRetry,
        handlePrAlreadyOpen,
        completeBlockedPath,
        completeAlreadyFixedPath,
        completeInterruptedPath,
        // gh-1301: ask-mode outcome — exported for direct characterization tests.
        completeNeedsInputPath,
        // gh-1087: quota park path — exported for direct characterization tests.
        parkQuotaPath,
        // gh-1188: the PR park-label helper — exported for direct
        // characterization tests.
        parkLabelOpenPr,
        // gh-1188: step helpers extracted from action — exported for direct
        // characterization tests.
        readJson,
        logWorkingTreeCheck,
        resolveRunContext,
        resolvePrAlreadyOpenOutcome,
        resolveSpecialOutputPath,
        recoverResponseMd,
        handleActionError,
        pushPreservedAnalysisWork,
        executePartialPushPlan
    };
}
