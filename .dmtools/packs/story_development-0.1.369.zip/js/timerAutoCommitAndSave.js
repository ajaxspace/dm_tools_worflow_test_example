/**
 * Timer JS Action — Auto-commit, push, and save session artefacts
 *
 * Executed periodically (every timerIntervalSeconds) while CLI commands run.
 * Ensures code changes are never lost even if the runner crashes.
 *
 * Actions performed on each tick:
 * 1. If there are uncommitted changes in targetRepository workingDir → commit + push
 * 2. If there is accumulated CLI output → save a snapshot as a release asset
 *    (GitHub or GitLab, resolved from config.scm.provider / customParams.scmProvider)
 *
 * params available:
 *   params.currentCliOutput — accumulated CLI stdout so far
 *   params.jobParams.customParams — agent config customParams
 *   params.ticket — current ticket object (key, fields, etc.)
 *   params.jobParams.metadata.contextId — agent name (e.g. "sf_story_development")
 */

var releaseArtefacts = require('./common/releaseArtefacts.js');
var prHelper = require('./common/pullRequest.js');
var gitStaging = require('./common/gitStaging.js');
var mergeState = require('./common/mergeState.js');
var configLoader = require('./configLoader.js');

// Canonical copy (gh-823/gh-912): the warning:/note: line filter lives in
// common/pullRequest.js once — this delegate keeps every local call site.
function cleanCommandOutput(output) {
    return prHelper.cleanCommandOutput(output);
}

function resolveCustomParams(params) {
    return (params.jobParams && params.jobParams.customParams) ||
           params.customParams ||
           {};
}

function getTicketKey(params) {
    if (params.ticket && params.ticket.key) return params.ticket.key;
    if (params.ticketKey) return params.ticketKey;
    return null;
}

function getContextId(params) {
    var metadata = (params.jobParams && params.jobParams.metadata) || {};
    return metadata.contextId || 'unknown_agent';
}

/**
 * gh-798 (live fa PR #1420 rework leg, run 37828431528): is this push failure
 * a non-fast-forward rejection? Only THAT class self-heals (below) — auth,
 * network, and ref-lock failures are surfaced untouched. The git hint is
 * matched by SHAPE ('current branch is behind' — git's "Updates were
 * rejected because the tip of your current branch is behind its remote
 * counterpart"), never by the bare word or the short " is behind" phrase: a
 * hook/proxy message that happens to contain "behind" must not trigger a
 * heal (gh-798 review).
 */
function isNonFastForwardError(error) {
    var text = String((error && error.message) || error || '');
    return text.indexOf('non-fast-forward') !== -1 ||
        text.indexOf('[rejected]') !== -1 ||
        text.indexOf('fetch first') !== -1 ||
        text.indexOf('current branch is behind') !== -1;
}

/**
 * gh-798: the timer's bare `git push origin HEAD`, hardened. When the SM's
 * silent-update legitimately refreshes the branch mid-run (any residual race
 * around the in-flight-leg exclusion), the rejection must self-heal exactly
 * the way the agent manually recovered in the live incident: fetch the
 * branch, merge origin into it (merge-style — matching the SM's own
 * merge refreshes; a rebase would rewrite the leg's WIP commits), and retry
 * the push ONCE. Anything else surfaces honestly.
 *
 * `resolveBranchName` is consulted ONLY on the healing path (a clean push
 * pays no branch probe). A conflicted heal merge is ABORTED — a MERGE_HEAD
 * left behind would make every later timer tick skip (gh-761) and strand
 * conflict markers in the agent's working state mid-run.
 *
 * Returns { pushed: true, healed: false } on the plain push,
 * { pushed: true, healed: true } after a self-heal; throws when the push
 * cannot land (the caller logs the honest failure).
 */
function pushBranchWithSelfHeal(cmd, resolveBranchName) {
    try {
        cmd('git push origin HEAD');
        return { pushed: true, healed: false };
    } catch (pushError) {
        if (!isNonFastForwardError(pushError)) throw pushError;
        var branchName = '';
        try {
            branchName = String(resolveBranchName() || '').trim();
        } catch (eBranch) {
            branchName = '';
        }
        if (!branchName) throw pushError;
        console.warn('⏱️ timer: push rejected non-fast-forward — merging origin/' +
            branchName + ' and retrying once (gh-798 self-heal)');
        cmd('git -c fetch.recurseSubmodules=no fetch origin ' +
            branchName + ':refs/remotes/origin/' + branchName);
        try {
            cmd('git merge --no-edit origin/' + branchName);
        } catch (mergeError) {
            try { cmd('git merge --abort'); } catch (eAbort) { /* already clean */ }
            throw mergeError;
        }
        cmd('git push origin HEAD');
        return { pushed: true, healed: true };
    }
}

/**
 * Auto-commit and push any uncommitted changes in the target repo working dir.
 * Returns true if a commit was made.
 */
/**
 * The auto-save commit message: formats.commitMessage.autoSave from the project config (or the
 * customParams.autoSaveCommitMessage override), default "{ticketKey} WIP auto-save {timestamp}".
 * Never throws and never returns an empty message: a failure to load the config falls back to the default.
 */
function autoSaveMessage(ticketKey, timestamp, override, params) {
    var template = override;
    if (!template) {
        try {
            var cfg = configLoader.loadProjectConfig((params && params.jobParams) || params || {});
            template = cfg && cfg.formats && cfg.formats.commitMessage && cfg.formats.commitMessage.autoSave;
        } catch (e) {
            template = null;
        }
    }
    if (!template) template = DEFAULT_AUTOSAVE_TEMPLATE;
    var msg = configLoader.formatTemplate(String(template), { ticketKey: ticketKey, timestamp: timestamp });
    msg = String(msg).replace(/"/g, "'").replace(/\r?\n/g, ' ').trim();
    return msg || (ticketKey + ' WIP auto-save ' + timestamp);
}

var DEFAULT_AUTOSAVE_TEMPLATE = '{ticketKey} WIP auto-save {timestamp}';

/**
 * The working dir the timer operates on: the target repo checkout, or the job
 * directory when no targetRepository is configured. A missing config must
 * never silently disable crash-safety commits (dev legs ran for years without
 * targetRepository — the timer was a silent no-op there and kill-timeout runs
 * lost the workspace), so the fallback is loud.
 */
function resolveTimerWorkingDir(customParams) {
    var targetRepo = customParams.targetRepository || {};
    var workingDir = targetRepo.workingDir || '.';
    var warned = !targetRepo.workingDir;
    if (warned) {
        console.warn('⏱️ timer: targetRepository.workingDir not configured — falling back to the job directory');
    }
    return { targetRepo: targetRepo, workingDir: workingDir, warned: warned };
}

/**
 * Safety net: never auto-commit/push while sitting on the base branch
 * (develop/main/...). If setup failed to switch onto the ticket branch
 * (e.g. checkout error, missing PR), HEAD stays on baseBranch — pushing
 * WIP snapshots there would land straight in the mainline history instead
 * of the intended ticket branch. A failed branch probe skips the tick too.
 */
function baseBranchGuardSkips(targetRepo, workingDir) {
    if (!targetRepo.baseBranch) return false;
    var currentBranch;
    try {
        currentBranch = cli_execute_command({
            command: 'git rev-parse --abbrev-ref HEAD',
            workingDirectory: workingDir
        });
    } catch (e) {
        console.log('⏱️ timer: could not determine current branch, skipping:', e.toString().substring(0, 100));
        return true;
    }
    if (currentBranch && cleanCommandOutput(currentBranch) === targetRepo.baseBranch) {
        console.warn('⏱️ timer: HEAD is on base branch "' + targetRepo.baseBranch +
            '" — refusing to auto-commit/push (branch setup likely failed)');
        return true;
    }
    return false;
}

/**
 * gh-761: skip the tick while a merge is in progress. MERGE_HEAD present
 * means a conflicted merge of the base branch sits unconcluded in the
 * working tree (the rework setup leaves it there for the agent to
 * resolve; the agent's own merge of origin/main may be mid-conflict).
 * A blind `git add -A && git commit` here would stage the unmerged paths
 * — conflict markers and all — and FINALIZE that merge as a 'WIP
 * auto-save' commit pushed to origin: silent branch corruption. The probe
 * runs BEFORE the dirty-tree check (a mid-merge status is always dirty)
 * and must come after the base-branch guard, which cheaply rules out the
 * more dangerous wrong-branch case first. The next tick after the merge
 * concludes (or is aborted) resumes normal auto-saving; the session
 * artefact upload in action() is git-independent and still runs.
 */
function mergeInProgressSkips(workingDir) {
    var runInDir = function (command) {
        return cli_execute_command({ command: command, workingDirectory: workingDir });
    };
    if (!mergeState.isMergeInProgress(runInDir, workingDir)) {
        return false;
    }
    if (!mergeState.hasUnmergedPaths(runInDir, workingDir)) {
        return false;
    }
    console.warn('⏱️ timer: MERGE_HEAD exists with unmerged paths — merge in progress, skipping auto-commit/push this tick ' +
        '(a blind add/commit would finalize the conflicted merge and bake conflict markers into a WIP auto-save)');
    return true;
}

/** True when `git status --porcelain` reports anything (a failed probe reports nothing). */
function hasDirtyChanges(workingDir) {
    var statusOutput;
    try {
        statusOutput = cli_execute_command({
            command: 'git status --porcelain',
            workingDirectory: workingDir
        });
    } catch (e) {
        console.log('⏱️ timer: git status failed:', e.toString().substring(0, 100));
        return false;
    }
    return Boolean(statusOutput && statusOutput.trim());
}

/** The customParams.autoSaveCommitMessage override for autoSaveMessage (null when unset). */
function autoSaveCommitMessageOverride(customParams) {
    return customParams.autoSaveCommitMessage || null;
}

/**
 * Untrack machine-local runtime logs that older/poisoned branches may already
 * carry (gh-628: the timer itself swept .dmtools/credential-helper.log into
 * three commits on ai/gh-628). Pathspec exclusion cannot help a TRACKED file,
 * so they are removed from the index. Two plain commands (list tracked, then
 * rm) — no shell pipe, which the Java validator rejects (epam/dm.ai#679).
 * A cleanup failure never blocks the WIP save.
 */
function untrackRuntimeArtifactsSafe(workingDir) {
    try {
        gitStaging.untrackRuntimeArtifacts(function (command) {
            return cli_execute_command({ command: command, workingDirectory: workingDir });
        });
    } catch (cleanupErr) {
        console.log('⏱️ timer: session cache cleanup skipped:', cleanupErr.toString().substring(0, 100));
    }
}

/**
 * Stage everything except the machine-local runtime artifacts.
 * `:!factory-kit`: the factory workflow's nested machine-infra
 * repo (when a pin still lands it in the workspace) is a gitlink
 * a bare `git add -A` cannot stage — exit 128 kills the timer
 * (live: fa gh-1044 leg 2026-10-03, clip 1791017320716).
 * `:!.dmtools/...` runtime logs (gh-628): the machine's runtime
 * artifacts live INSIDE the committed .dmtools/ directory
 * (config.js, runners/), so the directory itself cannot be
 * ignored — the credential helper's serving trace, fa trace and
 * run logs, the watchdog stall capture and the session store
 * must be excluded by pathspec, exactly like copilot-sessions.
 * `.dmtools-session-output.log` is this timer's own CLI-stdout
 * snapshot at the job root — a crash mid-upload leaves it
 * behind, and the next broad add would commit the full session
 * log into the ticket branch. Shared canonical list:
 * js/common/gitStaging.js.
 * gh-683 (live fa run 37153405587 — this timer's add was the
 * FIRST casualty of git's ignored-pathspec guard): naming an
 * existing ignored-untracked path in a `:!` exclusion pathspec
 * fails the whole add. The check-ignore probe below drops the
 * exclusion for every path git already ignores, so the timer's
 * WIP save can never die on the guard again.
 * gh-1164 (live fa runs 37153882406 + 37220167230): `factory-kit`
 * must go through the SAME probe — appended statically, it kept
 * tripping the guard every 5 minutes for 40+ minutes whenever the
 * kit was materialized AND gitignored, and the dev agent's work
 * died uncommitted with the runner.
 * gh-1318: `input` + `outputs` ride the same probe — the tracker
 * regenerates both before every leg, so committing them bakes a
 * pre-answer ticket snapshot onto ai/<ticket> that either wins
 * over (checkoutBranch) or refuses (preCliDevelopmentSetup) the
 * next leg's fresh copy. Belt-and-suspenders beside the
 * .git/info/exclude seed: ignored repo → probe drops them
 * (gitignore owns it), unignored repo → the exclusion holds.
 */
function stageWorkingTree(workingDir) {
    try {
        cli_execute_command({
            command: 'git add -A -- ' + gitStaging.buildStagingPathspecs(function (args) {
                return cli_execute_command({
                    command: args.command,
                    workingDirectory: workingDir,
                    expectNonZeroExit: args.expectNonZeroExit
                });
            }, ['factory-kit', 'input', 'outputs']),
            workingDirectory: workingDir
        });
        return true;
    } catch (e) {
        console.error('⏱️ timer: git add failed:', e.toString().substring(0, 100));
        return false;
    }
}

/**
 * True when `HEAD` is already reachable from any remote-tracking ref (`origin/*`),
 * so amending it would rewrite already-pushed history (gh-1523).
 */
function isHeadOnRemoteBranch(workingDir) {
    try {
        var out = cleanCommandOutput(cli_execute_command({
            command: 'git branch -r --contains HEAD',
            workingDirectory: workingDir
        }) || '').trim();
        return out.length > 0;
    } catch (e) {
        return false;
    }
}

/**
 * True when HEAD is already an unpushed non-merge `WIP auto-save` commit
 * (gh-1501 / gh-1523). Once a WIP commit has been pushed to `origin/<branch>`,
 * subsequent timer ticks MUST create a new commit instead of amending it
 * locally and diverges-failing on push.
 */
function shouldAmendHeadWipCommit(workingDir) {
    try {
        var subj = cleanCommandOutput(cli_execute_command({
            command: 'git log -1 --no-merges --format=%s HEAD',
            workingDirectory: workingDir
        }) || '').trim();
        if (!/WIP auto-save/.test(subj)) return false;
        return !isHeadOnRemoteBranch(workingDir);
    } catch (e) {
        return false;
    }
}

/** Best-effort git author configuration in the timer working dir when config.git is present. */
function applyTimerGitAuthor(workingDir, gitCfg) {
    if (!gitCfg) return;
    if (gitCfg.authorName) {
        cli_execute_command({ command: 'git config user.name "' + gitCfg.authorName + '"', workingDirectory: workingDir });
    }
    if (gitCfg.authorEmail) {
        cli_execute_command({ command: 'git config user.email "' + gitCfg.authorEmail + '"', workingDirectory: workingDir });
    }
}

function configureTimerGitAuthor(workingDir, params) {
    try {
        var cfg = configLoader.loadProjectConfig((params && params.jobParams) || params || {});
        applyTimerGitAuthor(workingDir, cfg && cfg.git);
    } catch (e) {
        console.log('⏱️ timer: git author config skipped:', e.toString().substring(0, 100));
    }
}

/** Commit the staged tree (amending when HEAD is already a WIP auto-save commit). */
function commitWorkingTree(workingDir, commitMsg, amend) {
    try {
        var prefix = amend ? 'git commit --amend -m "' : 'git commit -m "';
        cli_execute_command({
            command: prefix + commitMsg + '"',
            workingDirectory: workingDir
        });
        return true;
    } catch (e) {
        // Could be "nothing to commit" after add
        console.log('⏱️ timer: git commit:', e.toString().substring(0, 100));
        return false;
    }
}

/** Push the WIP commit (with the gh-798 self-heal) and log the outcome. */
function pushAndLog(workingDir, commitMsg, amend) {
    try {
        pushBranchWithSelfHeal(function (command) {
            return cli_execute_command({
                command: (amend && command === 'git push origin HEAD') ? 'git push --force-with-lease origin HEAD' : command,
                workingDirectory: workingDir
            });
        }, function () {
            return cleanCommandOutput(cli_execute_command({
                command: 'git rev-parse --abbrev-ref HEAD',
                workingDirectory: workingDir
            }) || '');
        });
        console.log('⏱️ timer: ✅ auto-committed and pushed: ' + commitMsg);
        return true;
    } catch (e) {
        console.error('⏱️ timer: git push failed:', e.toString().substring(0, 100));
        return false;
    }
}

/**
 * Auto-commit and push any uncommitted changes in the target repo working dir.
 * Returns true if a commit was made.
 */
function autoCommitAndPush(customParams, ticketKey, params) {
    var repo = resolveTimerWorkingDir(customParams);
    if (baseBranchGuardSkips(repo.targetRepo, repo.workingDir)) return false;
    if (mergeInProgressSkips(repo.workingDir)) return false;
    if (!hasDirtyChanges(repo.workingDir)) return false;

    // There are changes — commit and push
    var timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    // agents#883: the message is a template like every other commit message (formats.commitMessage.autoSave in
    // the project config), so a repo whose commit-msg hook demands a tracker key can be satisfied. Default is
    // the previous text, byte for byte. Double quotes are dropped: the message is placed inside git commit -m "...".
    var commitMsg = autoSaveMessage(ticketKey, timestamp, autoSaveCommitMessageOverride(customParams), params);

    untrackRuntimeArtifactsSafe(repo.workingDir);
    if (!stageWorkingTree(repo.workingDir)) return false;
    configureTimerGitAuthor(repo.workingDir, params);
    var amend = shouldAmendHeadWipCommit(repo.workingDir);
    if (!commitWorkingTree(repo.workingDir, commitMsg, amend)) return false;
    return pushAndLog(repo.workingDir, commitMsg, amend);
}

/**
 * Save CLI output snapshot to releases as an artefact.
 * The asset name includes the agent contextId to distinguish between agents.
 *
 * Uses working-dir-relative paths (FileTools blocks /tmp/ as path traversal).
 * Uploads .log directly — no zip needed (timer doesn't inherit CLI_ALLOWED_COMMANDS,
 * so `zip` is not in whitelist; raw .log upload is simpler and sufficient).
 */
// ── gh-1229: saveSessionArtefact decomposed into small steps; behavior is
//    byte-identical to the previous inline flow. ──

/** cacheToReleases tag/name templates, when the timer is configured to publish. */
function releaseTemplatesOf(customParams) {
    return {
        tagTemplate: customParams.cacheToReleases && customParams.cacheToReleases.releaseTagTemplate,
        nameTemplate: customParams.cacheToReleases && customParams.cacheToReleases.releaseNameTemplate
    };
}

/** Write the wrapped snapshot; false (with the error logged) when the write fails. */
function writeSessionSnapshot(outputFile, snapshotHeader, currentCliOutput, snapshotFooter) {
    try {
        file_write({ path: outputFile, content: snapshotHeader + currentCliOutput + snapshotFooter });
        return true;
    } catch (e) {
        console.error('⏱️ timer: failed to write CLI output file:', e.toString().substring(0, 100));
        return false;
    }
}

/** Upload outcome is logged, never thrown — a failed save must not kill the timer. */
function reportSessionUpload(result, assetName, tag, scmProvider) {
    if (result.success) {
        console.log('⏱️ timer: ✅ session saved: ' + assetName + ' → ' + tag + ' (' + scmProvider + ')');
    } else {
        console.error('⏱️ timer: session upload failed:', String(result.error).substring(0, 150));
    }
}

function saveSessionArtefact(params, customParams, ticketKey, contextId, currentCliOutput) {
    var artefactRepo = releaseArtefacts.resolveArtefactRepository(customParams);
    if (!artefactRepo) {
        return;
    }

    if (!currentCliOutput || !currentCliOutput.trim()) {
        return;
    }

    var projectConfig = configLoader.loadProjectConfig(params.jobParams || params);
    var scmProvider = (projectConfig.scm && projectConfig.scm.provider) || 'github';

    var assetName = contextId + '-session.log';
    var templates = releaseTemplatesOf(customParams);
    var tag = releaseArtefacts.buildTag(ticketKey, templates.tagTemplate);
    var releaseConfig = { tagTemplate: templates.tagTemplate, nameTemplate: templates.nameTemplate };

    // Write to working dir (FileTools blocks /tmp/ paths)
    var outputFile = '.dmtools-session-output.log';

    var snapshotTimestamp = new Date().toISOString();
    var snapshotHeader = '=== ⏱️ TIMER SESSION SNAPSHOT START (saved at ' + snapshotTimestamp + ') ===\n' +
                         '=== This is a periodic snapshot of the running agent output, NOT a new agent run ===\n\n';
    var snapshotFooter = '\n\n=== ⏱️ TIMER SESSION SNAPSHOT END ===\n';

    if (!writeSessionSnapshot(outputFile, snapshotHeader, currentCliOutput, snapshotFooter)) {
        return;
    }

    // Upload .log directly to release (no zip, no CLI commands needed)
    var result = releaseArtefacts.uploadRawFile(
        artefactRepo.owner, artefactRepo.repo, ticketKey, releaseConfig, outputFile, assetName, scmProvider
    );
    reportSessionUpload(result, assetName, tag, scmProvider);

    // Cleanup
    try { file_delete({ path: outputFile }); } catch (e) { /* ignore */ }
}

/**
 * Main timer action entry point.
 */
function action(params) {
    var customParams = resolveCustomParams(params);
    var ticketKey = getTicketKey(params);
    var contextId = getContextId(params);
    var currentCliOutput = params.currentCliOutput || '';

    if (!ticketKey) {
        console.log('⏱️ timer: no ticketKey available, skipping');
        return;
    }

    // 1. Auto-commit and push changes
    autoCommitAndPush(customParams, ticketKey, params);

    // 2. Save currentCliOutput to releases as session artefact
    saveSessionArtefact(params, customParams, ticketKey, contextId, currentCliOutput);
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        action: action,
        autoCommitAndPush: autoCommitAndPush,
        autoSaveMessage: autoSaveMessage,
        pushBranchWithSelfHeal: pushBranchWithSelfHeal,
        isNonFastForwardError: isNonFastForwardError,
        resolveTimerWorkingDir: resolveTimerWorkingDir,
        baseBranchGuardSkips: baseBranchGuardSkips,
        mergeInProgressSkips: mergeInProgressSkips,
        hasDirtyChanges: hasDirtyChanges,
        autoSaveCommitMessageOverride: autoSaveCommitMessageOverride,
        saveSessionArtefact: saveSessionArtefact,
        releaseTemplatesOf: releaseTemplatesOf,
        shouldAmendHeadWipCommit: shouldAmendHeadWipCommit,
        isHeadOnRemoteBranch: isHeadOnRemoteBranch,
        configureTimerGitAuthor: configureTimerGitAuthor
    };
}
