var DEFAULT_MAX_ATTEMPTS = 2;

// gh-775: hard wall-clock cap for the bounded missing-response resume.
// 40 min by recommendation — must fit the job's remaining timeout budget;
// projects can tighten it via feedbackLoop.missingResponse.timeoutSeconds.
var DEFAULT_MISSING_RESPONSE_TIMEOUT_SECONDS = 2400;

// gh-775: dedicated attempt-marker stage so the bounded resume never shares
// (or consumes) the failure-recovery stages' attempt counters.
var MISSING_RESPONSE_STAGE = 'missing_response';

// gh-1121: backoff before the provider-outage resume. The chain just spent
// minutes answering 5xx/429 — an immediate resume would re-enter the same
// outage window. Default 90s; projects override via
// customParams.providerTransientBackoffSec.
var DEFAULT_PROVIDER_TRANSIENT_BACKOFF_SECONDS = 90;

function sanitizeId(value) {
    return String(value || 'unknown').replace(/[^A-Za-z0-9_.-]+/g, '_');
}

function writeFile(path, content) {
    file_write({ path: path, content: content });
}

function readFile(path) {
    try { return file_read({ path: path }); } catch (e) { return null; }
}

function runCommand(command, workingDir) {
    var args = { command: command };
    if (workingDir) args.workingDirectory = workingDir;
    return cli_execute_command(args);
}

function ensureFeedbackDir() {
    // mkdir is not in the cli_execute_command whitelist — wrap in bash -c.
    try { runCommand('bash -c "mkdir -p outputs/feedback"'); } catch (e) {}
}

function normalizeConfig(customParams, section) {
    var root = (customParams && customParams.feedbackLoop) || {};
    var scoped = (section && root[section] && typeof root[section] === 'object') ? root[section] : {};
    var merged = {};
    Object.keys(root).forEach(function(key) {
        if (typeof root[key] !== 'object' || Array.isArray(root[key])) merged[key] = root[key];
    });
    Object.keys(scoped).forEach(function(key) { merged[key] = scoped[key]; });
    return merged;
}

function isFeedbackEnabled(customParams, section) {
    var root = (customParams && customParams.feedbackLoop) || null;
    if (!root) return false;
    var scoped = (section && root[section] && typeof root[section] === 'object') ? root[section] : null;
    return root.enabled === true || (scoped && scoped.enabled === true);
}

function getAttempt(markerPath) {
    var raw = readFile(markerPath);
    var value = parseInt(raw || '0', 10);
    return isNaN(value) ? 0 : value;
}

function setAttempt(markerPath, attempt) {
    writeFile(markerPath, String(attempt));
}

function isNonRecoverable(errorText, config) {
    var text = String(errorText || '');
    var patterns = (config && config.nonRecoverablePatterns) || [
        'COPILOT_GITHUB_TOKEN',
        'GITHUB_TOKEN',
        'JIRA_API_TOKEN',
        'Bad credentials',
        'Resource not accessible by integration',
        'could not read Username',
        'Authentication failed',
        'refusing to merge unrelated histories',
        'No merge base found between HEAD and origin/'
    ];
    return patterns.some(function(pattern) {
        return text.indexOf(pattern) !== -1;
    });
}

function buildFeedbackPrompt(options) {
    return [
        'A previous automation step failed. Continue/resume the current task in the same repository and fix the root cause.',
        '',
        'Ticket: ' + (options.ticketKey || 'unknown'),
        'Stage: ' + (options.stage || 'unknown'),
        'Attempt: ' + (options.attempt || 1),
        '',
        'Error/output:',
        '```',
        String(options.error || '').substring(0, 12000),
        '```',
        '',
        'Instructions:',
        '- Inspect the current working tree and recent changes.',
        '- Fix the failure directly; do not revert unrelated user or automation changes.',
        '- Keep the implementation focused on the ticket and the failing gate/post-action.',
        '- Update outputs/response.md with what you changed and any validation you ran.',
        '- Do not push; the post-action will commit and push after you finish.'
    ].join('\n');
}

// gh-775: follow-up prompt for the bounded missing-response resume — the exact
// scenario this recovery exists for is a hung background verification child
// that stalled the session after the real work was done (live fa gh-1341).
// Kept inline like buildFeedbackPrompt (the prompts/ home variant would add a
// runtime file-read failure mode for no versioning benefit — this file IS the
// versioned home of the resume mechanics).
function buildMissingResponsePrompt(options) {
    options = options || {};
    return [
        'Your previous run finished its real work but was interrupted before outputs/response.md could be written — most likely a background verification job (test suite, coverage, build) hung and the session stalled watching it.',
        '',
        'Ticket: ' + (options.ticketKey || 'unknown'),
        '',
        'Resume and finish the task now:',
        '- Check running background jobs (bash_job status) and STOP any job with no progress: bash_job stop <id>.',
        '- Do NOT restart long verification runs. Note the unverified part in the deliverable (job id, command, last output tail) — validation CI on the pull request is the safety net.',
        '- Finish any remaining small steps, then write outputs/response.md (the deliverable the post-action expects) and end the turn.',
        '- Do not push; the post-action will commit and push after you finish.'
    ].join('\n');
}

// ── gh-1196: resumeAgent decomposed into pure single-purpose helpers ────────
// Behavior contract is unchanged (the characterization suites in
// test_feedbackLoop.js pin every branch); this section only splits the
// former monolith the same way gh-1079 split runConfiguredGates:
//   feedbackSection      — the section default ('postAction')
//   resumeEnabled        — the enablement gate (root/section switch + explicit false)
//   maxAttemptsFrom      — default → parse → validity (0 = unusable)
//   resumeBlocker        — the three early exits in contract order
//   resumeKey            — the sanitized <ticket>_<stage> marker key
//   feedbackMarkerPaths  — the attempt-marker + prompt-file paths
//   resumePromptFor      — override or the built feedback prompt
//   buildResumeCommand   — the run-agent.sh wrapper (+ the hard timeout wrap)
// Every exec/console/file call keeps its original position in the sequence.

function feedbackSection(options) {
    return options.section || 'postAction';
}

function resumeEnabled(customParams, section, config) {
    return isFeedbackEnabled(customParams, section) && config.enabled !== false;
}

function maxAttemptsFrom(config) {
    var maxAttempts = config.maxAttempts;
    if (maxAttempts === undefined || maxAttempts === null) maxAttempts = DEFAULT_MAX_ATTEMPTS;
    maxAttempts = parseInt(maxAttempts, 10);
    if (!maxAttempts || maxAttempts < 1) return 0;
    return maxAttempts;
}

// The early exits in contract order: disabled → maxAttempts unusable →
// non-recoverable error. Null = the resume may proceed.
function resumeBlocker(options, customParams, config, section) {
    if (!resumeEnabled(customParams, section, config)) {
        return { attempted: false, reason: 'disabled' };
    }
    if (!maxAttemptsFrom(config)) {
        return { attempted: false, reason: 'maxAttempts=0' };
    }
    if (isNonRecoverable(String(options.error || ''), config)) {
        return { attempted: false, reason: 'non-recoverable' };
    }
    return null;
}

function resumeKey(options) {
    return sanitizeId((options.ticketKey || 'unknown') + '_' + (options.stage || 'feedback'));
}

function feedbackMarkerPaths(key) {
    return {
        marker: 'outputs/feedback/' + key + '.attempt',
        prompt: 'outputs/feedback/' + key + '.md'
    };
}

// `buildFeedbackPrompt()` bakes in dev-flow assumptions ("do not push; the
// post-action will commit and push after you finish") that don't apply to
// every caller (e.g. a publish-only post-action that never pushes code).
// Callers with a different resume flow can pass `promptOverride` with the
// full prompt text instead — attempt tracking / non-recoverable-error
// detection / the `--continue` resume mechanics stay identical either way.
function resumePromptFor(options, errorText, attempt) {
    return options.promptOverride || buildFeedbackPrompt({
        ticketKey: options.ticketKey,
        stage: options.stage,
        attempt: attempt,
        error: errorText
    });
}

// gh-775: bounded resume — a hard wall-clock cap on the wrapper invocation so a
// hung provider session cannot hold the post-action (and the job's remaining
// timeout budget) hostage. `timeout -k 60 <N>` TERM-inates the wrapper after <N>
// seconds and KILLs it 60s later if TERM is ignored. The wrapper is entered
// through `bash` (cli_execute_command whitelists the command's FIRST token only;
// dev runners carry it via envVariables.CLI_ALLOWED_COMMANDS), so no new
// whitelist entry is needed.
function buildResumeCommand(config, promptPath, timeoutSeconds) {
    // Copilot CLI's `--continue` already means "resume the most recent session in this
    // directory" (no value needed); its own `-r, --resume[=value]` flag is a second,
    // mutually exclusive way to resume (by explicit id or an interactive picker when bare).
    // Passing both together is rejected outright: "error: option '-r, --resume[=value]'
    // cannot be used with option '--continue'" — which made every feedback-loop retry fail
    // deterministically before the agent ever got a chance to act on the new prompt.
    var resumeArgs = config.resumeArgs || '--continue';
    var command = 'bash agents/scripts/run-agent.sh ' + resumeArgs + ' ' + promptPath;
    var timeout = parseInt(timeoutSeconds, 10);
    if (timeout && timeout > 0) {
        command = 'bash -c "timeout -k 60 ' + timeout + ' ' + command + '"';
    }
    return command;
}

function resumeLogLine(stage, attempt, maxAttempts) {
    return 'Feedback loop: resuming agent for ' + (stage || 'failure') +
        ' attempt ' + attempt + '/' + maxAttempts;
}

function resumeAgent(options) {
    options = options || {};
    var customParams = options.customParams || {};
    var section = feedbackSection(options);
    var config = normalizeConfig(customParams, section);
    var blocker = resumeBlocker(options, customParams, config, section);
    if (blocker) return blocker;

    var maxAttempts = maxAttemptsFrom(config);
    ensureFeedbackDir();
    var paths = feedbackMarkerPaths(resumeKey(options));
    var attempt = getAttempt(paths.marker);
    if (attempt >= maxAttempts) {
        return { attempted: false, reason: 'attempts-exhausted', attempts: attempt };
    }

    attempt += 1;
    setAttempt(paths.marker, attempt);
    writeFile(paths.prompt, resumePromptFor(options, String(options.error || ''), attempt));
    console.log(resumeLogLine(options.stage, attempt, maxAttempts));
    runCommand(buildResumeCommand(config, paths.prompt, options.timeoutSeconds));
    return { attempted: true, attempts: attempt, promptPath: paths.prompt };
}

// ── gh-775: ONE bounded resume for a missing deliverable ────────────────────
// A dev agent can finish all real work and still lose the leg to a HUNG
// background verification job: the post-action finds outputs/response.md
// missing and cold-resets a session that was one "write the deliverable" step
// away from done (live fa gh-1341, run 37521704313). Before that cold reset,
// the dev post-action makes exactly ONE bounded resume attempt so the
// still-resumable session can finish and land the deliverable.
//
// Contract:
// - gated on the same feedback-loop enablement switch as every other resume
//   path (root `enabled` or a dedicated `missingResponse.enabled`), with a
//   section-level `enabled: false` winning over the root switch;
// - exactly ONE attempt per leg (own `missing_response` attempt marker —
//   multi-resume retries are a non-goal by design);
// - the wrapper invocation is hard-capped (timeout -k 60 <timeoutSeconds>,
//   default 2400s = 40 min; configurable via
//   feedbackLoop.missingResponse.timeoutSeconds);
// - a failed/timed-out wrapper invocation is a resume FAILURE, not a crash:
//   it is returned (attempted: true, failed: true) so the caller can re-check
//   the deliverable and fall back to the EXISTING cold reset verbatim.
function missingResponseScoped(root) {
    return (root.missingResponse && typeof root.missingResponse === 'object') ? root.missingResponse : {};
}

// The two opt-outs in contract order: the section-level switch wins over
// everything (even an outage-forced resume); the generic feedback-loop
// enablement switch applies unless the caller forces the resume.
function missingResponseDisabled(scoped, options, customParams) {
    if (scoped.enabled === false) {
        return true;
    }
    return !options.force && !isFeedbackEnabled(customParams, 'missingResponse');
}

function missingResponseTimeoutSeconds(scoped) {
    var timeoutSeconds = parseInt(scoped.timeoutSeconds, 10);
    if (!timeoutSeconds || timeoutSeconds < 1) {
        return DEFAULT_MISSING_RESPONSE_TIMEOUT_SECONDS;
    }
    return timeoutSeconds;
}

// The resumeAgent invocation for the missing-deliverable resume: exactly one
// attempt for the dedicated stage, the caller's error text (or the built
// follow-up prompt when no override is supplied) and the hard timeout cap.
function missingResponseResumeOptions(options, forcedCustomParams, timeoutSeconds) {
    return {
        ticketKey: options.ticketKey,
        customParams: forcedCustomParams,
        section: 'missingResponse',
        stage: MISSING_RESPONSE_STAGE,
        error: options.error || '',
        promptOverride: options.promptOverride || buildMissingResponsePrompt({
            ticketKey: options.ticketKey
        }),
        timeoutSeconds: timeoutSeconds
    };
}

function resumeOnceForMissingResponse(options) {
    options = options || {};
    var customParams = options.customParams || {};
    var root = customParams.feedbackLoop || {};
    var scoped = missingResponseScoped(root);
    if (missingResponseDisabled(scoped, options, customParams)) {
        return { attempted: false, reason: 'disabled' };
    }

    // gh-1121: the provider-outage resume bypasses the GENERIC enablement
    // flag (options.force) — an outage that killed the leg mid-flight must
    // not depend on feedbackLoop being configured. An explicit
    // missingResponse.enabled=false still opts the project out.

    var timeoutSeconds = missingResponseTimeoutSeconds(scoped);

    // Force exactly one attempt for this stage regardless of the inherited
    // root maxAttempts — gh-775 is explicit: no multi-resume retries.
    var forced = forcedResumeParams(customParams, root, scoped);

    try {
        return resumeAgent(missingResponseResumeOptions(options, forced, timeoutSeconds));
    } catch (e) {
        console.warn('Bounded resume for missing outputs/response.md failed/timed out:', e);
        return { attempted: true, failed: true, error: errorTextOf(e) };
    }
}

// gh-775: exactly one attempt for the missingResponse stage regardless of the
// inherited root maxAttempts — clone customParams with the scoped
// missingResponse config forced on (enabled: true, maxAttempts: 1). Split out
// of resumeOnceForMissingResponse to keep it under the CRAP ratchet baseline.
function forcedResumeParams(customParams, root, scoped) {
    var forced = {};
    for (var key in customParams) {
        if (customParams.hasOwnProperty(key)) forced[key] = customParams[key];
    }
    forced.feedbackLoop = Object.assign({}, root, {
        missingResponse: Object.assign({}, scoped, { enabled: true, maxAttempts: 1 })
    });
    return forced;
}

// ── gh-1121: ONE bounded resume for a whole-provider-chain outage ───────────
// Live fa gh-1112 (run 39315836954, 2026-10-19): zai/glm-5.3-flash answered
// 500 ×3, kimi-for-coding hit 429 ×12 → "Provider chain exhausted: 2 of 2".
// The dev leg discarded 97k prompt tokens of real work and cold-reset into
// the same outage. Before that cold reset, the classified outage gets ONE
// resume of the persisted fa session (run-agent.sh re-invoked; the fa
// provider resume-or-creates the deterministic --session):
//
// - a configurable backoff (customParams.providerTransientBackoffSec, default
//   90s) runs first so the resume does not re-enter the same outage window;
//   the sleep goes through `bash -c` — already whitelisted for the wrapper —
//   so no new CLI_ALLOWED_COMMANDS entry is needed;
// - the generic feedback-loop enablement flag is IGNORED (the outage resume
//   is the recovery for a leg the provider chain killed — it cannot depend
//   on the project having opted into feedbackLoop); an explicit
//   missingResponse.enabled=false still opts out;
// - the same missing_response attempt marker as resumeOnceForMissingResponse
//   enforces at-most-once per leg (I2).
function providerTransientBackoffSeconds(customParams) {
    var n = parseInt(customParams && customParams.providerTransientBackoffSec, 10);
    return (n > 0) ? n : DEFAULT_PROVIDER_TRANSIENT_BACKOFF_SECONDS;
}

// Follow-up prompt for the outage resume. Unlike the gh-775 hung-job prompt,
// the session here died from transient provider errors mid-run — the agent
// must pick up where it stopped, not diagnose a hung child.
function buildProviderOutageResumePrompt(options) {
    options = options || {};
    return [
        'Your previous run was interrupted by a transient provider outage — every provider in the chain answered transient errors (HTTP 5xx / 429 / network) and the CLI exited before the task was finished. The outage window has passed and the persisted session was restored for this resume.',
        '',
        'Ticket: ' + (options.ticketKey || 'unknown'),
        '',
        'Resume the task now:',
        '- Continue exactly where the previous run left off — do NOT restart completed steps from scratch.',
        '- If a background job from the previous run is stuck, stop it (bash_job stop <id>) instead of waiting on it.',
        '- Finish the remaining work, then write outputs/response.md (the deliverable the post-action expects) and end the turn.',
        '- Do not push; the post-action will commit and push after you finish.'
    ].join('\n');
}

// gh-1121: the explicit section-level opt-out — checked BEFORE the backoff
// sleep so a project that disabled the missingResponse resume never pays the
// wait either. The generic feedbackLoop flag is deliberately NOT consulted.
function providerOutageResumeOptedOut(customParams) {
    var root = (customParams && customParams.feedbackLoop) || {};
    var scoped = (root.missingResponse && typeof root.missingResponse === 'object') ? root.missingResponse : {};
    return scoped.enabled === false;
}

function resumeOnceForProviderOutage(options) {
    options = options || {};
    var customParams = options.customParams || {};
    if (providerOutageResumeOptedOut(customParams)) {
        return { attempted: false, reason: 'disabled' };
    }
    var backoff = providerTransientBackoffSeconds(customParams);
    console.log('⏸️ Provider chain outage (transient 5xx/429/network failures) — backing off ' + backoff + 's before the bounded resume of the persisted session…');
    runCommand('bash -c "sleep ' + backoff + '"');
    return resumeOnceForMissingResponse({
        ticketKey: options.ticketKey,
        customParams: customParams,
        error: options.error || '',
        promptOverride: options.promptOverride || buildProviderOutageResumePrompt({
            ticketKey: options.ticketKey
        }),
        timeoutSeconds: options.timeoutSeconds,
        force: true
    });
}

function getConfiguredGates(customParams, section, legacyKey) {
    var config = normalizeConfig(customParams || {}, section);
    var gates = config.gates || config[section] || ((customParams && customParams[legacyKey || section]) || []);
    return Array.isArray(gates) ? gates : [];
}

// ── gh-1079: runConfiguredGates decomposed into pure helpers ────────────────
// Behavior contract is unchanged (the characterization suite in
// test_feedbackLoop.js pins every branch); this section only splits the
// former 37-complexity monolith into single-purpose pieces:
//   resolveGateEntry   — skip rules + name/command/workingDir/maxAttempts
//   runGateAttempt     — one console.log + runCommand attempt
//   classifyGateFailure— exhausted? resume? return-after-resume? retry?
//   gateExhaustedOutcome / recordNonBlockingGateFailure / gateFailureResult
//                      — the three failure exits (non-blocking record,
//                        blocking bubble, resumeAttempted bubble)
// Every exec/console call keeps its original position in the sequence.

function errorTextOf(error) {
    return error && error.message ? error.message : String(error);
}

function gateRunnable(gate) {
    return !!gate && gate.enabled !== false;
}

function gateCommand(gate, ticketKey) {
    return gate.command ? String(gate.command).replace(/\{ticketKey\}/g, ticketKey || '') : null;
}

function gateWorkingDir(gate, options, config) {
    return gate.workingDir || options.workingDir || config.workingDir || null;
}

function gateMaxAttempts(gate) {
    var maxAttempts = gate.maxAttempts;
    if (maxAttempts === undefined || maxAttempts === null) maxAttempts = DEFAULT_MAX_ATTEMPTS;
    return parseInt(maxAttempts, 10) || 0;
}

// Exact key order of the pre-refactor failure results (success, failedGate,
// error, [resumeAttempted], results, nonBlockingFailures) — keep it stable.
function gateFailureResult(name, errorText, ctx, resumeAttempted) {
    return resumeAttempted ? {
        success: false,
        failedGate: name,
        error: errorText,
        resumeAttempted: true,
        results: ctx.results,
        nonBlockingFailures: ctx.nonBlockingFailures
    } : {
        success: false,
        failedGate: name,
        error: errorText,
        results: ctx.results,
        nonBlockingFailures: ctx.nonBlockingFailures
    };
}

function recordNonBlockingGateFailure(name, attempts, errorText, ctx, warnWhy) {
    console.warn('⚠️ Non-blocking ' + ctx.gateType + ' "' + name + '" failed ' + warnWhy +
        ' — continuing without blocking: ' + errorText);
    ctx.results.push({ name: name, success: false, attempts: attempts, error: errorText, blocking: false });
    ctx.nonBlockingFailures.push({ name: name, error: errorText });
}

// A gate that gave up: blocking gates bubble the failure result, non-blocking
// gates are recorded and the run moves to the next gate ('next-gate').
function gateExhaustedOutcome(gate, name, attempts, errorText, ctx, warnWhy) {
    if (gate.blocking !== false) return gateFailureResult(name, errorText, ctx, false);
    recordNonBlockingGateFailure(name, attempts, errorText, ctx, warnWhy);
    return 'next-gate';
}

function gateFeedbackConfig(section, gate, maxAttempts) {
    var feedbackLoopConfig = { feedbackLoop: {} };
    feedbackLoopConfig.feedbackLoop[section] = {
        enabled: true,
        maxAttempts: maxAttempts,
        resumeArgs: gate.resumeArgs || undefined,
        nonRecoverablePatterns: gate.nonRecoverablePatterns || undefined
    };
    return feedbackLoopConfig;
}

function gateResumeOptions(ctx, gate, name, command, workingDir, maxAttempts, errorText) {
    return {
        ticketKey: ctx.options.ticketKey,
        customParams: gateFeedbackConfig(ctx.section, gate, maxAttempts),
        section: ctx.section,
        stage: ctx.stagePrefix + '_' + name,
        error: 'Command failed: ' + command +
            (workingDir ? '\nWorking directory: ' + workingDir : '') +
            '\n\n' + errorText
    };
}

function gateWantsReturnAfterResume(ctx, gate) {
    return !!(ctx.options.returnAfterResume || ctx.config.returnAfterResume || gate.returnAfterResume);
}

// Outcome protocol: 'retry' → run the command again; 'next-gate' → give up on
// this gate without failing the run (non-blocking); object → bubble the
// failure result to the caller.
function classifyGateFailure(gate, entry, attempts, error, ctx) {
    var errorText = errorTextOf(error);
    if (attempts > entry.maxAttempts || gate.retryWithAgent === false) {
        return gateExhaustedOutcome(gate, entry.name, attempts, errorText, ctx, 'after ' + attempts + ' attempt(s)');
    }
    var resume = resumeAgent(gateResumeOptions(ctx, gate, entry.name, entry.command,
        entry.workingDir, entry.maxAttempts, errorText));
    if (!resume.attempted) {
        return gateExhaustedOutcome(gate, entry.name, attempts, errorText, ctx, '(no resume attempted)');
    }
    if (gateWantsReturnAfterResume(ctx, gate)) {
        return gateFailureResult(entry.name, errorText, ctx, true);
    }
    return 'retry';
}

function runGateAttempt(gate, entry, attempts, ctx) {
    try {
        console.log('Running ' + ctx.gateType + ' "' + entry.name + '": ' + entry.command);
        var output = runCommand(entry.command, entry.workingDir) || '';
        ctx.results.push({ name: entry.name, success: true, attempts: attempts, output: output });
        return true;
    } catch (e) {
        return classifyGateFailure(gate, entry, attempts, e, ctx);
    }
}

function resolveGateEntry(gate, index, ctx) {
    if (!gateRunnable(gate)) return null;
    var command = gateCommand(gate, ctx.options.ticketKey);
    if (!command) return null;
    return {
        name: gate.name || ('gate_' + (index + 1)),
        command: command,
        workingDir: gateWorkingDir(gate, ctx.options, ctx.config),
        maxAttempts: gateMaxAttempts(gate)
    };
}

function runGate(gate, index, ctx) {
    var entry = resolveGateEntry(gate, index, ctx);
    if (!entry) return null;
    var attempts = 0;
    while (true) {
        attempts += 1;
        var outcome = runGateAttempt(gate, entry, attempts, ctx);
        if (outcome === 'retry') continue;
        if (outcome === 'next-gate') return null;
        return outcome === true ? null : outcome;
    }
}

function gateSection(options, section) {
    return options.section || section;
}

function runGateContext(options, section, stagePrefix) {
    var customParams = options.customParams || {};
    return {
        options: options,
        section: section,
        stagePrefix: stagePrefix,
        gateType: section === 'policyGates' ? 'policy gate' : 'quality gate',
        config: normalizeConfig(customParams, gateSection(options, section)),
        results: [],
        nonBlockingFailures: []
    };
}

function runConfiguredGates(options, section, stagePrefix) {
    options = options || {};
    section = section || 'qualityGates';
    stagePrefix = stagePrefix || 'quality_gate';
    var ctx = runGateContext(options, section, stagePrefix);
    var gates = getConfiguredGates(options.customParams || {}, gateSection(options, section), section);
    for (var i = 0; i < gates.length; i++) {
        var outcome = runGate(gates[i], i, ctx);
        if (outcome) return outcome;
    }
    return { success: true, results: ctx.results, nonBlockingFailures: ctx.nonBlockingFailures };
}

function runQualityGates(options) {
    return runConfiguredGates(options || {}, 'qualityGates', 'quality_gate');
}

function runPolicyGates(options) {
    return runConfiguredGates(options || {}, 'policyGates', 'policy_gate');
}

function runPostPublishGates(options) {
    options = options || {};
    options.returnAfterResume = options.returnAfterResume !== false;
    return runConfiguredGates(options, 'postPublishGates', 'post_publish_gate');
}

module.exports = {
    DEFAULT_MAX_ATTEMPTS: DEFAULT_MAX_ATTEMPTS,
    DEFAULT_MISSING_RESPONSE_TIMEOUT_SECONDS: DEFAULT_MISSING_RESPONSE_TIMEOUT_SECONDS,
    DEFAULT_PROVIDER_TRANSIENT_BACKOFF_SECONDS: DEFAULT_PROVIDER_TRANSIENT_BACKOFF_SECONDS,
    MISSING_RESPONSE_STAGE: MISSING_RESPONSE_STAGE,
    resumeAgent: resumeAgent,
    resumeOnceForMissingResponse: resumeOnceForMissingResponse,
    // gh-122: extracted missingResponse helpers, exported for unit tests.
    missingResponseScoped: missingResponseScoped,
    missingResponseDisabled: missingResponseDisabled,
    missingResponseTimeoutSeconds: missingResponseTimeoutSeconds,
    missingResponseResumeOptions: missingResponseResumeOptions,
    resumeOnceForProviderOutage: resumeOnceForProviderOutage,
    providerTransientBackoffSeconds: providerTransientBackoffSeconds,
    buildFeedbackPrompt: buildFeedbackPrompt,
    buildMissingResponsePrompt: buildMissingResponsePrompt,
    buildProviderOutageResumePrompt: buildProviderOutageResumePrompt,
    runConfiguredGates: runConfiguredGates,
    runQualityGates: runQualityGates,
    runPolicyGates: runPolicyGates,
    runPostPublishGates: runPostPublishGates,
    normalizeConfig: normalizeConfig,
    isFeedbackEnabled: isFeedbackEnabled,
    sanitizeId: sanitizeId,
    getConfiguredGates: getConfiguredGates,
    feedbackSection: feedbackSection,
    resumeEnabled: resumeEnabled,
    maxAttemptsFrom: maxAttemptsFrom,
    resumeBlocker: resumeBlocker,
    resumeKey: resumeKey,
    feedbackMarkerPaths: feedbackMarkerPaths,
    resumePromptFor: resumePromptFor,
    buildResumeCommand: buildResumeCommand,
    resumeLogLine: resumeLogLine,
    errorTextOf: errorTextOf,
    gateRunnable: gateRunnable,
    gateCommand: gateCommand,
    gateWorkingDir: gateWorkingDir,
    gateMaxAttempts: gateMaxAttempts,
    gateFailureResult: gateFailureResult,
    gateFeedbackConfig: gateFeedbackConfig,
    gateResumeOptions: gateResumeOptions,
    gateWantsReturnAfterResume: gateWantsReturnAfterResume,
    classifyGateFailure: classifyGateFailure,
    resolveGateEntry: resolveGateEntry,
    runGate: runGate,
    gateSection: gateSection,
    runGateContext: runGateContext
};
