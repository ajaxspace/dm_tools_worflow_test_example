/**
 * Common Jira Helper Functions
 * Shared utilities for Jira ticket operations
 */

const { STATUSES, LABELS } = require('../config.js');

// gh-823: required at LOAD TIME — a deferred (in-function) require resolves
// against the pack's js/ root only at runtime, so the lazy
// `require('./trackers.js')` fallbacks could never fire in a pack ("Failed
// to require module: ./trackers.js"). Load-time requires resolve
// file-relative and dmtools compile discovers them for the pack closure.
const trackersModule = require('./trackers.js');
var configLoader = null;
try { configLoader = require('../configLoader.js'); } catch (e) {}

function _loadHelperConfig() {
    return configLoader ? configLoader.loadProjectConfig({}) : null;
}

function resolveDefaultConfig(config) {
    return config || _loadHelperConfig();
}

/**
 * Assign ticket to initiator and move to "In Review" status with AI-generated label
 * This is the common post-processing logic used by multiple agents
 * 
 * @param {string} ticketKey - The Jira ticket key
 * @param {string} initiatorId - Account ID of the person to assign the ticket to
 * @param {string} wipLabel - Optional WIP label to remove after processing
 * @returns {Object} Result object with success status and message
 */
function assignForReview(ticketKey, initiatorId, wipLabel, targetStatus, tracker, config) {
    const statusName = targetStatus || STATUSES.IN_REVIEW;
    try {
        const t = tracker || trackersModule.createTracker(resolveDefaultConfig(config), {});
        return t.assignForReview(ticketKey, initiatorId, wipLabel, statusName);
    } catch (error) {
        console.error("❌ Error in assignForReview:", error);
        return {
            success: false,
            error: error.toString()
        };
    }
}

/**
 * Extract ticket key from Jira API response
/**
 * Extracted ticket key from a Jira API response — the canonical
 * implementation lives in trackers.js (gh-1248: one copy; this module
 * already holds the trackers reference).
 *
 * @param {string|Object} result - Jira API response
 * @returns {string|null} Extracted ticket key or null if not found
 */
function extractTicketKey(result) {
    return trackersModule.extractTicketKey(result);
}

/**
 * Set priority on a Jira ticket using the appropriate API
 * 
 * @param {string} ticketKey - The Jira ticket key
 * @param {string} priority - Priority name (e.g., 'Low', 'Medium', 'High')
 * @returns {boolean} True if successful, false otherwise
 */
function setTicketPriority(ticketKey, priority, tracker, config) {
    if (!ticketKey || !priority) {
        return false;
    }
    
    try {
        const t = tracker || trackersModule.createTracker(resolveDefaultConfig(config), {});
        t.setPriority(ticketKey, priority);
        console.log('Set priority ' + priority + ' on ticket ' + ticketKey);
        return true;
    } catch (priorityError) {
        console.error('Failed to set priority on ticket ' + ticketKey + ':', priorityError);
        return false;
    }
}

// Export functions for use by other modules
module.exports = {
    assignForReview,
    extractTicketKey,
    setTicketPriority
};

