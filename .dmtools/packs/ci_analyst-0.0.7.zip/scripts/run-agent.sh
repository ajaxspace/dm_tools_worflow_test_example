#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Ensure Node/npm/npx are on PATH even in non-interactive shells ───────────
# Several providers below shell out to `npx @github/copilot@...`/`npx
# @anthropic-ai/claude-code` etc. when the CLI binary itself isn't globally
# installed. Node is typically managed by nvm, and nvm only auto-loads via
# ~/.bashrc — but ~/.bashrc's very first lines ("If not running
# interactively, don't do anything") make it a no-op for any NON-interactive
# shell, including `bash -lc "..."` (which is exactly how dmtools/Java spawns
# this script via ProcessBuilder, and how run-teammate-local.sh/CI invoke it
# too). Without this, every `npx ...` call fails outright with
# "npx: command not found" (exit 127) — but the surrounding Teammate job
# still reports success and its postJSAction still advances the ticket
# (labels + status change), producing a "completed" run that silently wrote
# NO content at all (see e.g. agents/js/assignForSolutionArchitecture.js).
# Guarded on `command -v npx` so this is a fast no-op once Node is already
# resolvable (global install, PATH already exporting nvm's bin dir, etc).
if ! command -v npx >/dev/null 2>&1; then
  export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
  if [ -s "${NVM_DIR}/nvm.sh" ]; then
    # shellcheck source=/dev/null
    \. "${NVM_DIR}/nvm.sh" --no-use
    nvm use default >/dev/null 2>&1 || nvm use node >/dev/null 2>&1 || true
  fi
fi

# Load shared helpers and provider implementations.
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/_common.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/claude.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/codemie.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/copilot.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/fa.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/kimi.sh"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/providers/cursor.sh"

usage() {
  cat <<EOF
Usage: $(basename "$0") "prompt"

Runs the configured AI agent with the provided prompt.
Provider is controlled by AI_AGENT_PROVIDER environment variable (default: cursor).

Providers:
  cursor       - Uses cursor-agent (default)
  claude-code  - Uses Claude Code CLI via Bedrock proxy (ANTHROPIC_BASE_URL + ANTHROPIC_API_KEY)
  codemie      - Uses codemie-claude
  copilot      - Uses GitHub Copilot CLI (npx @github/copilot)
  fa           - Uses the Fa CLI (fa); requires FA_PROVIDER_TYPE +
                 FA_PROVIDER_MODEL, optional FA_PROVIDER_BASE_URL and
                 FA_PROVIDER_API_KEY
  kimi         - Uses Kimi Code CLI (kimi)

Example:
  $(basename "$0") "process the input folder"

Notes:
  - Provide the prompt as a single argument
  - Extra arguments before the prompt are passed through to the agent (cursor and codemie)
  - Useful for resume: $(basename "$0") --continue "fix the push error"
    (do NOT combine with --resume: Copilot CLI rejects --continue + --resume together)
  - For codemie: requires CODEMIE_API_KEY and CODEMIE_BASE_URL environment variables
  - For copilot: requires COPILOT_GITHUB_TOKEN or GITHUB_TOKEN environment variable
  - For cursor: optional CURSOR_MODEL env var (default: auto)
  - For kimi: requires KIMI_API_KEY environment variable unless authenticated via OAuth;
              optional KIMI_BASE_URL and KIMI_MODEL
  - Final response is written to outputs/response.md
EOF
}

if [ $# -lt 1 ]; then
  usage
  exit 1
fi

# --skip: print prompt and exit without running any agent (for post-action testing)
for arg in "$@"; do
  if [ "$arg" = "--skip" ]; then
    PROMPT_FILE="${!#}"
    echo "=== --skip mode: printing prompt ==="
    echo ""
    cat "$PROMPT_FILE"
    echo ""
    echo "=== skipped agent execution ==="
    exit 0
  fi
done

# Load dmtools.env if exists (for local runs)
# `while IFS='=' read -r k v; ... export "${k}=${v}"` (matching
# run-teammate-local.sh's loader) instead of `source <(grep ...)`: `source`
# executes each line as a shell command, so any UNQUOTED value containing
# spaces (e.g. `JIRA_EXTRA_FIELDS=Acceptance criteria,Solution,...`) is
# parsed as `KEY=firstword secondword...` — a command invocation, not an
# assignment — which either errors ("command not found") or, worse, silently
# leaves that var (and, depending on shell/error-handling quirks, everything
# defined further down the file) unset. Splitting on the first '=' via `read`
# preserves the rest of the line — spaces included — as one literal value,
# with no shell re-evaluation.
if [ -f "dmtools.env" ]; then
  echo "Loading environment from dmtools.env"
  while IFS='=' read -r k v; do
    [[ "${k}" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
    export "${k}=${v}"
  done < <(grep -E '^[A-Za-z_][A-Za-z0-9_]*=' dmtools.env)
fi

# Extract prompt (last argument).
# When cliPrompt is used, DMTools passes the prompt as a temp file path — read it if so.
PROMPT_ARG="${!#}"
PROMPT_SOURCE="inline-argument"

if [ -f "$PROMPT_ARG" ]; then
  PROMPT="$(cat "$PROMPT_ARG")"
  PROMPT_SOURCE="$PROMPT_ARG"
else
  PROMPT="$PROMPT_ARG"
fi

if [ -z "$PROMPT" ]; then
  echo "Error: prompt argument is required" >&2
  usage
  exit 1
fi

PROMPT_BYTES=$(printf "%s" "$PROMPT" | wc -c | tr -d ' ')
echo "=== AGENT PROMPT START ==="
echo "Prompt source: ${PROMPT_SOURCE}"
echo "Prompt size: ${PROMPT_BYTES} bytes"
echo ""
printf "%s\n" "$PROMPT"
echo ""
echo "=== AGENT PROMPT END ==="
echo ""

# Extract extra arguments (everything except the last — the prompt)
# These are passed through to the agent to support flags like --continue --resume
PASS_ARGS=()
if [ $# -gt 1 ]; then
  PASS_ARGS=("${@:1:$#-1}")
fi

# Determine provider
PROVIDER="${AI_AGENT_PROVIDER:-cursor}"
echo "AI Agent Provider: $PROVIDER"

# Derive a human-readable usage name for token-report files.
# Prefer the agent config name (e.g. story_acceptance_criteria from CONFIG_FILE),
# then fall back to the workflow-provided AI_TEAMMATE_CONFIG_FILE,
# and finally fall back to the provider name for standalone/local runs.
AI_AGENT_USAGE_NAME="${PROVIDER}"
CONFIG_FILE="${CONFIG_FILE:-${AI_TEAMMATE_CONFIG_FILE:-}}"
if [ -n "${CONFIG_FILE:-}" ]; then
  case "${CONFIG_FILE}" in
    */.dmtools/packs/*)
      # Pack launch surface (Wave 2): the config lives inside an unpacked
      # agent pack (~/.dmtools/packs/<agent>-<v>/…, e.g. launch.json) —
      # report usage under the AGENT NAME (the pack dir), not the file
      # basename, so token-usage reports stay stable across the migration.
      usage_name="${CONFIG_FILE#*/.dmtools/packs/}"
      usage_name="${usage_name%%/*}"
      usage_name="${usage_name%-[0-9]*}"
      AI_AGENT_USAGE_NAME="${usage_name:-launch}"
      ;;
    *)
      AI_AGENT_USAGE_NAME="$(basename "${CONFIG_FILE}" .json)"
      ;;
  esac
fi
export AI_AGENT_USAGE_NAME
echo "AI Agent Usage Name: ${AI_AGENT_USAGE_NAME}"

# Marker used by rescue_misplaced_outputs() (see providers/_common.sh) to
# detect output files the agent wrote to the wrong directory — e.g. because
# its persistent Bash shell `cd`'d into a dependency checkout while exploring
# source and never returned before writing outputs/*.
RESCUE_MARKER="$(start_output_rescue_marker)"

# ── git push guard (mechanical, dmtools-agents#542) ─────────────────────────
# Interpose a `git` shim at the front of PATH for the WHOLE agent subprocess
# tree: the provider CLI (fa/claude/cursor/…) inherits it, so the LLM agent's
# own shell-tool `git push` is intercepted, and the JS post-actions' pushes
# (via cli_execute_command, PATH-resolved) go through it too. The shim
# refuses pushes to protected branches (main/master/default) and commit
# messages with closing keywords — prompts alone proved insufficient (the
# gh-992 incident: crafted "(closes #992)" commit pushed straight to main).
GIT_GUARD_DIR=""
if [ -f "${SCRIPT_DIR}/git-push-guard.sh" ]; then
  # Do not arm a second shim when one is already on PATH (the factory
  # workflow prepends its own guard dir for the whole step): two copies
  # would resolve each other as "real git" and exec-loop forever
  # (RCA 2026-09-28 legs hang). The shim itself also skips sibling guard
  # copies during real-git resolution — belt and braces.
  _existing_git_resolved="$(readlink -f "$(command -v git 2>/dev/null)" 2>/dev/null || true)"
  case "$_existing_git_resolved" in
    */git-push-guard.sh)
      echo "git push guard: already armed on PATH — skipping duplicate install"
      ;;
    *)
      GIT_GUARD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/git-push-guard.XXXXXX")"
      ln -sf "${SCRIPT_DIR}/git-push-guard.sh" "${GIT_GUARD_DIR}/git"
      export PATH="${GIT_GUARD_DIR}:${PATH}"
      echo "git push guard: armed (${GIT_GUARD_DIR}/git → scripts/git-push-guard.sh)"
      ;;
  esac
fi

exit_code=0
case "$PROVIDER" in
  claude-code)
    run_claude_code || exit_code=$?
    ;;
  codemie)
    run_codemie || exit_code=$?
    ;;
  copilot)
    run_copilot || exit_code=$?
    ;;
  fa)
    run_fa || exit_code=$?
    ;;
  kimi)
    run_kimi || exit_code=$?
    ;;
  cursor)
    run_cursor || exit_code=$?
    ;;
  *)
    echo "Error: unknown provider '$PROVIDER'" >&2
    usage
    exit 1
    ;;
esac

# Best-effort recovery only — must never itself change this script's exit
# code (a hiccup here would otherwise mask the real CLI exit_code above,
# under `set -e`), so it's explicitly guarded with `|| true`.
rescue_misplaced_outputs "$RESCUE_MARKER" || true
rm -f "$RESCUE_MARKER"
if [ "$exit_code" -eq 0 ] && command -v promote_pending_session_manifest >/dev/null 2>&1; then
  promote_pending_session_manifest "$exit_code" || true
fi
[ -n "${GIT_GUARD_DIR:-}" ] && rm -rf "${GIT_GUARD_DIR}" || true

exit $exit_code
