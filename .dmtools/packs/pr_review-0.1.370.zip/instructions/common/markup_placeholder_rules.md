# Markup Placeholder Rules

The structural template is an **example only**. Tags such as `<bold>`, `<bullet>`, `<code>`, `<heading2>`, and `<link>` are placeholders that show the required shape of the document.

**CRITICAL: Never write the final `outputs/response.md` using these literal metatags.** Use the tracker-specific transformation table in this prompt (e.g., **Jira Markup Reference**, **ADO Markup Reference**, or **GitHub-Flavored Markdown Placeholder Table**) to convert every placeholder into the correct tracker markup.

## Placeholder Transformation Rules

- Replace every `<bold>`, `<italic>`, `<strike>`, `<underline>`, `<code>`, `<codeblock>`, `<bullet>`, `<numbered>`, `<heading1>`, `<heading2>`, `<heading3>`, `<link>`, `<image>`, `<quote>`, `<panel>`, `<color>`, and `<hr>` placeholder with the equivalent markup defined in the tracker-specific transformation table.
- Do NOT leave literal XML-style tags such as `<bold>` or `<code>` in the final `outputs/response.md`.
- Follow the active tracker's markup syntax strictly and do not mix dialects from other trackers.
- Use the tracker-specific link format when referencing tickets or URLs.
