# Story Test Automation Output Rules

## Mandatory JSON output

Write `outputs/story_test_automation_result.json` using the shared JSON schema from the **Bulk Test Automation Shared Rules** section.

- `overall`:
  - `passed` — no `failed` results (combination of `passed`, `skipped`, and/or `irrelevant` is OK).
  - `failed` — at least one result is `failed` and none are blocked.
  - `blocked_by_human` — automation could not run due to missing credentials/data.
- `results` must contain every linked Test Case found in the input context.
- `failedDescriptionFile` is required for every `failed` result. It must point to a file under `outputs/`.
- `failureSummary` is required for every `failed` result.
- `testPath` is required for every `passed` result; it should be omitted for `skipped` and `irrelevant`.
- `irrelevant` — use when the Test Case is legacy, obsolete, or no longer applies to the current product (e.g., a test for a removed workflow job or an external page whose contract changed). The post-action will move it to `Irrelevant` and delete its test code.

## Mandatory tracker comment

Write `outputs/tracker_comment.md` using the active tracker's comment format (defined by the tracker-specific formatting instructions included in this prompt). It should include:

- Story key and summary.
- Counts of passed / failed / skipped Test Cases.
- List of failed Test Cases with links to their failed description files (will be attached by the post-action).
- Any blockers or missing setup.

## Failed description files

For each failed Test Case, write `outputs/failed_description_{TC_KEY}.md` containing:

1. Test Case key and summary.
2. Steps to reproduce.
3. Expected vs actual result.
4. Stack trace / logs / screenshots if available.
5. Environment details.

Use the active tracker's markup format (headings, code blocks, lists) as defined by the tracker-specific formatting instructions in this prompt so the file is readable when attached to the Test Case ticket.
