```mermaid
flowchart TD
    START([Bug ticket ready for fix]) --> READ["⚠️ MANDATORY: Read ALL input files FIRST — see instructions/common/input_context_reading.md"]
    READ --> PREFLIGHT{"⚠️ STEP 0 input-completeness pre-flight (bug + batch legs):<br/>missing attachment, broken reference, or contradiction?"}
    PREFLIGHT -->|Highlights - missing input| ASK["Post ONE comment asking for the missing items +<br/>write outputs/needs-input.md + STOP before RCA/fix — developBugAndCreatePR and<br/>developBugFixBatchAndCreatePR classify this ask stop BEFORE any interrupted/reset path"]
    ASK --> END_ASK([End - needs input - bug leg green, no PR])
    PREFLIGHT -->|Clean| RETURNED{Ticket returned to development?}
    RETURNED -->|Yes| PREV["Review previous PR diff and QA feedback in comments.md"]
    PREV --> RCA_RET["Write/Update RCA explaining why previous fix failed — see output_rules.md for rca.md format"]
    RETURNED -->|No| RCA_FRESH["Write fresh RCA from ticket description and linked_tests.md"]
    RCA_RET --> REPRO
    RCA_FRESH --> REPRO["Write a unit test that reproduces the bug. Run it — it MUST FAIL"]
    REPRO --> EXISTS{Test fails?}
    EXISTS -->|No| ALREADY["Check git history, current code, and linked tests.<br/>⚠️ If linked test exists: verify it passes AND the test was created/updated BEFORE the fix commit — not after.<br/>If bug is genuinely fixed — write outputs/already_fixed.json and stop"]
    ALREADY --> END_FIXED([End — bug already fixed])
    EXISTS -->|Yes| BLOCKED{Fix requires external decision, secrets, or infra changes?}
    BLOCKED -->|Yes| BLOCK["Write outputs/blocked.json and stop — see output_rules.md"]
    BLOCK --> END_BLOCKED([End — blocked awaiting human input])
    BLOCKED -->|No| FIX["Make minimum targeted fix for the root cause ONLY"]
    FIX --> VERIFY["Run reproduction test (must PASS) and full test suite (no regressions)"]
    VERIFY --> PASS{All tests pass?}
    PASS -->|No| ADJUST["Adjust fix and re-run tests"]
    ADJUST --> VERIFY
    PASS -->|Yes| POSTCHECK{"Integration readiness check:<br/>does the feature depend on external setup<br/>the repo does not contain?"}
    POSTCHECK -->|Gaps found| CONCERNS["Write outputs/concerns.md:<br/>what is missing + what is needed to make it work"]
    CONCERNS --> GITSTATUS["Run git status and review every new/modified file"]
    POSTCHECK -->|Self-sufficient| GITSTATUS["Run git status and review every new/modified file"]
    GITSTATUS --> SECRETS{Sensitive or untracked non-code files present?}
    SECRETS -->|Yes| IGNORE["Add appropriate patterns to .gitignore"]
    SECRETS -->|No| SUMMARY["Write concise bug fix summary to outputs/response.md — see output_rules.md"]
    IGNORE --> SUMMARY
    SUMMARY --> END([End — post-processing handles git/PR])
```

## Returning from test-automation failure

When this Bug has been sent back to development because a linked Test Case failed:

1. Read the `Failed Reason` field of every linked Test Case.
2. If the failure is caused by a missing token, missing permission, missing secret, or any other access/credential/infra issue that you cannot fix in product code, write `outputs/blocked.json` and stop. Do **not** try to code a fix for an access problem.
3. Only attempt a product-code fix when the failure is a genuine product regression.

## ⚠️ STEP 0 — INPUT COMPLETENESS PRE-FLIGHT (bug + batch legs, before ANY work)

Bug and bug-fix-batch legs run the STEP 0 input-completeness pre-flight defined in `instructions/common/input_completeness_preflight.md` (it is part of the prompt chain). On these legs the needs-input probe is implemented in `js/developBugAndCreatePR.js` and `js/developBugFixBatchAndCreatePR.js`: a `needs-input.md` stop is classified before the interrupted-leg reset, adds the `ai_questions_asked` label, preserves partial work on the `ai/<ticket>` branch, and ends the leg green without a PR.

Before finishing, run the COMPLETION POST-CHECK — see `instructions/common/completion_post_check.md`.
