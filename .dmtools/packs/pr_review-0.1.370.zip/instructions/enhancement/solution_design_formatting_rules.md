# Solution Design Output Format

Write the enhanced SD CORE technical description to `outputs/response.md` and a valid Mermaid diagram to `outputs/diagram.md`.

Transform every generic template placeholder tag (`<bold>`, `<bullet>`, `<code>`, `<link>`, etc.) into the target tracker markup using the **Generic Template Placeholders** and tracker-specific markup sections in this prompt.

```
<bold>Purpose:</bold>
[One-paragraph summary of the solution goal and scope.]

<bold>Background and Constraints:</bold>
<bullet> Existing workflow, system, or business constraint.
<bullet> Relevant prior decision or dependency.
<bullet> Non-negotiable technical or process limitation.

<bold>Architecture Decisions:</bold>
<bullet> Decision: [chosen approach] — Rationale: [why it fits best].
<bullet> Decision: [alternative considered and rejected] — Rationale: [trade-off].

<bold>Component Responsibilities:</bold>
<bullet> <code>ComponentName</code>: [what it does and how it interacts with others].
<bullet> <code>AnotherComponent</code>: [responsibility].

<bold>Data Flow:</bold>
<bullet> Step 1: [actor / trigger → component].
<bullet> Step 2: [component → component / store].
<bullet> Step 3: [result / side effect].

<bold>API Contracts:</bold>
<bullet> <code>POST /api/example</code>: [request payload shape] → [response shape].
<bullet> <code>GET /api/example/{id}</code>: [purpose and return shape].
<bullet> [If a new/changed enum or literal id value is introduced here and another repository will hardcode it verbatim: call out here that the consuming repo's implementation MUST verify the exact literal against the actual merged source of truth (not just this design doc) before its change merges, and should cover it with a test that fails if the source value ever drifts — not one that only mocks the id locally.]

<bold>AC Coverage:</bold>
The Acceptance Criteria are defined in the BA ticket (<link>BA-TICKET|https://jira.example.com/browse/BA-TICKET</link>) and are the single source of truth.
<bullet> AC1 (Feature Display) → Addressed by [component / flow].
<bullet> AC2 (Dialog Content) → Addressed by [component / flow].
<bullet> AC3 (Core Logic) → Addressed by [component / flow].
<bullet> AC4 (Error Handling) → Addressed by [component / flow].

<bold>Out of Scope:</bold>
<bullet> Item deliberately not covered by this solution.

<bold>Risks and Security Notes:</bold>
<bullet> Risk: [description] — Mitigation: [approach].
<bullet> Security: [credential, secret, or permission consideration].
```

## Rules

- Replace every `<bold>`, `<bullet>`, `<code>`, `<link>` tag with the target tracker's markup (never leave literal XML-style tags).
- Write the Mermaid diagram to `outputs/diagram.md` following `common/diagram_output_contract.md` exactly (plain Mermaid syntax, no fences, no markup tags).
