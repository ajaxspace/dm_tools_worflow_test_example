```mermaid
flowchart TD
    G1["Run PM discovery for the ticket — outcome-oriented, continuous, not a one-shot doc dump"]
    G2["Read input/discovery_meta.json — tells you the resolved Confluence space/parent and whether a prior discovery page already exists"]
    G3["Check outputs/discovery/ BEFORE writing anything — on an iteration run it is already SEEDED with the last published Confluence content, at EVERY depth of the page tree (including nested subfolders).<br/>Read it FIRST. Treat it as the living context pack / running synthesis. EDIT those files in place, don't restart from a blank file."]
    G4["No invention (NOT no investigation — see investigate_before_writing.md): only state what sources support, but ACTIVELY GO FIND those sources first (web research, codebase, linked docs).<br/>Use TBD / Open question only for what's genuinely unknowable after investigating"]
    G5["Keep feature-request → symptom → problem → root cause → outcome → solution separate. Do not jump from a feature request straight to 'the solution' — a feature request is an INPUT, not a validated requirement."]
    G6["⚠️ MANDATORY: always write outputs/discovery/recommendations.md — challenge the idea FIRST (steelman the case against), THEN a go/no-go answer + concrete proposal, not just gathered facts. See output_rules.md."]

    subgraph AUTOPUBLISH["⚠️ This run auto-publishes — there is no interactive approval step"]
        AP1["Unlike an interactive discovery session, this is a headless CI run —<br/>whatever you write to outputs/discovery/ WILL be synced to Confluence after this run"]
        AP2["Treat any pre-existing content already sitting in outputs/discovery/ (seeded from the last published page) as already-approved —<br/>never silently delete or contradict it; use the delta buckets below instead"]
        AP3["Only write files for the mode(s) you actually have enough input to run.<br/>Do not fabricate content for empty sections — leave TBD"]
    end
```

## Findings are not the deliverable — a recommendation is

Gathering facts (from a ticket, web research, or the codebase) is necessary but not sufficient. Every discovery run must convert what was found into an actual, actionable recommendation: a go/no-go (or build/don't-build/build-smaller) stance, a concrete proposed direction, and your best-supported answer to each open question — not just a list of open questions with no answer attempted. See `output_rules.md`'s "`recommendations.md` is mandatory" section for the required structure. A run that only hands back raw research with no proposal or answer is an incomplete discovery pass, regardless of how much investigation went into it.

## Challenge the idea before endorsing it

Before writing a positive recommendation, actively argue against it: does this duplicate something that already exists (a tool, vendor, or internal feature)? Is the problem actually painful enough to justify the effort? What would a skeptical stakeholder say? A recommendation that never seriously considered "we don't need this" is not trustworthy — see `output_rules.md`'s required ordering for `recommendations.md`.


## Problem → outcome → solution

Keep these layers separate in every artefact you write:

1. **Feature request (input only)** — what was literally asked for; not yet validated as the right thing to build
2. **Symptom** — the visible complaint or friction (may not be the real problem)
3. **Problem** — whose pain / job; why it matters now; the underlying cause, not just the symptom
4. **Root cause** — why the problem happens at all (at least a provisional hypothesis, cited to evidence)
5. **Consequence** — what actually goes wrong when the problem occurs (delay, cost, error, escalation, churn, etc.)
6. **Outcome** — measurable or observable change if this succeeds
7. **Opportunity** — the intervention area the evidence actually supports
8. **Solution ideas** — options under consideration (see `decision_and_governance.md`'s solution-classes catalog — don't assume "build something new" is the only option)
9. **Committed solution (for build)** — only what sources/decisions actually support

Do not leap from a stakeholder feature request straight to "the solution" without working through problem → root cause → outcome first. A feature request is an input to discovery, not a pre-validated requirement.

## Four big risks (plus domain-conditional risks when they apply)

Use these consistently in the discovery plan, open questions, experiment design, and readiness sections:

| Risk | Question |
|------|----------|
| **Value** | Will users/customers choose to use it? Does it solve a real problem? |
| **Usability** | Can they figure out how to use it in their real workflow? |
| **Feasibility** | Can we build/operate it with our skills, time, systems, and partners? |
| **Business viability** | Does it work for the business (compliance, partners, cost, go-to-market, brand, ops)? |

Add these two **only when the domain genuinely warrants them** (e.g. safety-critical, regulated, or compliance-sensitive processes — do not add them by default for a low-stakes internal tool):

| Risk | Question |
|------|----------|
| **Operational/safety risk** | Could a failure mode cause incorrect processing, a missed decision, unsafe automation, or physical/operational harm? |
| **Compliance/privacy risk** | Does it meet the audit, validation, access, confidentiality, and data-protection obligations that apply here? |

For each material unknown: name the risk type, its severity (High/Med/Low/Unknown), and the lightest adequate **evidence bar** (e.g. stakeholder confirmation, workflow observation, prototype feedback, technical spike, compliance confirmation, metrics baseline). Do not demand the same rigor for every TBD — high consequence needs stronger evidence, low risk needs lighter confirmation. See `evidence_and_methods.md` for evidence classes and confidence levels to label findings with, and `decision_and_governance.md` for matching an experiment method to each risk type.

## Iteration protocol (when outputs/discovery/ is already seeded with prior published content)

Before writing anything, check `outputs/discovery/` — on an iteration run it already contains the last published Confluence content (seeded by the pre-CLI step), not an empty folder. When it is non-empty, produce a delta and edit those same files in place instead of rewriting from scratch:

| Bucket | Meaning |
|--------|---------|
| **Confirms** | Reinforces an existing decision / requirement |
| **Changes** | Updates prior understanding (cite old → new) |
| **Contradicts** | Conflicts with prior context or another source — do not resolve silently, surface it |
| **New** | Net-new requirement, field, flow, or constraint |
| **New open questions** | With risk type + evidence bar |
| **Scope impact** | Suggested in-scope / out-of-scope moves |

Update the relevant `outputs/discovery/*.md` file(s) **in place** with the merged result (prior content + delta) — since these files already contain the prior published state, this is a direct edit, not a copy-then-merge step. Note the delta itself in `outputs/discovery/index.md`'s "Last iteration" section too — don't leave the delta only in chat/log output, since Confluence readers only see the published files.

### Append-only artifacts are the one exception to "edit in place"

Most files above get merged/edited in place. Two optional files work differently — they exist specifically to preserve history across many iterations, so a run must never rewrite or drop their prior rows:

- **`decisions-log.md`** — running Q&A/decisions record. Append new rows for what this run surfaced; never edit or delete an existing row (if an old open question now has an answer, add a new row referencing it).
- **`references.md`** — consolidated external-artifact index. Append new rows for new artifacts; never remove an old row even if that artifact's topic later drops out of scope (mark it accordingly instead).

See `output_rules.md` for the exact table shape and when to bother creating these files at all (skip them for a single-session, one-shot discovery with no back-and-forth).

## Working rules

1. **Source of truth**: ticket description/comments/attachments for "what was asked"; any content already seeded in `outputs/discovery/` for "what was already published"; any Confluence/URL the ticket or its comments point to for "what is documented elsewhere". Call out conflicts across sources — do not silently pick a side.
2. **No invention, not no investigation** (see `investigate_before_writing.md`): only state what sources support — but go actively find those sources first (web research for named external topics/technologies, CodeGraph for codebase questions, fetching linked docs). Use **TBD** or **Open question** only for what's genuinely unknowable after investigating, not as a shortcut for skipping research.
3. **Preserve detail**: do not drop field values, status rules, interface names, owners, exception paths, or decisions. Prefer tables for contracts and mappings.
4. **AS IS vs TO BE**: keep current-state and future-state clearly separated; label working assumptions.
5. **Traceability**: every material finding cites its source (ticket comment, attachment name, Confluence section, prior context-pack entry).
6. **Experiment over documentation**: when the dominant risk is Value or Usability, prefer proposing the cheapest test (interview, walkthrough, prototype, spike) over writing more pages.
7. **Trio check**: before marking discovery "ready for delivery", note whether Product / Engineering / Design-UX (or the closest available roles) have reviewed the dominant risks — record who reviewed, or mark **pending**. Do not invent reviewers.
