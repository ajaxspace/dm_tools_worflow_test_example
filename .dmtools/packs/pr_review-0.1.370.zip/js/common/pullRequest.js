/**
 * Shared GitHub PR creation helper.
 *
 * Keeps command construction, title sanitization, duplicate PR lookup, body-file
 * handling, and URL extraction in one place for all agents.
 */

// Strips script-wrapper artifacts from a captured command output. Behaviour is deliberately
// unchanged for ALL callers (it backs ~20 delegating copies and runs on commit subjects, file
// lists, diffs): a captured line that happens to start with `warning: ` / `note: ` is DATA there
// and must survive. gh-912's stderr noise is handled where it matters — the strict ref-line
// parsers below — or explicitly via stripGitNoise().
function cleanCommandOutput(output) {
    if (!output) return '';
    return output.split('\n').filter(function(line) {
        return line.indexOf('Script started') === -1 &&
               line.indexOf('Script done') === -1 &&
               line.indexOf('COMMAND=') === -1 &&
               line.indexOf('COMMAND_EXIT_CODE=') === -1;
    }).join('\n').trim();
}

// gh-912: the JS bridge hands scripts stdout+stderr merged (deliberate Java-parity contract in
// dmtools-dart's _runShellScript), and git >= 2.54 prints `warning: redirecting to <url>/` on EVERY
// network command against a redirecting (central-mode insteadOf) server. Opt-in filter for captures
// that are known to be git network output: drops only whole LINES starting with `warning: ` /
// `note: ` (line-anchored — mid-line occurrences in diffs/logs are untouched), after the wrapper
// cleanup. Never use it on commit subjects, file lists or diffs.
function stripGitNoise(output) {
    return cleanCommandOutput(output).split('\n').filter(function(line) {
        return !/^warning: /.test(line) && !/^note: /.test(line);
    }).join('\n').trim();
}

/** Escape a string for literal use inside a RegExp (branch names, gh-912 E2). */
function escapeRegExp(text) {
    return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Both GitHub and GitLab reject PR/MR titles over 255 characters. A prTitle
// template like '{ticketKey} {ticketSummary}' can push an already-near-limit
// ticket summary (itself truncated to 255 elsewhere) past that cap, so this is
// the last-resort safety net right before the title is sent to gh/GitLab API.
var MAX_TITLE_LENGTH = 255;

function sanitizeTitle(title) {
    var sanitized = String(title || '')
        .replace(/\r?\n/g, ' ')
        .replace(/"/g, '\\"')
        .replace(/->/g, '→')
        .replace(/<-/g, '←')
        .replace(/[<>`|&;$]/g, ' ')
        .replace(/\s{2,}/g, ' ')
        .trim();

    if (sanitized.length > MAX_TITLE_LENGTH) {
        console.warn('PR/MR title exceeds ' + MAX_TITLE_LENGTH + ' characters (' + sanitized.length + '); truncating to fit GitHub/GitLab limit.');
        sanitized = sanitized.substring(0, MAX_TITLE_LENGTH - 3) + '...';
    }

    return sanitized;
}

/** Escape a string so it can safely be placed inside a double-quoted shell argument.
 *  CliCommandExecutor rejects: ; \n \r ` $(...) ${...} && || | > <
 *  Jira summaries often contain angle brackets, arrows, etc. */
function sanitizeCommitMessage(message) {
    return String(message || '')
        .replace(/->/g, '→')
        .replace(/<-/g, '←')
        .replace(/"/g, '\\"')
        .replace(/[<>\`\|&;$\r\n]/g, ' ')
        .replace(/\s{2,}/g, ' ')
        .trim();
}

function extractPrUrl(output, runCommand, branchName, workingDir) {
    var cleaned = cleanCommandOutput(output);
    var urlMatch = cleaned.match(/https:\/\/(?:github\.com|[^/\s]*gitlab[^/\s]*|gitlab\.example\.com)\/[^\s]+/);
    if (urlMatch) return urlMatch[0];

    var prNumberMatch = cleaned.match(/#(\d+)/);
    if (prNumberMatch) {
        try {
            var remoteUrl = cleanCommandOutput(runCommand('git config --get remote.origin.url', workingDir) || '');
            var repoMatch = remoteUrl.match(/github\.com[:/]([^/?#\s]+\/[^/?#\s]+)/);
            if (repoMatch) {
                return 'https://github.com/' + repoMatch[1].replace(/\.git$/, '') + '/pull/' + prNumberMatch[1];
            }
        } catch (e) {}
    }

    try {
        var listOutput = cleanCommandOutput(
            runCommand('gh pr list --head ' + branchName + ' --json url --jq ".[0].url"', workingDir) || ''
        );
        if (listOutput && listOutput.startsWith('https://')) return listOutput;
    } catch (e) {}

    return null;
}

function defaultRunCommand(command, workingDir) {
    var args = { command: command };
    if (workingDir) args.workingDirectory = workingDir;
    return cli_execute_command(args);
}

function defaultReadFile(path) {
    try {
        var content = file_read({ path: path });
        return (content && content.trim()) ? content : null;
    } catch (e) {
        return null;
    }
}

function defaultWriteFile(path, content) {
    return file_write(path, content);
}

function defaultDeleteFile(path) {
    try {
        file_delete({ path: path });
    } catch (e) {
        // Best-effort cleanup only — a leftover temp PR-body file is not fatal on an
        // ephemeral CI runner, but it does dirty the tree on a reused local-teammate
        // checkout (js/../scripts/run-teammate-local.sh refuses to run against a
        // dirty tree), so we still try.
    }
}

// ── Closes line (gh-737) ────────────────────────────────────────────────────
// The merge bot (awf factory-merge-trigger) links approved issues to PRs ONLY
// via 'Closes #N' in the PR body (or branch 'N-*'). Factory-created PRs built
// from the response.md template carried no Closes line, so the bot reported
// 'no linked open PR' for every approved issue and merged nothing
// (merged=0 skipped=4, live fa 2026-10-05). Every PR the pack creates must
// therefore carry the canonical line by construction. Bot-side awf#19 also
// accepts Fixes/Part-of, but the pack still emits canonical Closes — a
// non-canonical keyword never substitutes for it.
var ROUTER_ISSUE_KEY = /^g[hl]-\d+$/i; // gh-N (GitHub) and gl-N (GitLab) both close issue #N on their forge

/**
 * Extracts the trailing issue number from a ticket key (gh-737 → '737',
 * PROJ-123 → '123'). Returns null when the key carries no digits.
 */
function extractIssueNumber(ticketKey) {
    var m = /(\d+)\s*$/.exec(String(ticketKey || '').trim());
    return m ? m[1] : null;
}

/**
 * Guarantees the body contains the canonical 'Closes #N' line for the ticket.
 * Idempotent: a body that already closes the same issue is left untouched;
 * any other keyword (Fixes/Part-of) still gets the canonical line added.
 * Keys that are not router keys (gh-N / gl-N) leave the body unchanged.
 */
function ensureClosesLine(body, ticketKey) {
    // Only router keys (gh-N / gl-N) map to a closeable issue on the target
    // forge; tracker keys such as PROJ-123 would produce a bogus 'Closes #123' link.
    if (!ROUTER_ISSUE_KEY.test(String(ticketKey || '').trim())) return body;
    var num = extractIssueNumber(ticketKey);
    if (!num) return body;

    var text = body === null || body === undefined ? '' : String(body);
    if (new RegExp('\\bCloses\\s+#?' + num + '\\b', 'i').test(text)) return text;

    return 'Closes #' + num + '\n' + text;
}

// gh-960: the PR body (including the canonical 'Closes #N' line) must be final
// BEFORE the PR enters the merge queue. Live 2026-10-17: PR #956 merged with
// 'Closes #952' added to the body at the merge moment (finalize-step rewrite
// after validation armed) — GitHub evaluates closing keywords on creation
// and body edits, never post-merge, so #952 stayed OPEN. From the moment the
// validate→merge pipeline arms (ai_validating on the PR) or the PR is
// merged/closed, a body rewrite is too late and must be skipped.
var MERGE_QUEUE_BODY_LABELS = ['ai_validating'];

/**
 * gh-960 rework (review thread js/common/pullRequest.js:192): the label scan
 * lives in its own helper so isPrBodyFrozen stays under the CI crap gate
 * (CC ≤ 8) — the loop + name-normalization ternary + indexOf pushed it to 12.
 * Accepts both GitHub REST label shapes ({name: …} objects) and plain-string
 * label arrays.
 */
function mergeQueueBodyLabelPresent(labels) {
    labels = labels || [];
    for (var i = 0; i < labels.length; i++) {
        var name = labels[i] && labels[i].name !== undefined ? labels[i].name : labels[i];
        if (MERGE_QUEUE_BODY_LABELS.indexOf(String(name)) !== -1) return true;
    }
    return false;
}

/**
 * Whether the PR body must be treated as final — the PR entered the merge
 * queue (validation armed) or is already merged/closed.
 */
function isPrBodyFrozen(pr) {
    if (!pr || typeof pr !== 'object') return false;
    // Defensive only: github_list_prs (REST list) carries no `merged` field and
    // lists only state:'open' PRs, so this branch never fires in production —
    // the ai_validating label is the only live freeze signal (review thread
    // js/common/pullRequest.js:203).
    if (pr.merged === true) return true;
    var state = String(pr.state || '').toLowerCase();
    // 'completed' covers ADO-shaped state — ADO closes work items/PRs as
    // 'completed', which a closed/merged-only check would miss.
    return state === 'closed' || state === 'merged' || state === 'completed' ||
        mergeQueueBodyLabelPresent(pr.labels);
}

// GitHub limits PR bodies to 65536 characters. Keep a safety margin so
// gh pr create does not fail on oversized bodies generated by agents.
var MAX_GH_PR_BODY_LENGTH = 60000;

var mergeState = require('./mergeState.js');
var jiraWikiToMarkdown = require('./jiraWikiToMarkdown.js').jiraWikiToMarkdown;

function isSafeRefName(ref) {
    return ref &&
        typeof ref === 'string' &&
        ref[0] !== '-' &&
        ref.indexOf('..') === -1 &&
        /^[A-Za-z0-9._/-]+$/.test(ref);
}

function lastNonEmptyLine(output) {
    var lines = cleanCommandOutput(output || '')
        .split(/\r?\n/)
        .map(function(line) { return line.trim(); })
        .filter(function(line) { return line; });
    return lines[lines.length - 1] || '';
}

function branchContainsBase(runCommand, workingDir, baseBranch) {
    if (!isSafeRefName(baseBranch)) {
        throw new Error('Unsafe base branch name: ' + baseBranch);
    }

    var baseRef = 'origin/' + baseBranch;
    var baseSha = lastNonEmptyLine(runCommand('git rev-parse ' + baseRef, workingDir));
    if (!baseSha) {
        throw new Error('Could not resolve ' + baseRef);
    }

    try {
        var mergeBase = lastNonEmptyLine(runCommand('git merge-base ' + baseRef + ' HEAD', workingDir));
        return mergeBase === baseSha;
    } catch (e) {
        return false;
    }
}

function branchHasMergeBase(runCommand, workingDir, baseBranch) {
    if (!isSafeRefName(baseBranch)) {
        throw new Error('Unsafe base branch name: ' + baseBranch);
    }

    try {
        var mergeBase = lastNonEmptyLine(
            runCommand('git merge-base origin/' + baseBranch + ' HEAD', workingDir)
        );
        return !!mergeBase;
    } catch (e) {
        return false;
    }
}

function fetchAdditionalHistoryForMergeBase(runCommand, workingDir, baseBranch, branchName) {
    var refSpecs = [
        '+refs/heads/' + baseBranch + ':refs/remotes/origin/' + baseBranch
    ];
    if (branchName && isSafeRefName(branchName)) {
        refSpecs.push('+refs/heads/' + branchName + ':refs/remotes/origin/' + branchName);
    }

    var deepenCommands = [];
    for (var i = 0; i < refSpecs.length; i++) {
        deepenCommands.push('git -c fetch.recurseSubmodules=no fetch --deepen=100 origin ' + refSpecs[i]);
    }
    deepenCommands.push('git -c fetch.recurseSubmodules=no fetch --unshallow origin');

    for (var j = 0; j < deepenCommands.length; j++) {
        try {
            runCommand(deepenCommands[j], workingDir);
        } catch (e) {
            console.warn('Could not deepen git history for merge-base lookup:', e.message || e);
        }
        if (branchHasMergeBase(runCommand, workingDir, baseBranch)) {
            return true;
        }
    }
    return false;
}

/**
 * Targeted origin fetch: ONLY the named branches, with forced remote-tracking
 * refspecs (owner rule 2026-10-03: never blanket-fetch — `fetch origin --prune`
 * pulled every ref of a big repo for 134s; legs need the target branch and the
 * issue branch, nothing else. Agents that want history fetch it themselves).
 *
 * @param {string[]} branches - branch names to fetch
 * @returns {string|null} the git command, or null when no safe names remain
 */
function buildTargetedOriginFetchCommand(branches) {
    var list = (branches || []).filter(function (b) { return b && isSafeRefName(b); });
    if (!list.length) return null;
    var refspecs = list.map(function (b) {
        return '+refs/heads/' + b + ':refs/remotes/origin/' + b;
    });
    return 'git -c fetch.recurseSubmodules=no fetch origin ' + refspecs.join(' ');
}

function buildOriginFetchCommand(refSpec) {
    return 'git -c fetch.recurseSubmodules=no fetch origin' + (refSpec ? ' ' + refSpec : '');
}

/**
 * Ensures `refs/remotes/origin/<branchName>` exists and is up to date.
 *
 * `git fetch origin <branchName>` (no destination refspec) only updates
 * FETCH_HEAD — it never creates/updates the `origin/<branchName>` tracking
 * ref. That "worked" for base branch "main" only because long-lived cached
 * checkouts (e.g. CI dependency caches) already had `origin/main` from an
 * earlier full clone or wildcard fetch. Any other base branch (e.g. a
 * fixVersion-derived "develop/3.9.0") that was never explicitly fetched with
 * a destination refspec into that cache genuinely has no local tracking ref,
 * so every later git command that reads `origin/<branchName>` (merge-base,
 * merge, diff) fails with "unknown revision or path not in the working
 * tree" — even though the branch exists on the remote.
 *
 * Uses an explicit refspec (`+refs/heads/<b>:refs/remotes/origin/<b>`) so the
 * tracking ref is created/updated regardless of the remote's configured
 * fetch refspec (e.g. a shallow/single-branch clone in CI).
 *
 * @returns {boolean} true if the fetch succeeded (ref should now exist)
 */
function ensureRemoteBranchRef(runCommand, workingDir, branchName) {
    if (!branchName || !isSafeRefName(branchName)) return false;

    try {
        runCommand(
            'git -c fetch.recurseSubmodules=no fetch origin +refs/heads/' + branchName + ':refs/remotes/origin/' + branchName,
            workingDir
        );
        return true;
    } catch (e) {
        console.warn('Could not fetch explicit ref for origin/' + branchName + ':', e.message || e);
        return false;
    }
}

// ── Strict ls-remote ref-line parsing (gh-912) ──────────────────────────────
// Branch-existence probes must NEVER decide on capture non-emptiness: the JS
// bridge merges git's stderr into every capture, and a `warning: redirecting
// to …` line survives cleanCommandOutput's wrapper filtering (the anchored
// ^warning:/^note: filter above is defense in depth; the parser below is the
// primary defense). A branch exists on origin iff the capture contains a real
// ref line `<sha>\trefs/heads/<name>`. ls-remote always prints full object
// names — 40 hex (SHA-1) or 64 hex (SHA-256 repos); {7,64} accepts every real form and rejects prose; the name is regex-escaped so
// dotted/special branch names match literally (E2).

/**
 * Returns only real remote-ref lines (`<sha>\trefs/...`) from an ls-remote
 * capture — stderr noise and wrapper artifacts are dropped.
 */
function remoteRefLines(output) {
    return cleanCommandOutput(output || '').split('\n').filter(function (line) {
        return /^[0-9a-f]{7,64}\trefs\//.test(line);
    }).join('\n');
}

/**
 * Extracts the tip SHA of `branchName` from a `git ls-remote --heads origin
 * <branch>` capture, or null when the capture carries no real ref line for
 * the branch. Throws through when the probe command itself fails — callers
 * keep their existing try/catch semantics.
 *
 * @returns {string|null} the matched SHA, or null when the branch is absent
 */
function remoteBranchSha(runCommand, workingDir, branchName) {
    var out = cleanCommandOutput(runCommand('git ls-remote --heads origin ' + branchName, workingDir) || '');
    var m = new RegExp('^([0-9a-f]{7,64})\\trefs/heads/' + escapeRegExp(branchName) + '\\r?$', 'm').exec(out);
    return m ? m[1] : null;
}

/**
 * True iff `branchName` exists on origin — decided strictly on a real
 * `refs/heads/<branchName>` ref line in the ls-remote capture, tolerating
 * stderr noise merged into it (gh-912). See remoteBranchSha for the
 * error-propagation contract.
 */
function remoteBranchExists(runCommand, workingDir, branchName) {
    return remoteBranchSha(runCommand, workingDir, branchName) !== null;
}

function readTrackedStatus(runCommand, workingDir) {
    var status = cleanCommandOutput(
        runCommand('git status --porcelain --ignore-submodules=dirty', workingDir) || ''
    );
    // factory-kit/ is the factory workflow's machine-infra nested repo
    // (git init inside the workspace — awf factory-teammate.yml), not agent
    // work; as an untracked gitlink it must not fail the working-tree-clean
    // gate before the origin sync (live gh-1000 2026-10-03: staging was
    // fixed, then THIS gate tripped on "?? factory-kit/").
    return status.split('\n')
        .filter(function (line) { return !/^(\?\?|A )\s+factory-kit(\/|$)/.test(line); })
        .join('\n');
}

function readStagedDiffStat(runCommand, workingDir) {
    return cleanCommandOutput(
        runCommand('git diff --cached --stat', workingDir) || ''
    );
}

function isSubmodulePath(runCommand, workingDir, path) {
    try {
        var stageOutput = cleanCommandOutput(
            runCommand('git ls-files --stage -- "' + path + '"', workingDir) || ''
        );
        return stageOutputHasSubmodule(stageOutput);
    } catch (e) {
        return false;
    }
}

// Pure: a `git ls-files --stage` output carries a submodule (gitlink,
// mode 160000) when any stage line starts with it. Shared with
// js/postTestReworkResults.js (gh-1248: one copy of the parse, each caller
// keeps its own command transport).
function stageOutputHasSubmodule(stageOutput) {
    return String(stageOutput || '').split('\n').some(function(line) {
        return line.trim().indexOf('160000 ') !== -1;
    });
}

// Pure: extracts conflicted file paths from `git status --short` output —
// lines whose first two columns carry an unmerged marker (UU/AA/DD/AU/UA/DU/UD).
function parseConflictedFiles(statusRaw) {
    return (statusRaw || '').split('\n')
        .filter(function(line) { return /^(UU|AA|DD|AU|UA|DU|UD) /.test(line.trim()); })
        .map(function(line) { return line.trim().substring(3).trim(); })
        .filter(Boolean);
}

// Pure decision for one conflicted file: which side of the conflict to keep
// ('ours' = the branch being synced / HEAD, 'theirs' = origin/<baseBranch>)
// and the matching log prefix. Submodule conflicts and files the branch never
// changed both adopt the origin/<baseBranch> version.
function decideConflictResolution(isSubmodule, branchChanged, baseBranch) {
    if (isSubmodule) {
        return { side: 'theirs', logPrefix: '  Submodule conflict — adopting origin/' + baseBranch + ' version for' };
    }
    if (branchChanged) {
        return { side: 'ours', logPrefix: '  Keeping branch version for' };
    }
    return { side: 'theirs', logPrefix: '  Keeping origin/' + baseBranch + ' version for' };
}

// True when the branch being synced changed `file` since the merge base with
// origin/<baseBranch> — i.e. the conflict is the branch's own edit. False when
// there is no merge base to compare against or the diff probe fails.
function branchChangedSinceMergeBase(runCommand, workingDir, file, mergeBase) {
    if (!mergeBase) return false;
    try {
        var diff = cleanCommandOutput(runCommand('git diff ' + mergeBase + ' HEAD -- "' + file + '"', workingDir) || '');
        return !!diff.trim();
    } catch (diffError) {
        console.warn('Could not determine change side for', file, ':', diffError.message || diffError);
        return false;
    }
}

// Resolves one conflicted file in place by checking out the chosen side and
// staging it; failures are logged and left for the caller to report.
function resolveOneConflictedFile(runCommand, workingDir, file, mergeBase, baseBranch) {
    try {
        var submodule = isSubmodulePath(runCommand, workingDir, file);
        var branchChanged = submodule ? false : branchChangedSinceMergeBase(runCommand, workingDir, file, mergeBase);
        var plan = decideConflictResolution(submodule, branchChanged, baseBranch);
        console.log(plan.logPrefix, file);
        runCommand('git checkout --' + plan.side + ' -- "' + file + '"', workingDir);
        runCommand('git add -- "' + file + '"', workingDir);
    } catch (resolveError) {
        console.warn('Could not auto-resolve', file, ':', resolveError.message || resolveError);
    }
}

function resolveMergeConflicts(runCommand, workingDir, baseBranch, branchName) {
    var conflictFiles = [];
    try {
        conflictFiles = parseConflictedFiles(cleanCommandOutput(runCommand('git status --short', workingDir) || ''));
    } catch (statusError) {
        return { resolved: false, error: 'Could not read conflict status' };
    }

    if (conflictFiles.length === 0) {
        return { resolved: false, error: 'No conflicted files detected' };
    }

    var mergeBase = '';
    try {
        mergeBase = lastNonEmptyLine(runCommand('git merge-base origin/' + baseBranch + ' HEAD', workingDir));
    } catch (e) {
        console.warn('Could not determine merge base for conflict resolution:', e.message || e);
    }

    conflictFiles.forEach(function(file) {
        resolveOneConflictedFile(runCommand, workingDir, file, mergeBase, baseBranch);
    });

    var stillUnmerged = cleanCommandOutput(
        runCommand('git diff --name-only --diff-filter=U', workingDir) || ''
    ).split('\n').map(function(s) { return s.trim(); }).filter(Boolean);

    if (stillUnmerged.length > 0) {
        return { resolved: false, conflictFiles: stillUnmerged, error: 'Unresolved conflicts remain: ' + stillUnmerged.join(', ') };
    }

    try {
        runCommand('git commit -m "Merge origin/' + baseBranch + ' into ' + branchName + '"', workingDir);
        console.log('✅ Auto-resolved merge conflicts and committed sync of origin/' + baseBranch);
        return { resolved: true };
    } catch (commitError) {
        return { resolved: false, error: 'Conflict files resolved but merge commit failed: ' + (commitError.message || commitError) };
    }
}

// ── gh-1190: syncBranchWithBase seam split ───────────────────────────────────
// Extracted pure parse/build/decide helpers so the orchestration function
// stays under the CRAP quality gate. Behaviour-preserving: same probes and
// decisions in the same order, same log lines, same return shapes — pinned
// by the syncBranchWithBase characterization tests
// (js/unit-tests/test_pullRequestHelper.js).

/** Pure: validates the sync inputs; returns the refusal message or null. */
function validateSyncInputs(branchName, baseBranch) {
    if (!branchName) return 'branchName is required';
    if (!isSafeRefName(branchName)) return 'Unsafe branch name: ' + branchName;
    if (!isSafeRefName(baseBranch)) return 'Unsafe base branch name: ' + baseBranch;
    return null;
}

/**
 * Pure builder for the gh-761 refusal: a merge is already in progress
 * (MERGE_HEAD present — e.g. the agent left a conflicted base-branch merge
 * unconcluded in the tree). `git merge --no-edit` on top of it fails with
 * "You have not concluded your merge", and the resolveMergeConflicts/abort
 * fallback would then auto-resolve the LEFTOVER unmerged paths — or silently
 * `git merge --abort` a fully staged in-flight resolution — finalizing a
 * merge this step did not start (marker-baking / work destruction). The
 * refusal is the first decision, before anything mutating; callers surface
 * the error as a merge-sync failure on the ticket.
 */
function mergeInProgressSyncResult(branchName, baseBranch) {
    return {
        success: false,
        mergeInProgress: true,
        error: 'A merge is already in progress (MERGE_HEAD exists). Conclude or abort it before syncing ' +
            branchName + ' with origin/' + baseBranch + ' — refusing to start a second merge on top of it.'
    };
}

/** Pure builder: the unrelated-histories refusal result. */
function unrelatedHistoriesSyncResult(baseBranch) {
    return {
        success: false,
        unrecoverableByAgent: true,
        error: 'No merge base found between HEAD and origin/' + baseBranch + '; refusing to merge unrelated histories. Fetch full branch history or recreate the branch from origin/' + baseBranch + ' before publishing.'
    };
}

/** Pure builder: the dirty-working-tree refusal result. */
function uncleanTreeSyncResult(baseBranch, status) {
    return {
        success: false,
        error: 'Cannot sync with origin/' + baseBranch + ' because the working tree is not clean:\n' + status
    };
}

/**
 * Dirty-tree realign attempt: when `readTrackedStatus` reports anything, try
 * `git submodule update --init --recursive` once and re-read the status.
 * Matches the original try/catch semantics — a failed submodule update is a
 * warning, not an error.
 */
function realignSubmodulesBeforeSync(runCommand, workingDir) {
    var status = readTrackedStatus(runCommand, workingDir);
    if (status.trim()) {
        try {
            runCommand('git submodule update --init --recursive', workingDir);
            status = readTrackedStatus(runCommand, workingDir);
        } catch (submoduleError) {
            console.warn('Could not realign submodules before syncing with base:', submoduleError.message || submoduleError);
        }
    }
    return status;
}

/**
 * The merge-precondition decision cluster: already-up-to-date early exit,
 * merge-base existence (+ deepen retry), then the dirty-tree realign probe.
 * Returns { block: <terminal result> } when the merge must not start, else
 * { status: <post-realign tracked status> }.
 */
function resolveSyncPreconditions(runCommand, workingDir, baseBranch, branchName) {
    var upToDate = branchContainsBase(runCommand, workingDir, baseBranch);
    if (upToDate) {
        console.log('✅ Branch already contains origin/' + baseBranch);
        return { block: { success: true, updated: false } };
    }

    if (!branchHasMergeBase(runCommand, workingDir, baseBranch) &&
            !fetchAdditionalHistoryForMergeBase(runCommand, workingDir, baseBranch, branchName)) {
        return { block: unrelatedHistoriesSyncResult(baseBranch) };
    }

    return { status: realignSubmodulesBeforeSync(runCommand, workingDir) };
}

/** Best-effort `git merge --abort` — a failed abort is silently tolerated. */
function abortMergeQuietly(runCommand, workingDir) {
    try { runCommand('git merge --abort', workingDir); } catch (abortError) {}
}

/**
 * Pure: shapes the catch-path failure message — a conflict list beats a
 * specific auto-resolve failure, which beats the original git error (when
 * autoResolve found zero conflict markers, `error` was never a real merge
 * conflict — e.g. a missing origin/<baseBranch> ref — so the original git
 * error is kept instead of the misleading generic message).
 */
function buildSyncFailureMessage(error, autoResolve, baseBranch) {
    var message = error && error.message ? error.message : String(error);
    var conflictFiles = autoResolve.conflictFiles || [];
    if (conflictFiles.length > 0) {
        return 'Merge conflict while syncing with origin/' + baseBranch + ': ' + conflictFiles.join(', ');
    }
    if (autoResolve.error && autoResolve.error !== 'No conflicted files detected') {
        // A specific auto-resolve failure (unresolved conflicts, commit failure)
        // is more actionable than the original git error — surface it.
        return autoResolve.error;
    }
    return message;
}

/** Pure builder: the failure result for the sync catch path. */
function syncFailureResult(message, autoResolve) {
    var conflictFiles = autoResolve.conflictFiles || [];
    return {
        success: false,
        conflict: conflictFiles.length > 0,
        conflictFiles: conflictFiles,
        error: message
    };
}

// ── gh-1190: two-branch-mode feature-branch route decision ──────────────────
// Pure decision shared by checkoutBranch.js and preCliDevelopmentSetup.js —
// both had the identical `!local && !remote → create / remote && !local →
// checkout-remote / else checkout-local` chain inline. `featureLocalExists`
// is the truthiness of the cleaned `git branch --list` capture,
// `featureRemoteExists` the strict ls-remote probe result.
function decideFeatureBranchRoute(featureLocalExists, featureRemoteExists) {
    if (!featureLocalExists && !featureRemoteExists) return 'create';
    if (featureRemoteExists && !featureLocalExists) return 'checkout-remote';
    return 'checkout-local';
}

/** Pure resolution of the sync options bag (defaults included). */
function syncOptionsOf(options) {
    options = options || {};
    return {
        branchName: options.branchName,
        baseBranch: options.baseBranch || 'main',
        workingDir: options.workingDir || null,
        runCommand: options.runCommand || defaultRunCommand
    };
}

/**
 * The catch-path recovery: conflict auto-resolution first (an auto-resolved
 * sync still succeeds), then a quiet abort and the shaped failure result.
 */
function recoverFromSyncError(runCommand, workingDir, baseBranch, branchName, error) {
    var autoResolve = resolveMergeConflicts(runCommand, workingDir, baseBranch, branchName);
    if (autoResolve.resolved) {
        return { success: true, updated: true, autoResolved: true };
    }

    abortMergeQuietly(runCommand, workingDir);

    var message = buildSyncFailureMessage(error, autoResolve, baseBranch);
    console.warn('Could not synchronize branch with base:', message);
    return syncFailureResult(message, autoResolve);
}

function syncBranchWithBase(options) {
    var opts = syncOptionsOf(options);
    var branchName = opts.branchName;
    var baseBranch = opts.baseBranch;
    var workingDir = opts.workingDir;
    var runCommand = opts.runCommand;

    var inputError = validateSyncInputs(branchName, baseBranch);
    if (inputError) return { success: false, error: inputError };

    if (mergeState.isMergeInProgress(runCommand, workingDir)) {
        return mergeInProgressSyncResult(branchName, baseBranch);
    }

    try {
        console.log('Synchronizing ' + branchName + ' with origin/' + baseBranch + ' before publishing...');
        ensureRemoteBranchRef(runCommand, workingDir, baseBranch);

        var preconditions = resolveSyncPreconditions(runCommand, workingDir, baseBranch, branchName);
        if (preconditions.block) return preconditions.block;

        if (preconditions.status.trim()) {
            return uncleanTreeSyncResult(baseBranch, preconditions.status);
        }

        runCommand('git merge --no-edit origin/' + baseBranch, workingDir);
        console.log('✅ Merged origin/' + baseBranch + ' into ' + branchName);
        return { success: true, updated: true };
    } catch (error) {
        return recoverFromSyncError(runCommand, workingDir, baseBranch, branchName, error);
    }
}

function resolveBodyContent(options) {
    if (options.bodyContent) return options.bodyContent;

    var readFile = options.readFile || defaultReadFile;
    var candidates = options.bodyFileCandidates || ['outputs/response.md'];
    for (var i = 0; i < candidates.length; i++) {
        var content = readFile(candidates[i]);
        if (content) return content;
    }

    return options.defaultBody || 'Automated changes.';
}

// ── gh-1041: PR creation seam split ──────────────────────────────────────────
// Extraction of createPullRequest (CRAP 46.4) into the orchestrator plus
// small build/decide helpers. Behaviour-preserving: same gh/scm calls in the
// same order, same log lines, same return shapes — pinned by
// test_pullRequestHelper.js characterization tests.

// The canonical Closes-line body resolution shared by both creation paths.
function buildPrBodyContent(options) {
    // PR bodies are GitHub-Flavored Markdown — defensively convert stray Jira wiki markup.
    var bodyContent = jiraWikiToMarkdown(resolveBodyContent(options));
    // gh-737: guarantee the canonical 'Closes #N' line so the merge bot can
    // link this PR to the ticket by construction (applies to defaultBody too).
    if (options.ticketKey) bodyContent = ensureClosesLine(bodyContent, options.ticketKey);
    if (bodyContent && bodyContent.length > MAX_GH_PR_BODY_LENGTH) {
        console.warn('PR body exceeds ' + MAX_GH_PR_BODY_LENGTH + ' characters (' + bodyContent.length + '); truncating to fit GitHub limit.');
        var truncationNotice = '\n\n_…PR body truncated by automation; original full content was ' + bodyContent.length + ' characters._';
        bodyContent = bodyContent.substring(0, MAX_GH_PR_BODY_LENGTH - truncationNotice.length) + truncationNotice;
    }
    return bodyContent;
}

// Pure builder for the `gh pr create` invocation (title sanitized the same
// way for both the command line and the SCM-provider payload).
function buildGhPrCreateCommand(title, tempBodyFile, baseBranch, branchName) {
    return 'gh pr create --title "' + sanitizeTitle(title) + '"' +
        ' --body-file "' + tempBodyFile + '"' +
        ' --base ' + baseBranch +
        ' --head ' + branchName;
}

// True when a gh-cli create failure means an equivalent PR already exists
// (the recoverable shape — the existing URL is looked up afterwards).
function isExistingGhPrError(errMsg) {
    return errMsg.indexOf('already exists') !== -1 || errMsg.indexOf('pull request for branch') !== -1;
}

// True when an SCM-provider create failure means an equivalent PR/MR already
// exists ('Another open merge request' is the GitLab wording).
function isExistingScmPrError(errMsg) {
    return errMsg.indexOf('already exists') !== -1 || errMsg.indexOf('Another open merge request') !== -1;
}

// Looks up an already-open PR for the branch; a failing lookup is non-fatal.
function findExistingGhPr(runCommand, branchName, workingDir) {
    try {
        var existingPr = cleanCommandOutput(
            runCommand('gh pr list --head ' + branchName + ' --json url --jq ".[0].url"', workingDir) || ''
        );
        if (existingPr && existingPr.startsWith('https://')) {
            return existingPr;
        }
    } catch (e) {
        console.warn('Could not check for existing PR (non-fatal):', e);
    }
    return null;
}

// Stringifies a thrown value the way the original seam did (Error → message
// via toString, anything else → String()).
function toErrorString(error) {
    return error && error.toString ? error.toString() : String(error);
}

// The SCM-provider creation path (GitHub/GitLab/ADO providers exposing createPr).
function createPrThroughScm(scm, options, branchName, baseBranch) {
    var body = buildPrBodyContent(options);
    try {
        var created = scm.createPr({
            title: sanitizeTitle(options.title),
            branchName: branchName,
            baseBranch: baseBranch,
            body: body,
            removeSourceBranch: options.removeSourceBranch
        });
        if (created && created.success) {
            console.log('✅ Pull/Merge Request created:', created.prUrl || '(URL not found)');
            return created;
        }
        return created || { success: false, error: 'SCM provider returned no result from createPr' };
    } catch (error) {
        var errMsg = toErrorString(error);
        if (isExistingScmPrError(errMsg)) {
            console.warn('SCM provider reported an existing PR/MR for branch ' + branchName + ': ' + errMsg);
        }
        return { success: false, error: errMsg };
    }
}

// Temp body-file location: inside the working dir when one is set (trailing
// slash collapsed), next to the caller's cwd otherwise.
function resolveGhTempBodyPath(workingDir, tempBodyFile) {
    return workingDir ? workingDir.replace(/\/$/, '') + '/' + tempBodyFile : tempBodyFile;
}

// Runs `gh pr create` and shapes the outcome: URL extraction on success,
// already-exists recovery via `gh pr list`, the error otherwise; the temp
// body file is ALWAYS cleaned up (finally).
function runGhPrCreate(command, runCommand, deleteFile, tempBodyPath, branchName, workingDir) {
    try {
        var output = runCommand(command, workingDir) || '';
        var prUrl = extractPrUrl(output, runCommand, branchName, workingDir);
        console.log('✅ Pull Request created:', prUrl || '(URL not found)');
        return { success: true, prUrl: prUrl, output: output };
    } catch (error) {
        var errMsg = error.toString();
        if (isExistingGhPrError(errMsg)) {
            var existingUrl = extractPrUrl('', runCommand, branchName, workingDir);
            if (existingUrl) {
                console.log('✅ Found existing PR:', existingUrl);
                return { success: true, prUrl: existingUrl, alreadyExisted: true };
            }
        }
        console.error('Failed to create Pull Request:', errMsg);
        return { success: false, error: errMsg };
    } finally {
        // Clean up the temp PR-body file regardless of outcome. On an ephemeral CI
        // runner this is harmless either way, but on a reused local-teammate
        // checkout (run-teammate-local.sh) a leftover untracked file dirties the
        // tree and blocks the dirty-tree guard on the very next ticket.
        deleteFile(tempBodyPath);
    }
}

// The gh-cli creation path: duplicate lookup → temp body file → gh pr create
// → URL extraction, with already-exists recovery and guaranteed temp cleanup.
function createGhPullRequest(options, branchName) {
    var baseBranch = options.baseBranch || 'main';
    var workingDir = options.workingDir || null;
    var runCommand = options.runCommand || defaultRunCommand;
    var writeFile = options.writeFile || defaultWriteFile;
    var deleteFile = options.deleteFile || defaultDeleteFile;

    var existingPr = findExistingGhPr(runCommand, branchName, workingDir);
    if (existingPr) {
        console.log('✅ PR already exists for branch ' + branchName + ': ' + existingPr);
        return { success: true, prUrl: existingPr, alreadyExisted: true };
    }

    var tempBodyFile = options.tempBodyFile || 'pr_body_tmp.md';
    var tempBodyPath = resolveGhTempBodyPath(workingDir, tempBodyFile);
    var bodyContent = buildPrBodyContent(options);
    writeFile(tempBodyPath, bodyContent);

    var command = buildGhPrCreateCommand(options.title, tempBodyFile, baseBranch, branchName);
    return runGhPrCreate(command, runCommand, deleteFile, tempBodyPath, branchName, workingDir);
}

function createPullRequest(options) {
    options = options || {};
    var branchName = options.branchName;

    if (!branchName) return { success: false, error: 'branchName is required' };

    var scm = options.scm || null;
    if (scm && typeof scm.createPr === 'function') {
        return createPrThroughScm(scm, options, branchName, options.baseBranch || 'main');
    }
    return createGhPullRequest(options, branchName);
}

module.exports = {
    cleanCommandOutput: cleanCommandOutput,
    sanitizeTitle: sanitizeTitle,
    sanitizeCommitMessage: sanitizeCommitMessage,
    extractIssueNumber: extractIssueNumber,
    ensureClosesLine: ensureClosesLine,
    isPrBodyFrozen: isPrBodyFrozen,
    buildOriginFetchCommand: buildOriginFetchCommand,
    buildTargetedOriginFetchCommand: buildTargetedOriginFetchCommand,
    ensureRemoteBranchRef: ensureRemoteBranchRef,
    stripGitNoise: stripGitNoise,
    remoteRefLines: remoteRefLines,
    remoteBranchSha: remoteBranchSha,
    remoteBranchExists: remoteBranchExists,
    readTrackedStatus: readTrackedStatus,
    // gh-1246: canonical submodule probe, reused by postTestReworkResults.
    isSubmodulePath: isSubmodulePath,
    readStagedDiffStat: readStagedDiffStat,
    lastNonEmptyLine: lastNonEmptyLine,
    stageOutputHasSubmodule: stageOutputHasSubmodule,
    syncBranchWithBase: syncBranchWithBase,
    createPullRequest: createPullRequest,
    // gh-1041: creation-path helpers exposed as testable pure helpers
    buildPrBodyContent: buildPrBodyContent,
    buildGhPrCreateCommand: buildGhPrCreateCommand,
    isExistingGhPrError: isExistingGhPrError,
    isExistingScmPrError: isExistingScmPrError,
    findExistingGhPr: findExistingGhPr,
    createPrThroughScm: createPrThroughScm,
    createGhPullRequest: createGhPullRequest,
    resolveGhTempBodyPath: resolveGhTempBodyPath,
    runGhPrCreate: runGhPrCreate,
    toErrorString: toErrorString,
    // gh-1190: syncBranchWithBase seam — pure build/decide helpers exposed
    // for direct characterization tests.
    validateSyncInputs: validateSyncInputs,
    mergeInProgressSyncResult: mergeInProgressSyncResult,
    unrelatedHistoriesSyncResult: unrelatedHistoriesSyncResult,
    uncleanTreeSyncResult: uncleanTreeSyncResult,
    realignSubmodulesBeforeSync: realignSubmodulesBeforeSync,
    resolveSyncPreconditions: resolveSyncPreconditions,
    abortMergeQuietly: abortMergeQuietly,
    buildSyncFailureMessage: buildSyncFailureMessage,
    syncFailureResult: syncFailureResult,
    recoverFromSyncError: recoverFromSyncError,
    syncOptionsOf: syncOptionsOf,
    // gh-1190: shared two-branch-mode route decision (used by
    // checkoutBranch.js and preCliDevelopmentSetup.js).
    decideFeatureBranchRoute: decideFeatureBranchRoute
};
