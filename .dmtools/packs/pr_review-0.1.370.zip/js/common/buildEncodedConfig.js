/**
 * Shared encoded config builder for SM Agent and autoStart triggers.
 *
 * Reads the target agent JSON, copies its params, merges project-specific
 * instructions from .dmtools/config.js, and produces the URL-encoded
 * `encoded_config` payload that `ai-teammate.yml` consumes.
 *
 * Keeping this logic in one place guarantees that a workflow triggered by
 * SM, by autoStart, or manually with the same builder always receives the
 * same resolved params (cliPrompts, customParams, feedbackLoop, etc.).
 */

var configLoader = require('../configLoader.js');
var validateInputJql = require('./validateInputJql.js');
var trackers = require('./trackers.js');

function extractAgentName(configFile) {
    if (!configFile) return '';
    var name = configFile;
    var slashIdx = name.lastIndexOf('/');
    if (slashIdx !== -1) name = name.substring(slashIdx + 1);
    if (name.indexOf('.json') !== -1) name = name.replace('.json', '');
    return name;
}

/**
 * Resolve the full path to an agent config JSON.
 *
 * @param {Object|string} rule - Either a rule object with a `configFile`
 *   property or a bare config file name/path.
 * @param {Object} effectiveConfig - Loaded project config; its
 *   `agentConfigsDir` is used when only a bare filename is provided.
 * @returns {string|null} Resolved config file path.
 */
function resolveConfigFile(rule, effectiveConfig) {
    var cf = (rule && rule.configFile) || rule;
    if (!cf || typeof cf !== 'string') return null;
    if (cf.indexOf('/') !== -1) return cf;
    var dir = effectiveConfig && effectiveConfig.agentConfigsDir;
    if (dir) {
        return dir.replace(/\/$/, '') + '/' + cf;
    }
    return cf;
}

function tryReadJson(path) {
    try {
        var raw = file_read({ path: path });
        if (raw && raw.trim()) {
            return JSON.parse(raw);
        }
    } catch (e) {
        // ignore
    }
    return null;
}

/**
 * Resolve the directory portion of a file path.
 * "agents/story_solution_e2e.json" → "agents/"
 */
function dirOf(filePath) {
    var idx = filePath.lastIndexOf('/');
    return idx >= 0 ? filePath.substring(0, idx + 1) : '';
}

/** The inheritance marker: a parent block with a path, within the depth guard. */
function hasParentRef(agentJson, depth) {
    return Boolean(agentJson && agentJson.parent && agentJson.parent.path) && depth <= 10;
}

/** Accept both "params.cliPrompts" and bare "cliPrompts". */
function directiveKey(fieldPath) {
    var key = fieldPath;
    if (key.indexOf('params.') === 0) {
        key = key.substring('params.'.length);
    }
    return key;
}

/** Parent-first array concat; non-array sides contribute nothing. */
function arrayOrEmpty(value) {
    return Array.isArray(value) ? value : [];
}

/** merged[key] = parent items + child items (parent items prepended). */
function applyMergeDirective(merged, parentParams, childParams, fieldPath) {
    var key = directiveKey(fieldPath);
    merged[key] = arrayOrEmpty(parentParams[key]).concat(arrayOrEmpty(childParams[key]));
}

/** Apply every path in parent.merge; a missing/invalid merge block applies nothing. */
function applyMergeDirectives(merged, agentJson, parentParams, childParams) {
    var mergeFields = (agentJson.parent.merge && Array.isArray(agentJson.parent.merge))
        ? agentJson.parent.merge : [];

    mergeFields.forEach(function(fieldPath) {
        applyMergeDirective(merged, parentParams, childParams, fieldPath);
    });
}

/**
 * Recursively resolve parent inheritance for an agent JSON config.
 *
 * Supports `parent.merge` for array fields (currently only params.cliPrompts).
 * Per the JSON config spec: merged array = parent items + child items.
 *
 * @param {Object} agentJson   - Parsed agent JSON (may contain a `parent` block).
 * @param {string} agentPath   - File path used to resolve relative `parent.path` values.
 * @param {number} [depth=0]   - Recursion guard (max 10 levels).
 * @returns {Object} Fully-resolved `params` object with parent inheritance applied.
 */
function parentCandidatePaths(parentRefPath, agentPath, base) {
    if (String(parentRefPath || '').indexOf('@') !== -1) {
        return ['agents/' + base + '.json', base + '.json'];
    }
    return [dirOf(agentPath) + base + '.json', 'agents/' + base + '.json', base + '.json'];
}

function resolveParentFilePath(parentRefPath, agentPath) {
    var direct = dirOf(agentPath) + parentRefPath;
    if (direct !== agentPath && tryReadJson(direct)) {
        return direct;
    }
    var base = String(parentRefPath || '').replace(/@[^/]+$/, '').replace(/\.json$/i, '');
    if (!base) {
        return direct;
    }
    var candidates = parentCandidatePaths(parentRefPath, agentPath, base);
    for (var i = 0; i < candidates.length; i++) {
        if (candidates[i] !== agentPath && tryReadJson(candidates[i])) {
            return candidates[i];
        }
    }
    return direct;
}

function resolveParentMerge(agentJson, agentPath, depth) {
    depth = depth || 0;
    var childParams = (agentJson && agentJson.params) ? agentJson.params : {};

    if (!hasParentRef(agentJson, depth)) {
        return childParams;
    }

    var parentAbsPath = resolveParentFilePath(agentJson.parent.path, agentPath);
    var parentJson = tryReadJson(parentAbsPath);
    if (!parentJson) {
        return childParams;
    }

    // Resolve grandparent chain first
    var parentParams = resolveParentMerge(parentJson, parentAbsPath, depth + 1);

    // Deep-merge: parent as base, child overrides
    var merged = configLoader.deepMerge(parentParams, childParams);

    // Apply merge directives
    applyMergeDirectives(merged, agentJson, parentParams, childParams);

    return merged;
}

/**
 * Read contentOutput.target from a customParams object, if present.
 */
function readContentOutputTarget(customParams) {
    if (customParams && customParams.contentOutput &&
            typeof customParams.contentOutput.target === 'string') {
        return customParams.contentOutput.target;
    }
    return null;
}

function isWikiOutputTarget(target) {
    return target === 'confluence' || target === 'wiki';
}

function hasConfluencePrompts(source) {
    return Boolean(source && source.cliPromptsByTracker && source.cliPromptsByTracker.confluence);
}

/**
 * Resolve the 'confluence' tracker-prompt override for an agent.
 *
 * When the effective customParams (agent JSON customParams, overridable via the project
 * config's jobParamPatches.<agent>.customParams) route generated content exclusively to
 * Confluence (contentOutput.target === 'confluence'), tracker-specific CLI prompts must be
 * selected by the 'confluence' key so the CLI agent authors Markdown instead of tracker
 * markup (e.g. Jira wiki). Returns 'confluence' only when confluence tracker prompts are
 * actually declared (agent JSON or project config); otherwise null — callers then keep the
 * default tracker, matching the runtime fallback in CliCommandBuilder.
 */
function resolveConfluenceTrackerOverride(agentParamsRoot, effectiveConfig, agentName) {
    var patches = effectiveConfig && effectiveConfig.jobParamPatches && effectiveConfig.jobParamPatches[agentName];
    var target = readContentOutputTarget(patches && patches.customParams) ||
        readContentOutputTarget(agentParamsRoot && agentParamsRoot.customParams);
    if (!isWikiOutputTarget(target)) {
        return null;
    }
    return (hasConfluencePrompts(agentParamsRoot) || hasConfluencePrompts(effectiveConfig)) ? 'confluence' : null;
}

/**
 * Derive the project key used to resolve a project-specific agent JSON
 * (e.g. "agents/pr_review.json" -> "ai_teammate/myproject/pr_review.json").
 * Explicit rule.projectKey wins; otherwise the basename of the loaded
 * project config path is used unless it is the generic "config".
 *
 * @param {Object|string} rule - Rule object or resolved config file path.
 * @param {Object} effectiveConfig - Loaded project config.
 * @returns {string} Project key ('' when none can be derived).
 */
function resolveProjectKey(rule, effectiveConfig) {
    var projectKey = (rule && rule.projectKey) || '';
    if (!projectKey && effectiveConfig && effectiveConfig._configPath) {
        var cp = effectiveConfig._configPath;
        var base = cp.substring(cp.lastIndexOf('/') + 1).replace(/\.js$/, '');
        if (base && base !== 'config') projectKey = base;
    }
    return projectKey;
}

/**
 * Resolve which agent JSON file to read: the project-specific variant
 * ("ai_teammate/<projectKey>/<filename>") when it exists, otherwise the
 * generic resolved config file.
 */
function resolveAgentJsonPath(resolvedCf, projectKey) {
    var agentJsonPath = resolvedCf;
    if (projectKey) {
        var filename = resolvedCf.replace(/^.*\//, '');
        var projectSpecific = 'ai_teammate/' + projectKey + '/' + filename;
        if (tryReadJson(projectSpecific)) {
            agentJsonPath = projectSpecific;
        }
    }
    return agentJsonPath;
}

/**
 * True when a string param carries a JQL placeholder that must be
 * interpolated against the project config.
 */
function needsJqlInterpolation(value) {
    return value.indexOf('{jiraProject}') !== -1 || value.indexOf('{parentTicket}') !== -1;
}

/**
 * Copy a single agent-JSON param value into the encoded params payload,
 * applying the JQL interpolation to strings carrying {jiraProject} /
 * {parentTicket} placeholders and deep-copying structured values.
 * cliPromptsByTracker is cleared to null in copyAgentParams: tracker prompts
 * are already resolved and flattened into cliPrompts (resolveInstructions),
 * and an explicit null overrides the base agent JSON's cliPromptsByTracker map
 * during ConfigurationMerger.deepMerge so the runtime (CliCommandBuilder)
 * does not append the base tracker prompts a second time (gh-1267).
 */
function copyParamValue(p, paramKey, value, effectiveConfig) {
    if (typeof value === 'string') {
        if (needsJqlInterpolation(value)) {
            p[paramKey] = configLoader.interpolateJql(value, effectiveConfig);
        } else {
            p[paramKey] = value;
        }
    } else if (typeof value === 'boolean' || typeof value === 'number') {
        p[paramKey] = value;
    } else if (Array.isArray(value)) {
        p[paramKey] = value.slice();
    } else if (typeof value === 'object' && value !== null) {
        p[paramKey] = JSON.parse(JSON.stringify(value));
    }
}

/**
 * Copy all scalar/array/object params from the resolved agent JSON into the
 * encoded params payload (skipping inputJql and replacing cliPromptsByTracker
 * with null so runtime deepMerge neutralizes the base config's tracker map).
 */
function copyAgentParams(p, agentParamsRoot, effectiveConfig) {
    p.cliPromptsByTracker = null;
    var skipKeys = { inputJql: true, cliPromptsByTracker: true };
    Object.keys(agentParamsRoot).forEach(function(paramKey) {
        if (skipKeys[paramKey]) return;
        copyParamValue(p, paramKey, agentParamsRoot[paramKey], effectiveConfig);
    });
}

/**
 * Copy the nested agentParams / customParams objects from the agent JSON
 * into the encoded params payload (agentParams deep-merged from empty,
 * customParams shallow-copied).
 */
function copyNestedAgentObjects(p, agentParamsRoot) {
    var agentParams = agentParamsRoot.agentParams;
    if (agentParams && typeof agentParams === 'object') {
        p.agentParams = configLoader.deepMerge({}, agentParams);
    }
    var agentCustomParams = agentParamsRoot.customParams;
    if (agentCustomParams && typeof agentCustomParams === 'object') {
        p.customParams = Object.assign({}, agentCustomParams);
    }
}

/**
 * Apply the instruction-level resolutions from resolveInstructions():
 * a full instructions override lands in agentParams.instructions;
 * additionalInstructions are appended.
 */
function applyInstructionExtras(p, resolved) {
    if (resolved.instructionsOverridden) {
        if (!p.agentParams) p.agentParams = {};
        p.agentParams.instructions = resolved.instructions;
    }
    if (resolved.additionalInstructions && resolved.additionalInstructions.length > 0) {
        p.additionalInstructions = resolved.additionalInstructions;
    }
}

/**
 * Apply the resolved CLI prompts: 'replace' strategy swaps the JSON-inherited
 * cliPrompts entirely, the default 'merge' strategy appends after them.
 * A resolved cliPrompt override wins last.
 */
function applyCliPrompts(p, resolved) {
    if (resolved.cliPrompts && resolved.cliPrompts.length > 0) {
        if (resolved.cliPromptsStrategy === 'replace') {
            // replace: config.js prompts replace the JSON-inherited cliPrompts entirely
            p.cliPrompts = resolved.cliPrompts;
        } else {
            // merge (default): append config.js prompts after the JSON-inherited ones
            var existing = Array.isArray(p.cliPrompts) ? p.cliPrompts : [];
            p.cliPrompts = configLoader.appendTrackerPrompts(existing, resolved.cliPrompts);
        }
    }
    if (resolved.cliPrompt) {
        p.cliPrompt = resolved.cliPrompt;
    }
}

/**
 * Apply the agentParamPatch / jobParamPatch from the project config. The
 * jobParamPatch deep-merges into the whole params payload, so it is applied
 * last and its result is returned (p may be replaced by the merge).
 */
function applyConfigPatches(p, resolved) {
    if (resolved.agentParamPatch) {
        if (!p.agentParams) p.agentParams = {};
        p.agentParams = configLoader.deepMerge(p.agentParams, resolved.agentParamPatch);
    }
    if (resolved.jobParamPatch) {
        p = configLoader.deepMerge(p, resolved.jobParamPatch);
    }
    return p;
}

/**
 * Resolve the Jira field-name override for story_acceptance_criteria agents
 * from config.jira.fields.acceptanceCriteria (null when not configured).
 */
function resolveFieldNameOverride(agentName, effectiveConfig) {
    var jiraFields = effectiveConfig.jira && effectiveConfig.jira.fields;
    if (!jiraFields) return null;
    var fieldMap = {
        'story_acceptance_criteria': jiraFields.acceptanceCriteria,
        'story_acceptance_criterias': jiraFields.acceptanceCriteria
    };
    return fieldMap[agentName] || null;
}

/**
 * Build the metadata block for the encoded payload: agentId and/or contextId
 * (upper-cased project key). Returns null when both are absent.
 */
function buildMetadata(agentId, contextId) {
    if (!agentId && !contextId) return null;
    var metadata = {};
    if (agentId) metadata.agentId = agentId;
    if (contextId) metadata.contextId = contextId;
    return metadata;
}

// ---------------------------------------------------------------------------
// Orchestration steps (gh-1197) — each phase of buildEncodedConfig lives in
// its own small function so the top-level builder stays a thin sequence with
// no branching beyond input validation.
// ---------------------------------------------------------------------------

/**
 * Read the agent JSON for a resolved config file and copy its params into the
 * payload (deep-merging parent inheritance). Returns the resolved config file,
 * project key and the resolved agent params root for later phases.
 */
function loadAgentJsonParams(p, rule, effectiveConfig) {
    var resolvedCf = resolveConfigFile(rule, effectiveConfig);
    var projectKey = resolveProjectKey(rule, effectiveConfig);
    var agentParamsRoot = {};

    if (resolvedCf) {
        var agentJsonPath = resolveAgentJsonPath(resolvedCf, projectKey);
        var agentJson = tryReadJson(agentJsonPath);
        if (agentJson && agentJson.params) {
            agentParamsRoot = resolveParentMerge(agentJson, agentJsonPath);
            copyAgentParams(p, agentParamsRoot, effectiveConfig);
            copyNestedAgentObjects(p, agentParamsRoot);
        }
    }

    return { resolvedCf: resolvedCf, projectKey: projectKey, agentParamsRoot: agentParamsRoot };
}

/**
 * Apply the project config's instruction/prompt/patch resolutions for the
 * agent (resolveInstructions) plus the per-agent Jira field-name override.
 * Returns the (possibly replaced) params payload.
 */
function applyProjectConfigResolutions(p, resolvedCf, agentParamsRoot, effectiveConfig) {
    if (!effectiveConfig || !resolvedCf) return p;
    var agentName = extractAgentName(resolvedCf);
    var trackerOverride = resolveConfluenceTrackerOverride(agentParamsRoot, effectiveConfig, agentName);
    var resolved = configLoader.resolveInstructions(agentName, null, effectiveConfig, agentParamsRoot.cliPromptsByTracker,
        trackerOverride ? { trackerOverride: trackerOverride } : undefined);

    applyInstructionExtras(p, resolved);
    applyCliPrompts(p, resolved);
    p = applyConfigPatches(p, resolved);

    var fieldName = resolveFieldNameOverride(agentName, effectiveConfig);
    if (fieldName) {
        p.fieldName = fieldName;
    }
    return p;
}

function stampConfigPath(p, effectiveConfig) {
    if (effectiveConfig && effectiveConfig._configPath) {
        if (!p.customParams) p.customParams = {};
        p.customParams.configPath = effectiveConfig._configPath;
    }
    return p;
}

function stampLocalTeammate(p, isLocal) {
    if (isLocal) {
        if (!p.customParams) p.customParams = {};
        p.customParams.localTeammate = true;
    }
    return p;
}

/**
 * Attach the metadata block (agentId from the config file name, contextId from
 * the upper-cased project key) when either is present.
 */
function attachMetadata(p, resolvedCf, projectKey) {
    var agentId = resolvedCf ? extractAgentName(resolvedCf) : null;
    var contextId = projectKey ? projectKey.toUpperCase() : null;
    var metadata = buildMetadata(agentId, contextId);
    if (metadata) {
        p.metadata = metadata;
    }
    return p;
}

/**
 * Build the encoded config payload for a workflow dispatch.
 *
 * @param {string} ticketKey - Ticket key to process.
 * @param {Object|string} rule - Rule object or resolved config file path.
 * @param {Object} effectiveConfig - Project config from configLoader.
 * @param {boolean} [isLocal] - When true, marks the built config with
 *   `customParams.localTeammate = true` so the job it starts knows it is
 *   running locally (via smAgent's runTeammateLocally/forceLocalTeammate path)
 *   rather than as a GitHub Actions workflow_dispatch. Consumed by
 *   autoStart.js's triggerConfiguredWorkflowForTicket() to keep any further
 *   autoStartReview/autoStartRework chaining on the same machine instead of
 *   dispatching to GitHub Actions.
 * @returns {string} URL-encoded JSON string for workflow_dispatch `encoded_config`.
 */
function resolveTicketInputJql(ticketKey, effectiveConfig) {
    var provider = trackers.createTracker(effectiveConfig, {}).provider();
    return validateInputJql.inputJqlForKey(ticketKey, provider);
}

function buildEncodedConfig(ticketKey, rule, effectiveConfig, isLocal) {
    // One owner of the key rules (validateInputJql). Injection-shaped keys still fail.
    if (!validateInputJql.isValidTicketKey(ticketKey)) {
        throw new Error('Invalid ticket key: "' + ticketKey +
            '". Expected a Jira key (PROJECT-123), a GitHub or GitLab issue key, or an Azure DevOps work item id');
    }
    var p = { inputJql: resolveTicketInputJql(ticketKey, effectiveConfig) };

    var agent = loadAgentJsonParams(p, rule, effectiveConfig);
    p = applyProjectConfigResolutions(p, agent.resolvedCf, agent.agentParamsRoot, effectiveConfig);
    p = stampConfigPath(p, effectiveConfig);
    p = stampLocalTeammate(p, isLocal);

    if (!p.agentParams) p.agentParams = {};

    p = attachMetadata(p, agent.resolvedCf, agent.projectKey);

    return encodeURIComponent(JSON.stringify({ params: p }));
}


module.exports = {
    extractAgentName: extractAgentName,
    resolveConfigFile: resolveConfigFile,
    resolveParentMerge: resolveParentMerge,
    resolveParentFilePath: resolveParentFilePath,
    // gh-122: extracted parent-merge helpers, exported for unit tests.
    hasParentRef: hasParentRef,
    directiveKey: directiveKey,
    arrayOrEmpty: arrayOrEmpty,
    applyMergeDirective: applyMergeDirective,
    applyMergeDirectives: applyMergeDirectives,
    resolveConfluenceTrackerOverride: resolveConfluenceTrackerOverride,
    buildEncodedConfig: buildEncodedConfig,
    resolveTicketInputJql: resolveTicketInputJql,
    resolveProjectKey: resolveProjectKey,
    resolveAgentJsonPath: resolveAgentJsonPath,
    copyParamValue: copyParamValue,
    needsJqlInterpolation: needsJqlInterpolation,
    copyAgentParams: copyAgentParams,
    copyNestedAgentObjects: copyNestedAgentObjects,
    applyInstructionExtras: applyInstructionExtras,
    applyCliPrompts: applyCliPrompts,
    applyConfigPatches: applyConfigPatches,
    resolveFieldNameOverride: resolveFieldNameOverride,
    buildMetadata: buildMetadata,
    loadAgentJsonParams: loadAgentJsonParams,
    applyProjectConfigResolutions: applyProjectConfigResolutions,
    stampConfigPath: stampConfigPath,
    stampLocalTeammate: stampLocalTeammate,
    attachMetadata: attachMetadata
};
