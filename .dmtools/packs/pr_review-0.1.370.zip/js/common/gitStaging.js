/**
 * Shared staging hygiene for machine-local fa/dmtools runtime artifacts (gh-628, gh-683).
 *
 * The machine's runtime files live INSIDE the committed .dmtools/ directory
 * (config.js, runners/), so the directory itself cannot be ignored — each
 * artifact is excluded by pathspec instead. Every commit-producing staging
 * site (developTicketAndCreatePR, developBugAndCreatePR, pushReworkChanges,
 * timerAutoCommitAndSave) builds its commands from this single canonical
 * list, so the `git rm -r --cached` untrack list and the `git add` exclusion
 * pathspecs can never drift apart again (round 1 review found .dmtools/
 * fa-sessions in every staging pathspec but in none of the untrack lists).
 *
 * gh-683 (live fa run 37153405587, fa gh-1206, 2026-10-03): `git add` runs
 * its ignored-pathspec guard on EVERY pathspec element — including `:!`
 * EXCLUSION pathspecs. Naming a path that is gitignored AND exists untracked
 * in the working tree fails the whole add with exit 1 ("The following paths
 * are ignored by one of your .gitignore files ... Use -f if you really want
 * to add them"), killing the dev leg after a fully green run. The guard does
 * NOT fire when the ignored path is tracked (poisoned branch), nonexistent,
 * or when the pathspec is a glob — only for a literal pathspec naming an
 * existing ignored-untracked file. So the staging pathspecs are now built
 * through a `git check-ignore` probe (buildStagingPathspecs): a path git
 * already ignores is left to git's own exclude machinery (gitignore alone
 * keeps `git add .` away from it — no pathspec, no guard to trip), while a
 * path git does NOT ignore keeps its `:!` exclusion (and a not-ignored path
 * can never trip the ignored-files guard). This holds for ANY future runtime
 * file added to the list: ignored repo → no pathspec; unignored repo →
 * exclusion, guard-safe either way.
 *
 * GraalJS-compatible: var/plain functions only, no Node APIs.
 */

var RUNTIME_ARTIFACT_PATHS = [
    '.dmtools/copilot-sessions',
    '.dmtools/credential-helper.log',
    '.dmtools/codegraph-usage.log',
    '.dmtools/fa-trace.log',
    '.dmtools/run-output.txt',
    '.dmtools/stall-capture.log',
    '.dmtools/fa-sessions',
    // gh-1436: plan-mode appendix materialization — engine-written prompt
    // input, never leg work; the DURABLE plan artifact is the agent-committed
    // .dmtools/plan-snapshot.md.
    '.dmtools/development-mode-plan-appendix.md',
    '.dmtools-session-output.log',
    '.claude-session-id',
    '.dmtools-target-workingdir',
    '.fah/trajectories',
    '.fah/bash_jobs',
    // gh-1505 / epam/dm.ai#868: legacy dmtools REST-client cache folders
    // created in the working directory before DMTOOLS_CACHE_DIR defaulted to
    // ~/.dmtools/cache (plus any custom cache*Client / cacheTestRail dirs).
    'cache*Client',
    'cacheTestRail',
    'cacheBasic*'
];

/**
 * gh-1318: the tracker-regenerated leg context. input/ (ticket description,
 * comments, answers) and outputs/ (response.md, markers) are ephemeral per-leg
 * context — the tracker regenerates both before every leg — so they must never
 * be committed to a work branch. Committing them is what created the
 * stale-WIP collision in the first place: an ask-mode leg pushed its own
 * pre-answer input/ snapshot onto ai/<ticket>, and the re-run leg either had
 * its fresh copy cleaned away (checkoutBranch) or refused the checkout
 * outright (preCliDevelopmentSetup). Paired with the .git/info/exclude seed
 * (branchSetup.ensureLegContextLocalExcludes): the seed keeps `git add -A`
 * from ever staging them again, the untrack heals branches that already
 * carry them.
 */
var LEG_CONTEXT_ARTIFACT_PATHS = ['input', 'outputs'];

/**
 * Command that lists which of `paths` git actually TRACKS (gh-683: only tracked paths are ever
 * handed to `git rm`). A plain `git ls-files -- <paths>` — no pipe, `;` or `&&` — so it passes the
 * Java cli_execute_command shell-injection validator (epam/dm.ai#679: the old single-line
 * `ls-files | while read … git rm` form was rejected there on every run).
 */
function buildTrackedPathsCommand(paths) {
    var expanded = [];
    var list = paths || [];
    for (var i = 0; i < list.length; i++) {
        var p = list[i];
        expanded.push(p);
        if (p.indexOf('*') !== -1 && p.slice(-3) !== '/**') {
            expanded.push('"' + p + '/**"');
        }
    }
    return 'git ls-files -- ' + expanded.join(' ');
}

function buildTrackedArtifactsCommand() {
    return buildTrackedPathsCommand(RUNTIME_ARTIFACT_PATHS);
}

/**
 * `git rm --cached` for an explicit list of tracked paths (`--cached` is required — plain `git rm`
 * refuses locally-modified files, and these logs are always being appended). Paths are quoted.
 */
function buildUntrackPathsCommand(paths) {
    return 'git rm -r --cached --ignore-unmatch -- ' + (paths || []).map(function (p) {
        return '"' + p + '"';
    }).join(' ');
}

/**
 * Untracks already-poisoned paths from `paths`: lists the tracked ones, then removes only those from
 * the index. Nothing tracked (the normal case) = exactly ONE command (the listing) and no rm, so an
 * untracked path is never named to `git rm`. Two plain commands instead of one shell pipeline, so the
 * same code runs under the Java validator and the Dart bridge.
 *
 * @param {function(string): *} run executes a command string (the site's own wrapper, in the right
 *        working directory) and returns its output; may throw — callers keep their own try/catch
 * @param {string[]} paths the candidate paths (a listed line counts only when it equals one of them
 *        or lives underneath it)
 * @returns {string[]} the paths that were untracked (empty when nothing was tracked)
 */
function matchesCandidatePrefix(pathStr, candidate) {
    if (candidate.indexOf('*') !== -1) {
        var pattern = '^' + candidate.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '[^/]*') + '(/|$)';
        return new RegExp(pattern).test(pathStr);
    }
    return pathStr === candidate || pathStr.indexOf(candidate + '/') === 0;
}

function matchesAnyCandidatePath(pathStr, candidates) {
    var list = candidates;
    for (var i = 0; i < list.length; i++) {
        if (matchesCandidatePrefix(pathStr, list[i])) return true;
    }
    return false;
}

function untrackTrackedPaths(run, paths) {
    var candidates = paths || [];
    var listed = String(run(buildTrackedPathsCommand(candidates)) || '');
    var tracked = listed.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(function (l) {
        return l && matchesAnyCandidatePath(l, candidates);
    });
    if (tracked.length === 0) return [];
    run(buildUntrackPathsCommand(tracked));
    return tracked;
}

/**
 * Untracks already-poisoned runtime artifacts: lists the tracked ones, then removes only those from
 * the index. See untrackTrackedPaths for the command contract.
 */
function untrackRuntimeArtifacts(run) {
    return untrackTrackedPaths(run, RUNTIME_ARTIFACT_PATHS);
}

/**
 * gh-1318: untrack branch-committed leg context (input/, outputs/) — the
 * poisoned-branch half of the leg-context heal. Run right after the dev-branch
 * checkout so the ticket's own regenerated context never rides the leg's
 * commits again; pairs with branchSetup.ensureLegContextLocalExcludes.
 */
function untrackLegContextArtifacts(run) {
    return untrackTrackedPaths(run, LEG_CONTEXT_ARTIFACT_PATHS);
}

/**
 * Probe-filtered `:!` exclusion pathspecs for an arbitrary path list.
 * Each path that git does NOT already ignore yields `":!<path>"` plus
 * `":!<path>/**"` (quoted, so a shell or cli_execute_command never splits
 * paths); a path git already ignores yields nothing — gitignore alone keeps
 * it out of `git add`, and naming it in ANY pathspec (exclusions included)
 * is exactly what trips git add's ignored-pathspec guard.
 *
 * gh-683 + gh-1164 probe contract: `runCommand` takes { command } (e.g. the
 * site's cli_execute_command wrapper, executing in the SAME working
 * directory as the add) and runs `git check-ignore -q -- <path>`:
 *   - probe succeeds (exit 0 = git already ignores the path): the exclusion
 *     is DROPPED (live guard casualties: fa runs 37153405587, 37153882406);
 *   - probe throws (exit 1 = not ignored; cli_execute_command throws on any
 *     non-zero exit): the exclusion is KEPT — the pathspec is the only thing
 *     keeping the path out of the commit, and a not-ignored path can never
 *     trip the ignored-files guard.
 * Without `runCommand` the full static exclusion list is returned
 * (pre-gh-683 behavior) — kept for signature compatibility.
 */
function buildExclusionPathspecs(paths, runCommand) {
    var kept = paths || [];
    if (typeof runCommand === 'function') {
        kept = kept.filter(function (path) {
            try {
                runCommand({ command: 'git check-ignore -q -- ' + path, expectNonZeroExit: true });
                return false; // ignored — git's own exclude machinery owns it
            } catch (e) {
                return true; // not ignored (or probe unavailable) — pathspec exclusion required
            }
        });
    }
    var specs = [];
    for (var i = 0; i < kept.length; i++) {
        specs.push('":!' + kept[i] + '"');
        specs.push('":!' + kept[i] + '/**"');
    }
    return specs.join(' ');
}

/**
 * `:!` pathspec exclusions (each path and its contents) for `git add` staging
 * commands, e.g. `git add . -- <specs>`. Quoted, so a shell (or
 * cli_execute_command) never splits paths.
 *
 * `extraPaths` (gh-1164): site-specific excludes appended beside the runtime
 * artifacts — above all `factory-kit`, the factory workflow's nested
 * machine-infra repo. Live fa gh-1164 (runs 37153882406 + 37220167230,
 * 2026-10-03/04): the timer autosave's `git add -A` FAILED every 5 minutes
 * for 40+ minutes with exit 1 "The following paths are ignored by one of
 * your .gitignore files", the dev agent's real work was never committed and
 * died with the runner — because every site appended
 * `":!factory-kit" ":!factory-kit/**"` STATICALLY, after the probe-filtered
 * runtime specs. Scratch-repo repro (git 2.50.1): the guard fires on ANY
 * literal pathspec — exclusions included — naming an existing,
 * gitignored-untracked path, and a runner workspace has exactly that when
 * `factory-kit` is materialized AND gitignored. Extra paths therefore go
 * through the SAME check-ignore probe: ignored+present → exclusion dropped
 * (gitignore keeps it out); not ignored (the nested-gitlink case the
 * exclusion exists for) → exclusion kept, guard-safe either way.
 *
 * Every staging site runs the untrack command BEFORE the add, so the probe
 * observes the post-untrack state: a poisoned branch's tracked runtime files
 * are already index-less by then, and the tracked+ignored case never trips
 * the guard anyway.
 */
function buildStagingPathspecs(runCommand, extraPaths) {
    var paths = RUNTIME_ARTIFACT_PATHS.concat(extraPaths || []);
    return buildExclusionPathspecs(paths, runCommand);
}

/**
 * True when a `git status --porcelain` line only reports a machine-local
 * runtime artifact (untracked leftover of the `--cached` untrack, or a dirty
 * log). Such lines are never the CLI agent's work and must not flip
 * change-detection checks (gh-628 round 1: developBugAndCreatePR's
 * interrupted-agent recovery fired on every leg and posted a false
 * "Partial analysis work was saved" comment).
 */
function isRuntimeArtifactStatusLine(line) {
    if (!line) return false;
    for (var i = 0; i < RUNTIME_ARTIFACT_PATHS.length; i++) {
        var item = RUNTIME_ARTIFACT_PATHS[i];
        if (item.indexOf('*') !== -1) {
            var re = new RegExp('(?:^|\\s|")' + item.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '[^/\\s"]*') + '(?:/|"|$)');
            if (re.test(line)) return true;
        } else if (line.indexOf(item) !== -1) {
            return true;
        }
    }
    return false;
}

module.exports = {
    RUNTIME_ARTIFACT_PATHS: RUNTIME_ARTIFACT_PATHS,
    LEG_CONTEXT_ARTIFACT_PATHS: LEG_CONTEXT_ARTIFACT_PATHS,
    buildTrackedArtifactsCommand: buildTrackedArtifactsCommand,
    buildTrackedPathsCommand: buildTrackedPathsCommand,
    buildUntrackPathsCommand: buildUntrackPathsCommand,
    untrackTrackedPaths: untrackTrackedPaths,
    untrackRuntimeArtifacts: untrackRuntimeArtifacts,
    untrackLegContextArtifacts: untrackLegContextArtifacts,
    buildExclusionPathspecs: buildExclusionPathspecs,
    buildStagingPathspecs: buildStagingPathspecs,
    isRuntimeArtifactStatusLine: isRuntimeArtifactStatusLine
};
