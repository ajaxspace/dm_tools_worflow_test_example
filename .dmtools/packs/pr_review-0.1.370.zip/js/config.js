/**
 * Configuration constants for agent scripts
 * Central location for all hardcoded values used across agent workflows
 */

// Jira Issue Types
const ISSUE_TYPES = {
    SUBTASK: 'Subtask',
    TASK: 'Task',
    STORY: 'Story',
    BUG: 'Bug',
    EPIC: 'Epic',
    TEST_CASE: 'Test Case'
};

// Jira Statuses
const STATUSES = {
    IN_REVIEW: 'In Review',                         // ticket handed off for code review
    PO_REVIEW: 'PO REVIEW',                         // transition name → reaches "PO Review" status
    SOLUTION_ARCHITECTURE: 'SOLUTION ARCHITECTURE', // transition name → reaches "Solution Architecture" status
    READY_FOR_DEVELOPMENT: 'Ready For Development',
    IN_DEVELOPMENT: 'In Development',               // transition name → reaches "In Development" status
    IN_PROGRESS: 'In Progress',                     // transition name → reaches "In Development" on Task/SD tickets
    BLOCKED: 'Blocked',
    TODO: 'To Do',
    DONE: 'Done',
    MERGED: 'Merged',                               // PR merged and ticket complete
    IN_REWORK: 'In Rework',                         // PR review failed, focused fixes needed
    READY_FOR_TESTING: 'Ready For Testing',          // Test cases generated, ready for QA
    FAILED: 'Failed',                                // Test automation passed review
    PASSED: 'Passed',                                // Test automation passed review
    IN_REVIEW_PASSED: 'In Review - Passed',          // Test ran and passed, awaiting code review
    IN_REVIEW_FAILED: 'In Review - Failed',          // Test ran and failed, awaiting code review
    IN_TESTING: 'In Testing',                        // Test cases generated, automation in progress
    BUG_TO_FIX: 'Bug To Fix',                        // Bug linked/created for this TC, waiting for fix
    BACKLOG: 'Backlog',                              // Ticket waiting to be picked up
    SKIPPED: 'Skipped',                              // Test intentionally skipped (infra/missing platform/etc.)
    IRRELEVANT: 'Irrelevant',                        // Test became legacy / no longer applicable
    BA_ANALYSIS: 'BA Analysis'                       // Story ready for BA analysis after PO Review
};

// Jira Priorities
const PRIORITIES = {
    LOW: 'Low',
    MEDIUM: 'Medium',
    HIGH: 'High',
    HIGHEST: 'Highest',
    LOWEST: 'Lowest'
};

// Labels
const LABELS = {
    AI_GENERATED: 'ai_generated',
    AI_QUESTIONS_ASKED: 'ai_questions_asked',
    AI_CONCERNS: 'ai_concerns',
    AI_SOLUTION_DESIGN_CREATED: 'ai_solution_design_created',
    AI_DEVELOPED: 'ai_developed',
    AI_PR_REVIEWED: 'ai_pr_reviewed',
    AI_INTAKE: 'ai_intake',
    QUESTION: 'q',
    SD_CORE: 'sd_core',
    SD_API: 'sd_api',
    SD_UI: 'sd_ui',
    NEEDS_API_IMPLEMENTATION: 'needs_api_implementation',
    NEEDS_CORE_IMPLEMENTATION: 'needs_core_implementation',
    AI_TEST_AUTOMATION: 'ai_test_automation',
    PR_APPROVED: 'pr_approved',             // Added to PR and ticket when AI approves, removed after merge attempt
    TEST_PR_REWORK_NEEDED: 'test_pr_rework_needed', // Added when test-automation review requests changes; removed after rework
    TEST_PR_MERGED: 'test_pr_merged',       // Added when a test-automation PR is already merged but not yet finalized
    TEST_PR_FINALIZED: 'test_pr_finalized', // Added after merge finalization so review agents never re-enter the loop
    AI_TESTS_GENERATED: 'ai_tests_generated', // Added after TestCasesGenerator runs — guards against re-generation on re-approval
    BUG_FIX_BATCH: 'bug_fix_batch' // Bugs grouped into a bug-fix batch Epic; excluded from individual bug_development
};

// Git Configuration
const GIT_CONFIG = {
    AUTHOR_NAME: 'AI Teammate',
    AUTHOR_EMAIL: 'agent.ai.native@gmail.com',
    DEFAULT_BASE_BRANCH: 'main',
    DEFAULT_ISSUE_TYPE_PREFIX: 'feature'
};

// Solution Design Module Prefixes
const MODULE_PREFIXES = {
    CORE: '[SD CORE]',
    API: '[SD API]',
    UI: '[SD UI]'
};

// Module Configuration for Solution Design
const SOLUTION_DESIGN_MODULES = [
    { flag: 'core', prefix: MODULE_PREFIXES.CORE, label: LABELS.SD_CORE },
    { flag: 'api', prefix: MODULE_PREFIXES.API, label: LABELS.SD_API },
    { flag: 'ui', prefix: MODULE_PREFIXES.UI, label: LABELS.SD_UI }
];

// Diagram Defaults
const DIAGRAM_DEFAULTS = {
    API_SEQUENCE: 'sequenceDiagram\n    participant Client\n    participant API\n    Client->>API: Request\n    API-->>Client: Response',
    CORE_GRAPH: 'graph TD\n    A[SD CORE Enhancement] --> B[Technical Implementation]'
};

// Diagram Formatting
const DIAGRAM_FORMAT = {
    MERMAID_WRAPPER_START: '{code:mermaid}\n',
    MERMAID_WRAPPER_END: '\n{code}'
};

// Field Names
const JIRA_FIELDS = {
    DIAGRAMS: 'Diagrams',
    SOLUTION: 'Solution',
    FAILED_REASON: 'Failed Reason'
};

// Summary Length Constraints
const SUMMARY_MAX_LENGTH = 120;

// Jira's actual hard limit on the summary field — creating a ticket with a longer
// summary is rejected by the API ("Summary must be less than 255 characters").
// Distinct from SUMMARY_MAX_LENGTH above (a stricter style guideline for
// AI-authored summaries); this is the hard ceiling any summary must respect.
const JIRA_SUMMARY_MAX_LENGTH = 255;

/**
 * Truncate a ticket summary to fit within Jira's hard summary length limit,
 * appending an ellipsis when truncation actually occurs so the cut is visible.
 * Safe to call on any summary — a no-op when it's already short enough.
 *
 * @param {string} summary - full summary text (may include a "[repo] " prefix, etc.)
 * @param {number} [maxLength] - defaults to JIRA_SUMMARY_MAX_LENGTH
 * @returns {string} summary, truncated to maxLength characters if needed
 */
function truncateSummary(summary, maxLength) {
    var limit = maxLength || JIRA_SUMMARY_MAX_LENGTH;
    var text = (summary || '').toString();
    if (text.length <= limit) return text;
    var ellipsis = '...';
    return text.substring(0, Math.max(0, limit - ellipsis.length)) + ellipsis;
}

/**
 * Merge default STATUSES with project-specific overrides.
 * Allows each project to remap status names (e.g. use different Story/Bug workflow
 * status names than the generic defaults) without changing agent JS code.
 *
 * Two override channels are supported, applied in this precedence order (later wins):
 *   1. projectStatuses — from .dmtools/config.js's `jira.statuses` block, loaded via
 *      configLoader.loadProjectConfig(params).jira.statuses. This is the recommended
 *      channel: it applies project-wide to every agent invocation automatically.
 *   2. customParams.customStatuses — a legacy, per-agent-invocation override channel
 *      (set directly in an individual agent JSON's customParams). Still supported for
 *      backward compatibility / one-off overrides that shouldn't apply project-wide.
 *
 * Usage in JS actions:
 *   var config = configLoader.loadProjectConfig(params);
 *   const statuses = resolveStatuses(customParams, config.jira && config.jira.statuses);
 *   jira_move_to_status({ key, statusName: statuses.IN_REVIEW });
 *
 * .dmtools/config.js example (project-wide, recommended):
 *   jira: { statuses: { IN_REVIEW: 'Ready for Review', IN_DEVELOPMENT: 'Development in Progress' } }
 *
 * Config JSON example (customParams.customStatuses, legacy/per-invocation):
 *   "customStatuses": {
 *     "IN_DEVELOPMENT": "In Progress",
 *     "IN_REVIEW": "Ready For Review"
 *   }
 *
 * @param {Object} customParams - customParams from agent config
 * @param {Object} customParams - customParams from agent config
 * @param {Object} [projectStatuses] - project-wide status overrides (config.jira.statuses or config.tracker.statuses)
 * @param {string} [trackerProvider] - optional tracker provider ('jira' | 'ado' | 'github' | 'gitlab') for per-provider overrides
 * @returns {Object} STATUSES merged with project and customParams overrides
 */
function _copyStringEntries(base, source) {
    var keys = Object.keys(source);
    for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (typeof source[k] === 'string') base[k] = source[k];
    }
    return base;
}

function _applyProviderStatuses(base, source, trackerProvider) {
    if (!trackerProvider) return base;
    var provMap = source[String(trackerProvider).toLowerCase()];
    return (provMap && typeof provMap === 'object') ? Object.assign(base, provMap) : base;
}

function _extractStatusEntries(projectStatuses, trackerProvider) {
    if (!projectStatuses || typeof projectStatuses !== 'object') return {};
    var base = _copyStringEntries({}, projectStatuses);
    return _applyProviderStatuses(base, projectStatuses, trackerProvider);
}

function resolveStatuses(customParams, projectStatuses, trackerProvider) {
    var entries = _extractStatusEntries(projectStatuses, trackerProvider);
    var merged = Object.keys(entries).length > 0
        ? Object.assign({}, STATUSES, entries)
        : STATUSES;
    if (!customParams || !customParams.customStatuses) return merged;
    return Object.assign({}, merged, customParams.customStatuses);
}

// ── Default format templates ─────────────────────────────────────────────────
const DEFAULT_FORMATS = {
    commitMessage: {
        development: '{ticketKey} {ticketSummary}',
        testAutomation: '{ticketKey} test: automate {ticketSummary}',
        testRework: '{ticketKey} test rework: {result} test after review',
        rework: '{ticketKey} Rework: address PR review comments',
        wip: '{ticketKey} WIP: partial analysis (agent interrupted)',
        // timerAutoCommitAndSave.js periodic WIP commits; {timestamp} is e.g. 2026-10-12T19-55-14 (agents#883)
        autoSave: '{ticketKey} WIP auto-save {timestamp}'
    },
    prTitle: {
        development: '{ticketKey} {ticketSummary}',
        testAutomation: '{ticketKey} {ticketSummary}',
        rework: '{ticketKey} {ticketSummary} (rework)'
    }
};

// Export all configuration
/**
 * Name of the label that marks a ticket as being in a stage when the tracker rejected the status
 * transition (agents#856): 'PO_REVIEW' / 'PO Review' -> 'stage_po_review'. One definition shared by the
 * tracker (which writes the label) and the SM query placeholders (which select by it).
 */
function stageLabel(stageKey) {
    return 'stage_' + String(stageKey == null ? '' : stageKey)
        .toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}

// ── Rework-round cap helpers (Jira autoStartRework & GitHub machineSm) ──────
var DEFAULT_MAX_AUTO_REWORK_ROUNDS = 3;
var NEEDS_HUMAN_LABEL = 'needs-human';

/**
 * Highest `rework-round-N` label on a ticket/issue (0 when none).
 * Shared by Jira autoStartRework chains and machineSmAgent.countReworkRounds.
 */
function countReworkRounds(labels) {
    var rounds = 0;
    (labels || []).forEach(function(l) {
        var m = /^rework-round-(\d+)$/.exec(l);
        if (m) rounds = Math.max(rounds, parseInt(m[1], 10));
    });
    return rounds;
}

/**
 * Resolve `customParams.maxAutoReworkRounds` with a default of 3.
 * Logs a warning when a non-positive or non-numeric value is configured.
 */
function maxAutoReworkRoundsOf(customParams) {
    if (!customParams || customParams.maxAutoReworkRounds === undefined || customParams.maxAutoReworkRounds === null) {
        return DEFAULT_MAX_AUTO_REWORK_ROUNDS;
    }
    var n = Number(customParams.maxAutoReworkRounds);
    if (n > 0) return Math.floor(n);
    console.warn('⚠️ maxAutoReworkRounds must be > 0 (got ' + JSON.stringify(customParams.maxAutoReworkRounds) + ') — falling back to default ' + DEFAULT_MAX_AUTO_REWORK_ROUNDS + '; use autoStartRework: false to disable auto-rework');
    return DEFAULT_MAX_AUTO_REWORK_ROUNDS;
}

function ticketLabelList(ticket) {
    return (ticket && ticket.fields && ticket.fields.labels) || (ticket && ticket.labels) || [];
}

function addLabelBestEffort(tracker, ticketKey, label) {
    if (!tracker || !ticketKey) return;
    try {
        tracker.addLabel(ticketKey, label);
    } catch (e) {
        console.warn('⚠️ Failed to add label ' + label + ':', e.message || e);
    }
}

/**
 * Evaluate the Jira auto-rework round budget before triggering a configured
 * rework workflow. Returns:
 *   - null when the ticket already has `needs-human` or the budget is spent
 *     (stamps `needs-human` on the ticket when newly capped);
 *   - the next round number (`round + 1`) when within budget.
 *
 * Callers may stamp `rework-round-N` either before dispatch (crash-safe) or
 * after a truthy trigger return via `stampReworkRound` so transient trigger
 * skips (global workflow cap, active duplicate run) do not consume rounds.
 */
function checkAutoReworkBudget(opts) {
    var s = opts || {};
    var labels = s.labels || ticketLabelList(s.ticket);
    if (labels.indexOf(NEEDS_HUMAN_LABEL) !== -1) {
        console.log('ℹ️ autoStartRework: skipped — ticket has ' + NEEDS_HUMAN_LABEL);
        return null;
    }
    var round = countReworkRounds(labels);
    var max = maxAutoReworkRoundsOf(s.customParams);
    if (round >= max) {
        console.warn('🛑 autoStartRework: capped after ' + round + ' round(s) (max ' + max + ') — labeling ' + NEEDS_HUMAN_LABEL);
        addLabelBestEffort(s.tracker, s.ticketKey, NEEDS_HUMAN_LABEL);
        return null;
    }
    return round + 1;
}

function stampReworkRound(tracker, ticketKey, nextRound) {
    addLabelBestEffort(tracker, ticketKey, 'rework-round-' + nextRound);
}

function isAutoReworkConfigured(customParams) {
    return !!(customParams && customParams.autoStartRework && customParams.autoStartReworkConfigFile);
}

function buildAutoReworkTriggerOptions(s) {
    var triggerOpts = {
        ticketKey: s.ticketKey,
        customParams: s.customParams,
        config: s.config,
        configFile: s.customParams.autoStartReworkConfigFile,
        label: s.label || 'pr_rework',
        stripKeys: ['removeLabel', 'autoStartRework', 'autoStartReworkConfigFile']
    };
    if (s.scm) triggerOpts.scm = s.scm;
    return triggerOpts;
}

function triggerCappedAutoRework(opts) {
    var s = opts || {};
    if (!isAutoReworkConfigured(s.customParams)) return false;
    var nextRound = checkAutoReworkBudget(s);
    if (nextRound === null) return null;
    try {
        var triggered = s.autoStart.triggerConfiguredWorkflowForTicket(buildAutoReworkTriggerOptions(s));
        if (triggered) stampReworkRound(s.tracker, s.ticketKey, nextRound);
        return triggered;
    } catch (e) {
        console.warn('⚠️ autoStartRework trigger failed:', e.message || e);
        return false;
    }
}

module.exports = {
    stageLabel,
    DEFAULT_MAX_AUTO_REWORK_ROUNDS,
    NEEDS_HUMAN_LABEL,
    countReworkRounds,
    maxAutoReworkRoundsOf,
    ticketLabelList,
    addLabelBestEffort,
    checkAutoReworkBudget,
    stampReworkRound,
    triggerCappedAutoRework,
    ISSUE_TYPES,
    STATUSES,
    PRIORITIES,
    LABELS,
    GIT_CONFIG,
    SOLUTION_DESIGN_MODULES,
    DIAGRAM_DEFAULTS,
    DIAGRAM_FORMAT,
    JIRA_FIELDS,
    SUMMARY_MAX_LENGTH,
    JIRA_SUMMARY_MAX_LENGTH,
    truncateSummary,
    DEFAULT_FORMATS,
    resolveStatuses
};

