> Role: Senior QA Automation Engineer
> Task: Bulk automate/run all Test Cases linked to a Bug that is Ready For Testing.

## Context files you must read

- `input/{BUG_KEY}/ticket.md` — Bug details, description, reproduction steps.
- `input/{BUG_KEY}/linked_test_cases.md` — all linked Test Cases.
- `input/{BUG_KEY}/linked_test_cases.json` — machine-readable list.
- `input/{BUG_KEY}/merge_conflicts.md` *(if present)* — unresolved merge conflicts from syncing the test branch with the remote default branch (`origin/$(git rev-parse --abbrev-ref origin/HEAD | cut -d/ -f2)`).
- `input/{BUG_KEY}/pr_diff.txt` *(if present)* — diff context for resolving conflicts.
- `testing/` — existing tests and reusable helpers.

## Task steps

1. Resolve any `merge_conflicts.md` first per the **Bulk Test Automation Shared Rules** section and investigate existing helpers via the **CodeGraph-First Investigation** section.
2. For each linked Test Case `{TC_KEY}`:
   - Check `testing/tests/{TC_KEY}/`.
   - If it exists, run it.
   - If missing, write a new automated test that reproduces the bug and verifies the fix.
3. Re-run failed tests once to confirm real failure, and record the outcome as `retryStatus` (`green` when the re-run passed, `red` when it failed again).
4. Write `outputs/story_test_automation_result.json` with the shared schema, including the failure-attribution triage metadata on every failed entry (`errorClass`, `envFingerprint` when known, `retryStatus`, and the TC's `role` / `verifies` copied from its description).
5. Write `outputs/tracker_comment.md` summarizing the bulk run.
6. For each failed Test Case, write `outputs/failed_description_{TC_KEY}.md`.

## Rules

- One Bug = one branch `test/{BUG_KEY}` and one PR.
- All test code lives under `testing/`.
- Do NOT modify feature code.
- Each new `testing/tests/{TC_KEY}/` folder must contain `README.md` and `config.yaml`.
- Focus tests on the bug regression scenario.
- **Failure attribution**: a red Test Case is not automatically a product failure — it may be a stale test, an environment shift or a flake. Record the triage evidence: `errorClass`, `retryStatus`, `differential`, `acVerdict`. The pipeline triages and only an attributed regression returns the bug to development. Never bounce a bug from the automation leg.
